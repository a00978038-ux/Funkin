import funkin.modding.module.Module;
import funkin.modding.events.ScriptEvent;
import funkin.modding.events.SongEventScriptEvent;

import funkin.play.PlayState;
import funkin.graphics.FunkinSprite;
import funkin.audio.FunkinSound;

import flixel.FlxG;
import flixel.util.FlxColor;
import flixel.tweens.FlxEase;
import flixel.tweens.FlxTween;

class SoloTime extends Module
{
	var MULTI_SHIT:Float = 0.5;
	var OFFSET:Float = 0.25;

	public function new()
	{
		super("SoloTime");
	}

	override function onScriptEvent(event:ScriptEvent):Void
	{
		super.onScriptEvent(event);

		if (Std.isOfType(event, SongEventScriptEvent))
		{
			var songEvent:SongEventScriptEvent = cast event;

			if (songEvent.eventData.eventKind == "SoloTime")
			{
				var suffix:String = songEvent.eventData.getString("randParam") ?? "";

				FunkinSound.playOnce(
					Paths.sound(
						"gameplay/solo_time/solotime" + suffix,
						"shared"
					)
				);

				var texturePath:String = "ui/times/solo_time" + suffix;

				var soloTimeTxtSplash = new FunkinSprite();

				soloTimeTxtSplash.loadSparrow(texturePath);

				soloTimeTxtSplash.animation.addByPrefix(
					"anim",
					"solo_time",
					24,
					false
				);

				soloTimeTxtSplash.animation.onFinish.add(
					function(name:String)
					{
						FlxTween.tween(
							soloTimeTxtSplash,
							{alpha: 0},
							0.5,
							{
								onComplete: function(_)
								{
									PlayState.instance.remove(
										soloTimeTxtSplash,
										true
									);

									soloTimeTxtSplash.destroy();
								}
							}
						);
					}
				);

				soloTimeTxtSplash.scale.set(0.75, 0.75);
				soloTimeTxtSplash.camera = PlayState.instance.camHUD;
				soloTimeTxtSplash.zIndex = 1;

				soloTimeTxtSplash.screenCenter(0x10);
				soloTimeTxtSplash.x = -120;

				soloTimeTxtSplash.animation.timeScale = 1 / MULTI_SHIT;
				soloTimeTxtSplash.animation.play("anim", true);

				soloTimeTxtSplash.angle = FlxG.random.float(-2, 2);

				FlxTween.tween(
					soloTimeTxtSplash,
					{
						x: soloTimeTxtSplash.x + 20,
						angle: 0
					},
					1 * MULTI_SHIT,
					{
						ease: FlxEase.cubeOut
					}
				);

				createCoolBackLine(100, 0, 140, -180, 300);
				createCoolBackLine(350, 0, 60, -180, 650);
				createCoolBackLine(560, 0, 15, -180, 950);

				createBlackLine(
					-(FlxG.height / 4),
					-(FlxG.height / 6)
				);

				createBlackLine(
					FlxG.height,
					FlxG.height - (FlxG.height / 8)
				);
				
						var playerIndex:Int = PlayState.instance.members.indexOf(
					PlayState.instance.playerStrumline
				);

				PlayState.instance.insert(
					playerIndex,
					soloTimeTxtSplash
				);
			}
		}
	}

	function createBlackLine(
		yPos:Float,
		targetY:Float
	):FunkinSprite
	{
		var blackLine = new FunkinSprite(
			0,
			yPos
		).makeSolidColor(
			FlxG.width,
			Std.int(FlxG.height / 4),
			FlxColor.BLACK
		);

		blackLine.camera = PlayState.instance.camHUD;
		blackLine.alpha = 1;
		blackLine.zIndex = 0;

		var playerIndex:Int = PlayState.instance.members.indexOf(
			PlayState.instance.playerStrumline
		);

		PlayState.instance.insert(
			playerIndex,
			blackLine
		);

		FlxTween.tween(
			blackLine,
			{y: targetY},
			10 / 24 * MULTI_SHIT,
			{
				startDelay: 4 / 24 * MULTI_SHIT,
				ease: FlxEase.quadOut,

				onComplete: function(_)
				{
					FlxTween.tween(
						blackLine,
						{y: yPos},
						10 / 24 * MULTI_SHIT,
						{
							startDelay: 30 / 24 * MULTI_SHIT,
							ease: FlxEase.quadOut,

							onComplete: function(_)
							{
								PlayState.instance.remove(
									blackLine,
									true
								);

								blackLine.destroy();
							}
						}
					);
				}
			}
		);

		return blackLine;
	}

	function createCoolBackLine(
		xPos:Float,
		zIndex:Int,
		scaleX:Float,
		moveAmount:Float,
		moveEnd:Float
	):Void
	{
		var coolBackLine = new FunkinSprite(
			xPos,
			-100
		).makeSolidColor(
			1,
			Std.int(FlxG.height * 1.75),
			FlxColor.BLACK
		);

		coolBackLine.camera = PlayState.instance.camHUD;
		coolBackLine.angle = -20;
		coolBackLine.zIndex = zIndex;

		coolBackLine.scale.x = 0.001;
		coolBackLine.updateHitbox();

		var playerIndex:Int = PlayState.instance.members.indexOf(
			PlayState.instance.playerStrumline
		);

		PlayState.instance.insert(
			playerIndex,
			coolBackLine
		);

		FlxTween.tween(
			coolBackLine.scale,
			{x: scaleX},
			9 / 24 * MULTI_SHIT,
			{
				startDelay: OFFSET,
				ease: FlxEase.quadOut
			}
		);

		FlxTween.tween(
			coolBackLine,
			{
				x: coolBackLine.x - moveAmount
			},
			10 / 24 * MULTI_SHIT,
			{
				startDelay: OFFSET,
				ease: FlxEase.quadOut
			}
		);

		FlxTween.tween(
			coolBackLine.scale,
			{x: 0.0},
			9 / 24 * MULTI_SHIT,
			{
				startDelay:
					38 / 24 * MULTI_SHIT + OFFSET,
				ease: FlxEase.quadOut
			}
		);

		FlxTween.tween(
			coolBackLine,
			{
				x: coolBackLine.x + moveEnd
			},
			10 / 24 * MULTI_SHIT,
			{
				startDelay:
					38 / 24 * MULTI_SHIT + OFFSET,
				ease: FlxEase.quadOut,

				onComplete: function(_)
				{
					PlayState.instance.remove(
						coolBackLine,
						true
					);

					coolBackLine.destroy();
				}
			}
		);
	}
}