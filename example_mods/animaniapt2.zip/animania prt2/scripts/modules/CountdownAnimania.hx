import funkin.modding.module.Module;
import funkin.play.PlayState;
import flixel.util.FlxTimer;
import flixel.FlxSprite;
import funkin.Paths;
import flixel.tweens.FlxTween;
import flixel.tweens.FlxEase;
import funkin.Conductor;

class CountdownAnimaniaModule extends Module
{
	var customCountdownSongs:Array<String> = [
		"dad-beast",
		"cocoa-amtake",
		"eggnog-amtake",
		"bopeebo-amtake",
		"fresh-amtake"
	];

	var countdownIndex:Int = 0;
	var countdownNumbers:Array<String> = ["3", "2", "1", "go"];

	var customSprites:Array<FlxSprite> = [];

	var currentTimer:FlxTimer = null;

	var isRunning:Bool = false;
	var isGoAnimating:Bool = false;
	var isPaused:Bool = false;

	var pausedRemainingTime:Float = 0;
	var pausedSprite:FlxSprite = null;

	public function new()
	{
		super("CountdownAnimAMTAKEModule");
	}

	function shouldUseCustomCountdown():Bool
	{
		var ps = PlayState.instance;

		if (ps == null || ps.currentSong == null)
			return false;

		return customCountdownSongs.contains(ps.currentSong.id);
	}

	function getBeatDuration():Float
	{
		if (Conductor.instance != null
			&& Conductor.instance.beatLengthMs != null
			&& Conductor.instance.beatLengthMs > 0)
		{
			return Conductor.instance.beatLengthMs / 1000;
		}

		return 0.5;
	}

	function cleanupSprite(sprite:FlxSprite):Void
	{
		if (sprite == null)
			return;

		customSprites.remove(sprite);
	}

	function cancelCurrentTimer():Void
	{
		if (currentTimer != null)
		{
			currentTimer.cancel();
			currentTimer = null;
		}
	}

	function resetCountdown():Void
	{
		cancelCurrentTimer();

		countdownIndex = 0;

		for (sprite in customSprites)
		{
			if (sprite != null)
			{
				FlxTween.cancelTweensOf(sprite);

				if (sprite.scale != null)
					FlxTween.cancelTweensOf(sprite.scale);

				if (sprite.exists)
					sprite.destroy();
			}
		}

		customSprites = [];

		pausedSprite = null;
		pausedRemainingTime = 0;
	}

	/**
	 * Reproduce directamente la animación de countdown de GF.
	 * Esto evita depender de AnimateAtlasCharacter.onCountdownStep().
	 */
	function playGFCountdownAnimation(anim:String):Void
	{
		var ps = PlayState.instance;

		if (ps == null || ps.currentStage == null)
			return;

		var gf = ps.currentStage.getGirlfriend();

		if (gf == null)
			return;

		gf.playAnimation(anim, true, false, false);
	}

	override function onSongLoaded(event:Dynamic):Void
	{
		super.onSongLoaded(event);

		if (shouldUseCustomCountdown())
		{
			Paths.getSparrowAtlas(
				"ui/countdown/COUNTDOWN",
				"shared"
			);
		}
	}

	override function onCountdownStart(event:Dynamic):Void
	{
		super.onCountdownStart(event);

		if (!shouldUseCustomCountdown())
			return;

		isRunning = true;
		isGoAnimating = false;
		isPaused = false;

		resetCountdown();

		countdownIndex = 0;

		var ps = PlayState.instance;

		if (ps == null)
			return;

		/*
		 * Ocultamos el countdown original del engine.
		 */
		if (ps.countdownSprites != null)
		{
			for (sprite in ps.countdownSprites)
			{
				if (sprite != null)
					sprite.visible = false;
			}
		}

		/*
		 * 3
		 */
		playGFCountdownAnimation("count3");
		showNumber("3", false);

		currentTimer = new FlxTimer().start(
			getBeatDuration(),
			function(_)
			{
				if (!isPaused && isRunning)
				{
					/*
					 * 2
					 */
					playGFCountdownAnimation("count2");
					showNumber("2", false);

					currentTimer = new FlxTimer().start(
						getBeatDuration(),
						function(_)
						{
							if (!isPaused && isRunning)
							{
								/*
								 * 1
								 */
								playGFCountdownAnimation("count1");
								showNumber("1", false);

								currentTimer = new FlxTimer().start(
									getBeatDuration(),
									function(_)
									{
										if (!isPaused && isRunning)
										{
											/*
											 * GO
											 */
											playGFCountdownAnimation("cheer");
											showNumber("go", true);
										}
									}
								);
							}
						}
					);
				}
			}
		);
	}

	function showNumber(number:String, isGo:Bool):Void
	{
		var ps = PlayState.instance;

		if (ps == null)
			return;

		if (!shouldUseCustomCountdown())
			return;

		var prefix:String = switch (number)
		{
			case "3":
				"count3";

			case "2":
				"count2";

			case "1":
				"count1";

			case "go":
				"countgo";

			default:
				return;
		};

		var sprite = new FlxSprite();

		sprite.frames = Paths.getSparrowAtlas(
			"ui/countdown/COUNTDOWN",
			"shared"
		);

		sprite.animation.addByPrefix(
			"count",
			prefix,
			24,
			false
		);

		sprite.animation.play("count", true);

		sprite.scrollFactor.set(0, 0);

		sprite.cameras = [ps.camHUD];

		sprite.scale.set(0.75, 0.75);

		sprite.updateHitbox();

		sprite.screenCenter();

		sprite.zIndex = 999999;

		/*
		 * Ajuste especial para el escenario
		 * xMasCityMallAmTake.
		 */
		if (ps.currentStage != null
			&& ps.currentStage.id != null
			&& ps.currentStage.id.indexOf("xMasCityMallAmTake") >= 0)
		{
			sprite.x -= 280;
		}

		ps.add(sprite);

		customSprites.push(sprite);

		/*
		 * Animación especial de GO.
		 */
		if (isGo)
		{
			isGoAnimating = true;
			isRunning = false;

			currentTimer = new FlxTimer().start(
				0.8,
				function(_)
				{
					if (isPaused)
						return;

					if (sprite == null || !sprite.exists)
					{
						isGoAnimating = false;
						return;
					}

					FlxTween.tween(
						sprite,
						{
							angle: -120,
							alpha: 0
						},
						0.7,
						{
							ease: FlxEase.backIn,

							onComplete: function(_)
							{
								if (sprite != null)
								{
									FlxTween.cancelTweensOf(sprite);

									if (sprite.scale != null)
										FlxTween.cancelTweensOf(sprite.scale);
								}

								if (sprite != null && sprite.exists)
								{
									cleanupSprite(sprite);
									sprite.destroy();
								}

								isGoAnimating = false;
							}
						}
					);

					FlxTween.tween(
						sprite.scale,
						{
							x: 0.4,
							y: 0.4
						},
						0.7,
						{
							ease: FlxEase.backIn
						}
					);
				}
			);
		}
		else
		{
			/*
			 * Animación de 3, 2 y 1.
			 */
			currentTimer = new FlxTimer().start(
				getBeatDuration(),
				function(_)
				{
					if (isPaused)
						return;

					if (sprite != null && sprite.exists)
					{
						FlxTween.tween(
							sprite,
							{
								alpha: 0
							},
							0.1,
							{
								ease: FlxEase.quadOut,

								onComplete: function(_)
								{
									if (sprite != null && sprite.exists)
									{
										FlxTween.cancelTweensOf(sprite);

										cleanupSprite(sprite);
										sprite.destroy();
									}
								}
							}
						);
					}
				}
			);
		}
	}

	/**
	 * Permite que CountDownEvent.hx controle
	 * manualmente cada paso del countdown.
	 */
	public function playCustomCountdownStep(step:String):Void
	{
		if (!shouldUseCustomCountdown())
			return;

		cancelCurrentTimer();

		for (sprite in customSprites)
		{
			if (sprite != null)
			{
				FlxTween.cancelTweensOf(sprite);

				if (sprite.scale != null)
					FlxTween.cancelTweensOf(sprite.scale);

				if (sprite.exists)
					sprite.destroy();
			}
		}

		customSprites = [];

		isRunning = true;
		isGoAnimating = false;

		switch (step.toLowerCase())
		{
			case "3":
				playGFCountdownAnimation("count3");
				showNumber("3", false);

			case "2":
				playGFCountdownAnimation("count2");
				showNumber("2", false);

			case "1":
				playGFCountdownAnimation("count1");
				showNumber("1", false);

			case "go":
				playGFCountdownAnimation("cheer");
				showNumber("go", true);

			case "after":
				isRunning = false;

				for (sprite in customSprites)
				{
					if (sprite != null && sprite.exists)
					{
						FlxTween.cancelTweensOf(sprite);

						if (sprite.scale != null)
							FlxTween.cancelTweensOf(sprite.scale);

						sprite.destroy();
					}
				}

				customSprites = [];
		}
	}

	override function onCountdownEnd(event:Dynamic):Void
	{
		super.onCountdownEnd(event);

		if (!isGoAnimating)
		{
			isRunning = false;
			resetCountdown();
		}

		var ps = PlayState.instance;

		if (ps != null && ps.countdownSprites != null)
		{
			for (sprite in ps.countdownSprites)
			{
				if (sprite != null)
					sprite.visible = true;
			}
		}
	}

	override function onSongRetry(event:Dynamic):Void
	{
		super.onSongRetry(event);

		isRunning = false;
		isGoAnimating = false;
		isPaused = false;

		resetCountdown();
	}

	override function onPause(event:Dynamic):Void
	{
		super.onPause(event);

		if (!isRunning && !isGoAnimating)
			return;

		isPaused = true;

		if (customSprites.length > 0)
			pausedSprite = customSprites[customSprites.length - 1];

		if (currentTimer != null)
		{
			pausedRemainingTime = currentTimer.timeLeft;

			currentTimer.cancel();

			currentTimer = null;
		}
	}

	override function onResume(event:Dynamic):Void
	{
		super.onResume(event);

		if (!isPaused)
			return;

		isPaused = false;

		if (pausedSprite != null && pausedSprite.exists)
		{
			FlxTween.cancelTweensOf(pausedSprite);

			if (pausedSprite.scale != null)
				FlxTween.cancelTweensOf(pausedSprite.scale);

			pausedSprite.alpha = 0;

			pausedSprite.destroy();
		}

		pausedSprite = null;

		if (pausedRemainingTime > 0)
		{
			currentTimer = new FlxTimer().start(
				pausedRemainingTime,
				function(_)
				{
					if (!isPaused)
					{
						isRunning = false;
					}
				}
			);

			pausedRemainingTime = 0;
		}
	}
}