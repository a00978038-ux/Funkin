import flixel.FlxG;
import flixel.FlxSprite;
import flixel.group.FlxSpriteGroup;

import funkin.Paths;
import funkin.graphics.FunkinSprite;
import funkin.modding.module.Module;
import funkin.ui.title.TitleState;

class AnimaniaTitleScreen extends Module
{
	var titleStateRef:TitleState = null;

	var voidGradient:FlxSprite = null;

	var propsGroup:FlxSpriteGroup = null;
	var greenRing:FlxSprite = null;

	var fallingProps:Array<FlxSprite> = [];
	var propSpeeds:Array<Float> = [];
	var propDrifts:Array<Float> = [];

	// Velocidad vertical aleatoria de los props.
	// Sube estos valores si quieres que vayan todavía más rápido.
	static inline var PROP_MIN_SPEED:Float = 250;
	static inline var PROP_MAX_SPEED:Float = 750;

	var fallBF:FlxSprite = null;
	var fallGF:FlxSprite = null;

	var fallBFBaseY:Float = 0;
	var fallGFBaseY:Float = 0;

	var floatTime:Float = 0;

	static inline var FLOAT_DISTANCE:Float = 18;
	static inline var FLOAT_SPEED:Float = 1.6;

	var logoTV:FunkinSprite = null;

	var customElementsShown:Bool = false;



	public function new()
	{
		super("AnimaniaTitleScreen", 1000);
	}


	override function onStateChangeEnd(event)
	{
		super.onStateChangeEnd(event);

		if (!(event.targetState is TitleState))
			return;

		titleStateRef = cast event.targetState;

		customElementsShown = false;

		hideOriginalGFAndLogo();
		updateOriginalTitleTextAlpha();

		/*
		 * No creamos nada aquí.
		 * Esperamos a que TitleState muestre su logo original.
		 */
	}


	// =========================================================
	// OCULTAR SOLO GF Y LOGO ORIGINALES
	// =========================================================

	function hideOriginalGFAndLogo():Void
	{
		if (titleStateRef == null)
			return;

		if (titleStateRef.gfDance != null)
		{
			titleStateRef.gfDance.visible = false;
			titleStateRef.gfDance.alpha = 0;
		}

		if (titleStateRef.logoBl != null)
		{
			/*
			 * IMPORTANTE:
			 *
			 * NO ponemos visible = false.
			 *
			 * TitleState puede seguir cambiando su estado `visible`
			 * normalmente. Nosotros solamente lo hacemos invisible
			 * visualmente con alpha = 0.
			 *
			 * Así podemos detectar exactamente cuándo el logo
			 * original aparece después de la intro.
			 */
			titleStateRef.logoBl.alpha = 0;
		}
	}


	function isOriginalLogoReady():Bool
	{
		if (titleStateRef == null)
			return false;

		if (titleStateRef.logoBl == null)
			return false;

		if (!titleStateRef.logoBl.exists)
			return false;

		/*
		 * El logo original sigue siendo invisible porque su
		 * alpha está en 0, pero conservamos su propiedad
		 * `visible` original como señal.
		 */
		return titleStateRef.logoBl.visible;
	}



	function isIntroTextActive():Bool
	{
		if (titleStateRef == null)
			return false;

		if (titleStateRef.credGroup == null)
			return false;

		return
			titleStateRef.members.indexOf(
				titleStateRef.credGroup
			) != -1;
	}


	function updateOriginalTitleTextAlpha():Void
	{
		if (titleStateRef == null)
			return;

		if (titleStateRef.titleText == null)
			return;

		/*
		 * PRESS ENTER / titleText:
		 *
		 * - Alpha 0 desde el inicio.
		 * - Sigue en alpha 0 mientras exista la introText.
		 * - Cuando la introText desaparece, vuelve a alpha 1.
		 */
		if (isIntroTextActive())
		{
			titleStateRef.titleText.alpha = 0;
		}
		else
		{
			titleStateRef.titleText.alpha = 1;
			titleStateRef.titleText.visible = true;
		}
	}


	// =========================================================
	// CREAR TODO DESPUÉS DE LA INTRO
	// =========================================================

	function createCustomElements():Void
	{
		if (titleStateRef == null)
			return;

		if (customElementsShown)
			return;

		customElementsShown = true;

		createVoidGradient();
		createPropsGroup();
		createFallBF();
		createFallGF();
		createLogoTV();

		ensureCustomElements();
		enforceDrawOrder();
	}


	// =========================================================
	// VOID GRADIENT
	// =========================================================

	function createVoidGradient():Void
	{
		if (titleStateRef == null)
			return;

		voidGradient = new FlxSprite(0, 0);

		voidGradient.loadGraphic(
			Paths.image("title/void gradient")
		);

		voidGradient.setGraphicSize(
			FlxG.width,
			625
		);

		voidGradient.updateHitbox();

		voidGradient.x = 0;
		voidGradient.y = FlxG.height - voidGradient.height;

		voidGradient.alpha = 0.75;
		voidGradient.scrollFactor.set(0, 0);

		titleStateRef.add(voidGradient);
	}


	// =========================================================
	// PROPS
	// =========================================================

	function createPropsGroup():Void
	{
		if (titleStateRef == null)
			return;

		propsGroup = new FlxSpriteGroup();

		fallingProps = [];
		propSpeeds = [];
		propDrifts = [];

		titleStateRef.add(propsGroup);

		/*
		 * Todos los props del atlas original.
		 *
		 * Los props entran desde abajo y suben
		 * de forma escalonada.
		 */

		greenRing = addFallingProp(
			"AM green ring fall",
			-76,
			760,
			95,
			10
		);

		addFallingProp(
			"Japanese noodles",
			90,
			880,
			110,
			-7
		);

		addFallingProp(
			"bell",
			285,
			1010,
			125,
			6
		);

		addFallingProp(
			"disk",
			455,
			820,
			100,
			-5
		);

		addFallingProp(
			"kamina glasses",
			650,
			940,
			115,
			8
		);

		addFallingProp(
			"leek",
			815,
			860,
			105,
			-8
		);

		addFallingProp(
			"menu mic",
			980,
			1040,
			120,
			5
		);

		addFallingProp(
			"nenes kunai",
			1130,
			900,
			135,
			-10
		);

		addFallingProp(
			"pear teto",
			1230,
			980,
			112,
			7
		);
	}


	function getRandomPropSpeed():Float
	{
		return
			PROP_MIN_SPEED
			+ Math.random()
			* (PROP_MAX_SPEED - PROP_MIN_SPEED);
	}


	function addFallingProp(
		prefix:String,
		xPos:Float,
		yPos:Float,
		speed:Float,
		drift:Float
	):FlxSprite
	{
		var prop:FlxSprite = new FlxSprite(
			xPos,
			yPos
		);

		prop.frames =
			Paths.getSparrowAtlas(
				"title/props"
			);

		prop.animation.addByPrefix(
			"fall",
			prefix,
			24,
			true
		);

		prop.animation.play(
			"fall",
			true
		);

		prop.scrollFactor.set(0, 0);

		var randomSpeed:Float =
			getRandomPropSpeed();

		/*
		 * En Flixel:
		 * velocity.y NEGATIVA = SUBIR.
		 *
		 * Cada prop recibe una velocidad aleatoria.
		 */
		prop.velocity.y = -randomSpeed;
		prop.velocity.x = drift;
		prop.acceleration.y = 0;
		prop.acceleration.x = 0;

		propsGroup.add(prop);

		fallingProps.push(prop);
		propSpeeds.push(randomSpeed);
		propDrifts.push(drift);

		return prop;
	}


	function updateProps():Void
	{
		if (propsGroup == null)
			return;

		if (fallingProps == null)
			return;

		for (i in 0...fallingProps.length)
		{
			var prop:FlxSprite =
				fallingProps[i];

			if (prop == null)
				continue;

			/*
			 * Fuerza siempre el movimiento hacia ARRIBA.
			 * En Flixel, Y negativa = arriba.
			 */
			prop.velocity.y =
				-Math.abs(
					propSpeeds[i]
				);

			prop.velocity.x =
				propDrifts[i];

			/*
			 * Si sale completamente por ARRIBA,
			 * reaparece por DEBAJO.
			 */
			if (
				prop.y <
				-prop.height - 140
			)
			{
				prop.y =
					FlxG.height
					+ 80
					+ (i * 34);

				prop.x += 287;

				if (
					prop.x >
					FlxG.width + 80
				)
				{
					prop.x -=
						FlxG.width + 160;
				}

				if (
					prop.x <
					-120
				)
				{
					prop.x +=
						FlxG.width + 160;
				}

				prop.animation.play(
					"fall",
					true
				);

				/*
				 * Cada vez que reaparece recibe
				 * una velocidad vertical nueva.
				 */
				propSpeeds[i] =
					getRandomPropSpeed();

				prop.velocity.y =
					-Math.abs(
						propSpeeds[i]
					);

				prop.velocity.x =
					propDrifts[i];
			}
		}
	}


	// =========================================================
	// BF
	// =========================================================

	function createFallBF():Void
	{
		if (titleStateRef == null)
			return;

		fallBF = new FlxSprite();

		fallBF.frames =
			Paths.getSparrowAtlas(
				"title/fallguys"
			);

		fallBF.animation.addByPrefix(
			"fall",
			"bf fall",
			24,
			true
		);

		fallBF.animation.play(
			"fall",
			true
		);

		fallBF.updateHitbox();

		fallBF.x =
			(FlxG.width - fallBF.width) * 0.5
			- FlxG.width / 3;

		fallBF.y =
			(FlxG.height - fallBF.height) * 0.5
			- 100;

		fallBFBaseY = fallBF.y;

		fallBF.scrollFactor.set(0, 0);

		titleStateRef.add(fallBF);
	}


	// =========================================================
	// GF
	// =========================================================

	function createFallGF():Void
	{
		if (titleStateRef == null)
			return;

		fallGF = new FlxSprite();

		fallGF.frames =
			Paths.getSparrowAtlas(
				"title/fallguys"
			);

		fallGF.animation.addByPrefix(
			"fall",
			"gf fall",
			24,
			true
		);

		fallGF.animation.play(
			"fall",
			true
		);

		fallGF.updateHitbox();

		fallGF.x =
			(FlxG.width - fallGF.width) * 0.5
			+ FlxG.width / 3;

		fallGF.y =
			(FlxG.height - fallGF.height) * 0.5
			- 100;

		fallGFBaseY = fallGF.y;

		fallGF.scrollFactor.set(0, 0);

		titleStateRef.add(fallGF);
	}


	// =========================================================
	// LOGO OBJECT
	// =========================================================

	function createLogoTV():Void
	{
		if (titleStateRef == null)
			return;

		logoTV = new FunkinSprite(
			100,
			-200,
			Paths.animateAtlas(
				"title/LOGO_OBJECT"
			)
		);

		logoTV.anim.play(
			"Logolol",
			true
		);

		logoTV.scale.set(
			0.32,
			0.32
		);

		logoTV.updateHitbox();
		logoTV.scrollFactor.set(0, 0);

		titleStateRef.add(logoTV);
	}


	// =========================================================
	// MANTENER ELEMENTOS
	// =========================================================

	function ensureCustomElements():Void
	{
		if (titleStateRef == null)
			return;

		if (!customElementsShown)
			return;

		if (voidGradient != null)
		{
			voidGradient.visible = true;
			voidGradient.exists = true;
			voidGradient.active = true;
			voidGradient.alpha = 0.75;

			if (titleStateRef.members.indexOf(voidGradient) == -1)
				titleStateRef.add(voidGradient);
		}

		if (propsGroup != null)
		{
			propsGroup.visible = true;
			propsGroup.exists = true;
			propsGroup.active = true;
			propsGroup.alpha = 1;

			if (titleStateRef.members.indexOf(propsGroup) == -1)
				titleStateRef.add(propsGroup);
		}

		if (fallBF != null)
		{
			fallBF.visible = true;
			fallBF.exists = true;
			fallBF.active = true;
			fallBF.alpha = 1;

			if (titleStateRef.members.indexOf(fallBF) == -1)
				titleStateRef.add(fallBF);
		}

		if (fallGF != null)
		{
			fallGF.visible = true;
			fallGF.exists = true;
			fallGF.active = true;
			fallGF.alpha = 1;

			if (titleStateRef.members.indexOf(fallGF) == -1)
				titleStateRef.add(fallGF);
		}

		if (logoTV != null)
		{
			logoTV.visible = true;
			logoTV.exists = true;
			logoTV.active = true;
			logoTV.alpha = 1;

			if (titleStateRef.members.indexOf(logoTV) == -1)
				titleStateRef.add(logoTV);
		}
	}


	// =========================================================
	// ORDEN DE DIBUJO
	// =========================================================

	function enforceDrawOrder():Void
	{
		if (titleStateRef == null)
			return;

		if (!customElementsShown)
			return;

		/*
		 * En TitleState es más seguro forzar el orden real
		 * dentro de members que depender de zIndex.
		 *
		 * Orden final:
		 *
		 * fondo/elementos originales
		 * voidGradient
		 * props
		 * BF
		 * GF
		 * LOGO_OBJECT
		 * titleText / PRESS ENTER
		 */

		if (
			voidGradient != null
			&& titleStateRef.members.indexOf(voidGradient) != -1
		)
		{
			titleStateRef.remove(voidGradient, false);
			titleStateRef.add(voidGradient);
		}

		if (
			propsGroup != null
			&& titleStateRef.members.indexOf(propsGroup) != -1
		)
		{
			titleStateRef.remove(propsGroup, false);
			titleStateRef.add(propsGroup);
		}

		if (
			fallBF != null
			&& titleStateRef.members.indexOf(fallBF) != -1
		)
		{
			titleStateRef.remove(fallBF, false);
			titleStateRef.add(fallBF);
		}

		if (
			fallGF != null
			&& titleStateRef.members.indexOf(fallGF) != -1
		)
		{
			titleStateRef.remove(fallGF, false);
			titleStateRef.add(fallGF);
		}

		if (
			logoTV != null
			&& titleStateRef.members.indexOf(logoTV) != -1
		)
		{
			titleStateRef.remove(logoTV, false);
			titleStateRef.add(logoTV);
		}

		if (
			titleStateRef.titleText != null
			&& titleStateRef.members.indexOf(titleStateRef.titleText) != -1
		)
		{
			titleStateRef.remove(
				titleStateRef.titleText,
				false
			);

			titleStateRef.add(
				titleStateRef.titleText
			);
		}
	}


	// =========================================================
	// MOVIMIENTO SUAVE DE BF Y GF
	// =========================================================

	function updateCharacterFloat():Void
	{
		if (fallBF == null && fallGF == null)
			return;

		floatTime += FlxG.elapsed * FLOAT_SPEED;

		if (fallBF != null)
		{
			fallBF.y =
				fallBFBaseY
				+ Math.sin(floatTime)
				* FLOAT_DISTANCE;
		}

		if (fallGF != null)
		{
			/*
			 * GF usa la fase contraria para que el movimiento
			 * se vea más natural y no estén totalmente pegados.
			 */
			fallGF.y =
				fallGFBaseY
				+ Math.sin(floatTime + Math.PI)
				* FLOAT_DISTANCE;
		}
	}


	// =========================================================
	// LOOP INFINITO DEL LOGO
	// =========================================================

	function updateLogoLoop():Void
	{
		if (logoTV == null)
			return;

		if (logoTV.isAnimationFinished())
		{
			logoTV.anim.play(
				"Logolol",
				true
			);
		}
	}


	// =========================================================
	// UPDATE
	// =========================================================

	override function onUpdate(event)
	{
		super.onUpdate(event);

		if (titleStateRef == null)
			return;

		/*
		 * Primero comprobamos el estado NATURAL del logo original.
		 * Su alpha será 0, pero `visible` sigue siendo controlado
		 * por TitleState.
		 */
		var originalLogoReady:Bool = isOriginalLogoReady();

		hideOriginalGFAndLogo();
		updateOriginalTitleTextAlpha();

		/*
		 * Los elementos de Animania aparecen justo cuando
		 * TitleState hace aparecer su logo original.
		 *
		 * El logo original nunca se ve porque alpha = 0.
		 *
		 * No usa beats.
		 * No usa temporizadores.
		 * No usa skippedIntro.
		 */
		if (!customElementsShown)
		{
			/*
			 * Esperamos dos señales:
			 *
			 * 1. TitleState ya hizo visible su logo original.
			 * 2. La introText / credGroup ya desapareció.
			 *
			 * Así los elementos no quedan atrapados debajo
			 * de la intro.
			 */
			if (
				originalLogoReady
				&& !isIntroTextActive()
			)
			{
				createCustomElements();
			}

			return;
		}

		ensureCustomElements();
		enforceDrawOrder();

		updateProps();
		updateCharacterFloat();
		updateLogoLoop();
	}


	// =========================================================
	// LIMPIEZA
	// =========================================================

	override function onStateChangeBegin(event)
	{
		super.onStateChangeBegin(event);

		if (titleStateRef == null)
			return;

		if (logoTV != null)
		{
			titleStateRef.remove(
				logoTV,
				true
			);

			logoTV.destroy();
			logoTV = null;
		}

		if (fallGF != null)
		{
			titleStateRef.remove(
				fallGF,
				true
			);

			fallGF.destroy();
			fallGF = null;
		}

		if (fallBF != null)
		{
			titleStateRef.remove(
				fallBF,
				true
			);

			fallBF.destroy();
			fallBF = null;
		}

		if (propsGroup != null)
		{
			titleStateRef.remove(
				propsGroup,
				true
			);

			propsGroup.destroy();

			propsGroup = null;
			greenRing = null;

			fallingProps = [];
			propSpeeds = [];
			propDrifts = [];
		}

		if (voidGradient != null)
		{
			titleStateRef.remove(
				voidGradient,
				true
			);

			voidGradient.destroy();
			voidGradient = null;
		}

		customElementsShown = false;

		floatTime = 0;
		fallBFBaseY = 0;
		fallGFBaseY = 0;

		titleStateRef = null;
	}
}
