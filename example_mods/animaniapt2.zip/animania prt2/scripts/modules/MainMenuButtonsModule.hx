import funkin.modding.module.Module;
import funkin.ui.mainmenu.MainMenuState;

class MainMenuButtonsModule extends Module
{
    // 100 píxeles hacia la derecha.
    static final MOVE_X:Float = 300;

    var lastState:Dynamic = null;

    function new()
    {
        super("MainMenuButtonsModule");
    }

    override function onStateChangeEnd(event)
    {
        super.onStateChangeEnd(event);

        if (event.targetState is MainMenuState)
        {
            var state = event.targetState;

            // Evita aplicar el desplazamiento dos veces
            // al mismo estado.
            if (lastState == state)
                return;

            lastState = state;

            if (state.menuItems == null)
                return;

            if (state.menuItems.members == null)
                return;

            var members = state.menuItems.members;

            // STORY MODE
            if (members.length > 0 && members[0] != null)
            {
                members[0].x += MOVE_X;
            }

            // FREEPLAY
            if (members.length > 1 && members[1] != null)
            {
                members[1].x += MOVE_X;
            }

            // UPGRADE
            if (members.length > 2 && members[2] != null)
            {
                members[2].x += MOVE_X;
            }

            // CREDITS
            if (members.length > 3 && members[3] != null)
            {
                members[3].x += MOVE_X;
            }

            // optionsButton NO se toca.
        }
        else
        {
            lastState = null;
        }
    }
}