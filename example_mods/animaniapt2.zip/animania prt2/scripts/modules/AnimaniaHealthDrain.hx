import funkin.play.PlayState;
import funkin.modding.module.ScriptedModule;
import funkin.play.PauseSubState;
import funkin.save.Save;
import funkin.util.Constants;

import Std;


/**
 * =========================================================
 * HEALTH DAMAGE
 * =========================================================
 *
 * Canciones compatibles:
 *
 *     dadbattle-amtake
 *     cocoa-amtake
 *     eggnog-amtake
 *
 * La opción aparece ÚNICAMENTE en el menú de pausa
 * mientras se está jugando una de estas canciones.
 *
 * ON  = El oponente drena vida.
 * OFF = El oponente no drena vida.
 *
 * El drenaje nunca puede matar al jugador.
 *
 * Vida mínima:
 *
 *     0.10
 *
 * =========================================================
 */
class DadBeastHealthDrain extends ScriptedModule
{
	/*
	 * =========================================================
	 * CONFIGURACIÓN INTERNA
	 * =========================================================
	 */

	static var OPTION_NAME:String =
		"DadBeastHealthDrain";


	/*
	 * =========================================================
	 * ESTADO
	 * =========================================================
	 */

	var game:PlayState;

	var enabled:Bool = true;


	/*
	 * Vida mínima que puede dejar el drenaje.
	 */

	var minimumHealth:Float = 0.10;


	/*
	 * Multiplicador general del drenaje.
	 *
	 * 1.0 = drenaje normal.
	 */

	var drainMultiplier:Float = 1.0;


	/*
	 * =========================================================
	 * CONSTRUCTOR
	 * =========================================================
	 */

	public function new()
	{
		super("Health Damage");


		/*
		 * Activado por defecto.
		 */

		if (!Save.instance.modOptions.exists(OPTION_NAME))
		{
			Save.instance.modOptions.set(
				OPTION_NAME,
				true
			);

			Save.instance.flush();
		}


		/*
		 * Leer configuración guardada.
		 */

		enabled =
			Save.instance.modOptions.get(
				OPTION_NAME
			);
	}


	/*
	 * =========================================================
	 * SONG LOADED
	 * =========================================================
	 */

	override function onSongLoaded(event)
	{
		super.onSongLoaded(event);


		game =
			PlayState.instance;


		if (game == null)
			return;


		/*
		 * Si la canción no es una de las compatibles,
		 * desactivar este sistema para esta canción.
		 */

		if (!isHealthDrainSong())
		{
			enabled = false;
			return;
		}


		/*
		 * Recuperar configuración guardada.
		 */

		enabled =
			Save.instance.modOptions.get(
				OPTION_NAME
			);
	}


	/*
	 * =========================================================
	 * COMPROBAR CANCIONES COMPATIBLES
	 * =========================================================
	 */

	function isHealthDrainSong():Bool
	{
		if (game == null)
			game = PlayState.instance;


		if (game == null)
			return false;


		if (game.currentSong == null)
			return false;


		var songId:String =
			game.currentSong.id;


		return (
			songId == "dadbattle-amtake" ||
			songId == "cocoa-amtake" ||
			songId == "eggnog-amtake" ||
			songId == "bopeebo-amtake" ||
			songId == "fresh-amtake" ||
			songId == "winter-horrorland-amtake"
		);
	}


	/*
	 * =========================================================
	 * UPDATE
	 * =========================================================
	 */

	override function onUpdate(event)
	{
		super.onUpdate(event);


		/*
		 * No hacer nada fuera de las canciones compatibles.
		 */

		if (!isHealthDrainSong())
			return;


		/*
		 * Leer configuración actual.
		 */

		enabled =
			Save.instance.modOptions.get(
				OPTION_NAME
			);


		if (!enabled)
			return;


		if (game.isGamePaused)
			return;


		/*
		 * Protección adicional.
		 *
		 * El drenaje nunca puede llevar la vida por debajo
		 * de 0.10.
		 */

		if (game.health < minimumHealth)
		{
			game.health =
				minimumHealth;
		}
	}


	/*
	 * =========================================================
	 * NOTA DEL OPONENTE
	 * =========================================================
	 *
	 * Cada nota normal que golpea el oponente provoca drenaje.
	 */

	override function onNoteHit(event)
	{
		super.onNoteHit(event);


		if (!isHealthDrainSong())
			return;


		if (!enabled)
			return;


		if (game == null)
			return;


		if (event.note == null)
			return;


		if (game.isGamePaused)
			return;


		/*
		 * Si la nota pertenece al jugador,
		 * no hacemos nada.
		 */

		if (
			event.note.noteData.getMustHitNote()
		)
		{
			return;
		}


		/*
		 * =====================================================
		 * DRENAJE
		 * =====================================================
		 */

		var drain:Float =
			Constants.HEALTH_SICK_BONUS *
			drainMultiplier;


		var newHealth:Float =
			game.health -
			drain;


		/*
		 * Nunca permitir menos de 0.10.
		 */

		if (
			newHealth <
			minimumHealth
		)
		{
			newHealth =
				minimumHealth;
		}


		game.health =
			newHealth;
	}


	/*
	 * =========================================================
	 * HOLD NOTES
	 * =========================================================
	 *
	 * Mientras el oponente mantenga una nota larga,
	 * la vida baja lentamente.
	 */

	override function onUpdatePost(event)
	{
		super.onUpdatePost(event);


		if (!isHealthDrainSong())
			return;


		if (!enabled)
			return;


		if (game == null)
			return;


		if (game.isGamePaused)
			return;


		var opponentLine =
			game.opponentStrumline;


		if (
			opponentLine == null ||
			opponentLine.holdNotes == null ||
			opponentLine.holdNotes.members == null
		)
		{
			return;
		}


		/*
		 * Revisar las notas sostenidas del oponente.
		 */

		for (
			holdNote
			in opponentLine.holdNotes.members
		)
		{
			if (holdNote == null)
				continue;


			if (
				holdNote.hitNote &&
				!holdNote.missedNote &&
				holdNote.sustainLength > 0
			)
			{
				/*
				 * Drenaje de sostenida.
				 */

				var drain:Float =
					Constants.HEALTH_HOLD_BONUS_PER_SECOND *
					0.8 *
					drainMultiplier *
					event.elapsed;


				var newHealth:Float =
					game.health -
					drain;


				/*
				 * Nunca bajar de 0.10.
				 */

				if (
					newHealth <
					minimumHealth
				)
				{
					newHealth =
						minimumHealth;
				}


				game.health =
					newHealth;


				/*
				 * Solamente procesar una sostenida
				 * por frame.
				 */

				break;
			}
		}
	}


	/*
	 * =========================================================
	 * MENÚ DE PAUSA
	 * =========================================================
	 *
	 * La opción solamente aparece dentro del menú de pausa
	 * de las tres canciones compatibles.
	 */

	override function onSubStateOpenBegin(event)
	{
		var state =
			event.targetState;


		/*
		 * Si no estamos en una canción compatible,
		 * no hacer nada.
		 */

		if (!isHealthDrainSong())
			return;


		/*
		 * Verificar que sea el menú de pausa.
		 */

		if (
			!Std.isOfType(
				state,
				PauseSubState
			)
		)
		{
			return;
		}


		state.persistentUpdate =
			false;


		/*
		 * =====================================================
		 * CONSTRUIR MENÚ
		 * =====================================================
		 */

		state.openCallback = function()
		{
			/*
			 * Obtener entradas actuales.
			 */

			var entries =
				state.currentMenuEntries;


			if (entries == null)
				return;


			/*
			 * =================================================
			 * ELIMINAR DUPLICADOS
			 * =================================================
			 */

			var cleanEntries:Array<Dynamic> =
				[];


			for (entry in entries)
			{
				if (entry == null)
					continue;


				var text:String =
					Std.string(
						entry.text
					);


				if (
					text.indexOf(
						"Health Damage:"
					) != -1
				)
				{
					continue;
				}


				cleanEntries.push(
					entry
				);
			}


			entries =
				cleanEntries;


			/*
			 * =================================================
			 * ESTADO ACTUAL
			 * =================================================
			 */

			var currentEnabled:Bool =
				Save.instance.modOptions.get(
					OPTION_NAME
				);


			var status:String =
				currentEnabled
				? "ON"
				: "OFF";


			/*
			 * =================================================
			 * CREAR OPCIÓN
			 * =================================================
			 */

			var drainEntry =
			{
				text:
					"Health Damage: < "
					+ status
					+ " >",


				callback: function()
				{
					/*
					 * Leer estado actual.
					 */

					var current:Bool =
						Save.instance.modOptions.get(
							OPTION_NAME
						);


					/*
					 * Cambiar ON/OFF.
					 */

					current =
						!current;


					/*
					 * Guardar.
					 */

					Save.instance.modOptions.set(
						OPTION_NAME,
						current
					);


					Save.instance.flush();


					/*
					 * Actualizar estado interno.
					 */

					enabled =
						current;


					/*
					 * Volver a abrir el menú de pausa
					 * para actualizar el texto.
					 */

					var freshPause =
						new PauseSubState();


					freshPause.camera =
						PlayState.instance.camCutscene;


					PlayState.instance.openSubState(
						freshPause
					);
				}
			};


			/*
			 * =================================================
			 * BUSCAR RESTART SONG
			 * =================================================
			 */

			var restartIndex:Int =
				-1;


			for (
				i in 0...entries.length
			)
			{
				if (
					entries[i] == null
				)
				{
					continue;
				}


				var text:String =
					Std.string(
						entries[i].text
					);


				if (
					text ==
					"Restart Song"
				)
				{
					restartIndex =
						i;

					break;
				}
			}


			/*
			 * =================================================
			 * INSERTAR OPCIÓN
			 * =================================================
			 */

			if (
				restartIndex >= 0
			)
			{
				entries.insert(
					restartIndex + 1,
					drainEntry
				);
			}
			else
			{
				entries.push(
					drainEntry
				);
			}


			/*
			 * Aplicar cambios al menú.
			 */

			state.currentMenuEntries =
				entries;


			state.clearAndAddMenuEntries();


			state.changeSelection();
		};


		super.onSubStateOpenBegin(event);
	}


	/*
	 * =========================================================
	 * RETRY
	 * =========================================================
	 */

	override function onSongRetry(event)
	{
		super.onSongRetry(event);


		game =
			PlayState.instance;


		if (!isHealthDrainSong())
			return;


		/*
		 * Recuperar configuración.
		 */

		enabled =
			Save.instance.modOptions.get(
				OPTION_NAME
			);
	}


	/*
	 * =========================================================
	 * DESTROY
	 * =========================================================
	 */

	override function onDestroy()
	{
		game =
			null;

		super.onDestroy();
	}
}