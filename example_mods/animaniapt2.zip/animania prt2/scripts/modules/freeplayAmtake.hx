import funkin.modding.module.Module;
import funkin.util.ReflectUtil;
import flixel.FlxG;
import openfl.utils.Assets;
import funkin.Paths;

class AmtakeFreeplayArtBG extends Module
{
  public function new()
  {
    super("AmtakeFreeplayArtBG", 900);
  }

  // Imagen personalizada para las canciones AMTAKE.
  static inline var AMTAKE_BG_PATH:String = "freeplay/amtake_bg";

  var lastSongId:String = null;
  var originalKey:String = null;
  var usingAlt:Bool = false;


  inline function isFreeplay(sub:Dynamic):Bool
  {
    if (sub == null) return false;

    try
    {
      return ReflectUtil.getClassNameOf(sub) == "funkin.ui.freeplay.FreeplayState";
    }
    catch (_:Dynamic) {}

    return false;
  }


  inline function isAmtakeSong(id:String):Bool
  {
    if (id == null) return false;

    var songId = id.toLowerCase();

    return songId == "dadbattle-amtake"
        || songId == "fresh-amtake"
        || songId == "bopeebo-amtake"
        || songId == "cocoa-amtake"
        || songId == "eggnog-amtake"
        || songId == "winter-horrorland-amtake";
  }


  function getSelectedSongId(sub:Dynamic):String
  {
    if (sub == null) return null;

    var idx:Int = -1;

    try
    {
      idx = sub.curSelected;
    }
    catch (_:Dynamic) {}

    var grp:Dynamic = null;

    try
    {
      grp = sub.grpCapsules;
    }
    catch (_:Dynamic) {}

    if (grp == null) return null;
    if (grp.members == null) return null;

    if (idx < 0) return null;
    if (idx >= grp.members.length) return null;

    var cap:Dynamic = null;

    try
    {
      cap = grp.members[idx];
    }
    catch (_:Dynamic) {}

    if (cap == null) return null;

    var song:Dynamic = null;

    try
    {
      song = cap.freeplayData?.data;
    }
    catch (_:Dynamic) {}

    if (song == null) return null;
    if (song.id == null) return null;

    return Std.string(song.id).toLowerCase();
  }


  /*
   * IMPORTANTE:
   *
   * Antes se utilizaba loadTextureAsync().
   *
   * En Mobile podía quedar una carga pendiente justo cuando
   * Freeplay estaba siendo destruido al salir rápidamente.
   *
   * Ahora usamos solamente loadGraphic().
   */
  function loadSpriteGraphicSafe(sp:Dynamic, assetId:String):Bool
  {
    if (sp == null) return false;
    if (assetId == null) return false;

    try
    {
      sp.loadGraphic(assetId);
      return true;
    }
    catch (_:Dynamic) {}

    return false;
  }


  /*
   * Cuando Freeplay termina de cerrarse NO intentamos
   * modificar backingImage.
   *
   * En este punto Freeplay puede estar destruyendo sus
   * sprites y acceder a backingImage puede causar una
   * salida del juego sin Script Exception.
   */
  override function onSubStateCloseEnd(e):Void
  {
    lastSongId = null;
    originalKey = null;
    usingAlt = false;
  }


  override function onUpdate(e):Void
  {
    var st = FlxG.state;

    if (st == null) return;

    var sub:Dynamic = null;

    try
    {
      sub = st.subState;
    }
    catch (_:Dynamic) {}

    if (sub == null) return;
    if (!isFreeplay(sub)) return;


    var songId:String = getSelectedSongId(sub);

    if (songId == null) return;

    if (songId == lastSongId) return;

    lastSongId = songId;


    var backing:Dynamic = null;

    try
    {
      backing = sub.backingImage;
    }
    catch (_:Dynamic) {}

    if (backing == null) return;


    /*
     * Guardamos el fondo original únicamente mientras
     * esta instancia de Freeplay siga viva.
     */
    if (originalKey == null)
    {
      try
      {
        if (backing.graphic != null)
        {
          originalKey = backing.graphic.assetsKey;
        }
      }
      catch (_:Dynamic) {}
    }


    var altId:String = Paths.image(AMTAKE_BG_PATH);


    // ==========================================
    // CANCIONES AMTAKE
    // ==========================================

    if (isAmtakeSong(songId))
    {
      if (!Assets.exists(altId)) return;


      var curKey:String = null;

      try
      {
        if (backing.graphic != null)
        {
          curKey = backing.graphic.assetsKey;
        }
      }
      catch (_:Dynamic) {}


      if (curKey != altId || !usingAlt)
      {
        if (loadSpriteGraphicSafe(backing, altId))
        {
          usingAlt = true;
        }
      }

      return;
    }


    // ==========================================
    // CANCIONES NORMALES
    // ==========================================

    restoreIfNeeded(sub);
  }


  function restoreIfNeeded(sub:Dynamic):Void
  {
    if (!usingAlt) return;
    if (sub == null) return;


    var backing:Dynamic = null;

    try
    {
      backing = sub.backingImage;
    }
    catch (_:Dynamic) {}

    if (backing == null)
    {
      usingAlt = false;
      return;
    }


    /*
     * Restauramos únicamente mientras Freeplay sigue
     * abierto y backingImage todavía existe.
     */
    if (originalKey != null && Assets.exists(originalKey))
    {
      loadSpriteGraphicSafe(backing, originalKey);
    }
    else
    {
      try
      {
        sub.switchBackingImage(null);
      }
      catch (_:Dynamic) {}
    }


    usingAlt = false;
  }
}