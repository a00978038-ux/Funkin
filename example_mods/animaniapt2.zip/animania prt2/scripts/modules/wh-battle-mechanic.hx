import funkin.modding.module.Module;
import funkin.play.PlayState;
import funkin.graphics.FunkinSprite;
import funkin.Paths;
import funkin.Conductor;
import funkin.audio.FunkinSound;

import flixel.FlxG;
import flixel.tweens.FlxTween;
import flixel.tweens.FlxEase;

class WinterHorrorlandAmtakeBattleModule extends Module
{
	var game:PlayState = null;

	var keyboardInputMode:Bool = false;

	var mode:String = "dodge";

	static inline var DODGE_MISS_DAMAGE:Float = 0.40;

	var parryHealPending:Bool = false;
	var parryHealTime:Float = 0;
	static inline var PARRY_HEAL:Float = 0.45;

	var healthSucked:Float = 1.0;
	static inline var HEALTH_MAX:Float = 2.0;

	var pendingHealthUnlock:Float = 0;
	var healthUnlockTween:FlxTween = null;

	var DOT_SPEED:Float = 1.0;
	var DOT_OFFSET:Float = 180;

	var DOT_Z_INDEX:Int = 1650;
	var FINAL_STRIPE_Z_INDEX:Int = 1750;
	var POSITION_OFFSET:Float = 26;

	var FINAL_PRE_WINDOW:Float = 0.65;
	var FINAL_POST_WINDOW:Float = 0.50;

	var uiCross:FunkinSprite = null;
	var battleSplash:FunkinSprite = null;

	var focusedIcon:Dynamic = null;
	var iconMoveTween:FlxTween = null;
	var iconReturning:Bool = false;
	var tentacleLeft:Dynamic = null;
	var tentacleRight:Dynamic = null;
	var tentacleSide:String = "Left";

	var snowman:Dynamic = null;
	var snowmanReturnPending:Bool = false;
	var snowmanReturnTime:Float = 0;

	var songHadStarted:Bool = false;

	var opponentHitPending:Bool = false;
	var opponentHitTime:Float = 0;
	var opponentReleaseTime:Float = 0;

	var opponentIconFlickerActive:Bool = false;
	var opponentIconFlickerStart:Float = 0;
	var opponentIconFlickerEnd:Float = 0;
	var opponentIconFlickerNextToggle:Float = 0;
	var opponentIconFlickerPhase:Int = 0;

	var iconOriginalX:Float = 0;
	var iconOriginalY:Float = 0;
	var iconOriginalAngle:Float = 0;
	var iconOriginalWidth:Float = 0;
	var iconOriginalHeight:Float = 0;

	var iconP1StartX:Float = 0;
	var iconP1StartY:Float = 0;
	var iconP1StartAngle:Float = 0;
	var iconP1StartCaptured:Bool = false;

	var dodgeCameraActive:Bool = false;
	var dodgeCameraBaseX:Float = 0;
	var dodgeCameraBaseY:Float = 0;
	var dodgeCameraTargetX:Float = 0;
	var dodgeCameraTargetY:Float = 0;

	var dodgeCameraStartZoom:Float = 1;
	var dodgeCameraTargetZoom:Float = 1;

	var dodgeCameraStartAngle:Float = 0;
	var dodgeCameraElapsed:Float = 0;

	var currentBattleEventIndex:Int = -1;
	var dodgeTripleActive:Bool = false;
	var dodgeTripleStartIndex:Int = -1;
	var dodgeTripleEndIndex:Int = -1;

	var activeDots:Array<FunkinSprite> = [];
	var activeStripes:Array<FunkinSprite> = [];

	var mechanicActive:Bool = false;

	var eventBeats:Int = 0;
	var currentBeatInEvent:Int = 0;
	var eventStartBeat:Float = 0;

	var canHitFinal:Bool = false;
	var finalResultGiven:Bool = false;

	var targetFinalTime:Float = 0;

	var currentEventYah:Bool = false;

	var boyfriendHitBlinking:Bool = false;
	var boyfriendHitBlinkWaiting:Bool = false;
	var boyfriendHitBlinkStartTime:Float = 0;
	var boyfriendHitBlinkEndTime:Float = 0;
	var boyfriendHitNextToggleTime:Float = 0;
	var boyfriendHitBlinkVisible:Bool = true;
	var boyfriendHitBlinkPhase:Int = 0;

	var boyfriendMissHitPending:Bool = false;
	var boyfriendMissHitTime:Float = 0;

	var tentacleAttackPending:Bool = false;
	var tentacleAttackTime:Float = 0;

	var boyfriendAttackHoldPending:Bool = false;
	var boyfriendAttackReleaseTime:Float = 0;

	var battleEventTimes:Array<Float> = [
		32641.5094339623,
		34056.6037735849,
		35566.0377358491,
		58396.2264150943,
		67830.1886792453,
		69528.3018867925,
		70283.0188679245,
		71981.1320754717,
		74245.2830188679,
		75566.0377358491,
		76320.7547169811,
		79528.3018867925,
		93113.2075471698,
		94433.9622641509,
		95943.9622641509,
		106698.113207547
	];

	var battleEventTypes:Array<Int> = [
		0,
		0,
		0,
		1,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		1,
		0,
		0,
		0,
		1
	];

	var battleEventBeats:Array<Int> = [
		3,
		3,
		3,
		4,
		4,
		1,
		1,
		3,
		3,
		1,
		1,
		4,
		3,
		3,
		3,
		4
	];

	var battleEventTriggered:Array<Bool> = [];

	public function new()
	{
		super("WinterHorrorlandAmtakeBattleModule");
	}

	function isCorrectSong():Bool
	{
		if (PlayState.instance == null)
			return false;

		if (PlayState.instance.currentSong == null)
			return false;

		var id:String = Std.string(PlayState.instance.currentSong.id);

		return id == "winter-horrorland-amtake";
	}

	function isHardDifficulty():Bool
	{
		if (PlayState.instance == null)
			return false;

		return
			Std.string(
				PlayState.instance.currentDifficulty
			) == "hard";
	}

	function isBattleMechanicEnabled():Bool
	{
		return
			isCorrectSong() &&
			isHardDifficulty();
	}

	function syncAMtakeHealthLock():Void
	{
		AMtake.healthSuckedVisual =
			healthSucked;
	}

	function resetLockedHealth():Void
	{
		if (healthUnlockTween != null)
		{
			healthUnlockTween.cancel();
			healthUnlockTween = null;
		}

		pendingHealthUnlock = 0;

		healthSucked = 1.0;
		syncAMtakeHealthLock();
	}

	function clampLockedHealth():Void
	{
		if (game == null)
			return;

		if (healthSucked < 0)
			healthSucked = 0;

		if (healthSucked > HEALTH_MAX)
			healthSucked = HEALTH_MAX;

		var healthLimit:Float =
			HEALTH_MAX -
			healthSucked;

		if (game.health > healthLimit)
			game.health = healthLimit;

		if (game.health < 0)
			game.health = 0;

		syncAMtakeHealthLock();
	}

	function resetBattleEvents():Void
	{
		battleEventTriggered = [];

		currentBattleEventIndex = -1;
		dodgeTripleActive = false;
		dodgeTripleStartIndex = -1;
		dodgeTripleEndIndex = -1;

		for (i in 0...battleEventTimes.length)
		{
			battleEventTriggered.push(false);
		}
	}

	function createMechanic():Void
	{
		if (PlayState.instance == null)
			return;

		if (!isBattleMechanicEnabled())
			return;

		game = PlayState.instance;

		if (
			!iconP1StartCaptured &&
			game.iconP1 != null
		)
		{
			iconP1StartX = game.iconP1.x;
			iconP1StartY = game.iconP1.y;
			iconP1StartAngle = game.iconP1.angle;
			iconP1StartCaptured = true;
		}

		songHadStarted = false;
		resetBattleEvents();
		resetLockedHealth();

		battleSplash = new FunkinSprite();

		battleSplash.frames = Paths.getSparrowAtlas(
			"mechanincs/fighting_splash"
		);

		battleSplash.animation.addByPrefix(
			"splash",
			"splash",
			24,
			false
		);

		battleSplash.camera = game.camHUD;
		battleSplash.zIndex = 1700;

		battleSplash.screenCenter();

		battleSplash.visible = false;

		game.add(battleSplash);

		uiCross = new FunkinSprite();

		uiCross.loadGraphic(
			Paths.image(
				"mechanincs/FIGHTING_UI"
			)
		);

		uiCross.camera = game.camHUD;
		uiCross.zIndex = 2000;

		uiCross.screenCenter();

		uiCross.alpha = 0;

		game.add(uiCross);

		setupTentacles();

		game.refresh();
	}

	function createDot():FunkinSprite
	{
		var dot:FunkinSprite = new FunkinSprite();

		dot.loadGraphic(
			Paths.image(
				"mechanincs/beat-dot"
			)
		);

		dot.camera = game.camHUD;
		dot.zIndex = DOT_Z_INDEX;

		dot.visible = false;
		dot.active = false;
		dot.alpha = 0.5;

		game.add(dot);

		return dot;
	}

	function createStripe():FunkinSprite
	{
		var stripe:FunkinSprite = new FunkinSprite();

		stripe.loadGraphic(
			Paths.image(
				"mechanincs/beat-stripe"
			)
		);

		stripe.camera = game.camHUD;
		stripe.zIndex = FINAL_STRIPE_Z_INDEX;

		stripe.visible = false;
		stripe.active = false;

		game.add(stripe);

		return stripe;
	}

	function spawnDotPair():Void
	{
		if (game == null)
			return;

		if (uiCross == null)
			return;

		var crossCenterX:Float =
			uiCross.x +
			uiCross.width / 2;

		var crossCenterY:Float =
			uiCross.y +
			uiCross.height / 2;

		var dot1:FunkinSprite = createDot();

		dot1.x =
			crossCenterX -
			DOT_OFFSET * 2;

		dot1.y =
			crossCenterY -
			dot1.height / 2;

		dot1.visible = true;
		dot1.active = true;
		dot1.alpha = 0;

		activeDots.push(dot1);

		FlxTween.tween(
			dot1,
			{alpha: 0.5},
			0.15,
			{ease: FlxEase.quadOut}
		);

		var dot2:FunkinSprite = createDot();

		dot2.x =
			crossCenterX +
			DOT_OFFSET * 1.8;

		dot2.y =
			crossCenterY -
			dot2.height / 2;

		dot2.visible = true;
		dot2.active = true;
		dot2.alpha = 0;

		activeDots.push(dot2);

		FlxTween.tween(
			dot2,
			{alpha: 0.5},
			0.15,
			{ease: FlxEase.quadOut}
		);

		var targetX1:Float =
			crossCenterX -
			dot1.width / 2;

		var targetY1:Float =
			crossCenterY -
			dot1.height / 2;

		var targetX2:Float =
			crossCenterX -
			dot2.width / 2;

		var targetY2:Float =
			crossCenterY -
			dot2.height / 2;

		var beatDuration:Float =
			60 /
			Conductor.instance.bpm;

		var duration:Float =
			beatDuration *
			DOT_SPEED;

		FlxTween.tween(
			dot1,
			{
				x: targetX1,
				y: targetY1
			},
			duration,
			{
				ease: FlxEase.linear,

				onComplete:
					function(t:FlxTween)
					{
						if (dot1 == null)
							return;

						activeDots.remove(dot1);

						if (game != null)
						{
							game.remove(
								dot1,
								true
							);
						}

						dot1.destroy();
					}
			}
		);

		FlxTween.tween(
			dot2,
			{
				x: targetX2,
				y: targetY2
			},
			duration,
			{
				ease: FlxEase.linear,

				onComplete:
					function(t:FlxTween)
					{
						if (dot2 == null)
							return;

						activeDots.remove(dot2);

						if (game != null)
						{
							game.remove(
								dot2,
								true
							);
						}

						dot2.destroy();
					}
			}
		);

		game.refresh();
	}

	function spawnFinalStripes():Void
	{
		if (game == null)
			return;

		if (uiCross == null)
			return;

		var crossCenterX:Float =
			uiCross.x +
			uiCross.width / 2;

		var crossCenterY:Float =
			uiCross.y +
			uiCross.height / 2;

		var stripe1:FunkinSprite = createStripe();

		stripe1.x =
			crossCenterX -
			DOT_OFFSET * 2.3;

		stripe1.y =
			crossCenterY -
			stripe1.height / 2;

		stripe1.visible = true;
		stripe1.active = true;
		stripe1.alpha = 0;

		activeStripes.push(stripe1);

		FlxTween.tween(
			stripe1,
			{alpha: 1},
			0.1,
			{ease: FlxEase.quadOut}
		);

		var stripe2:FunkinSprite = createStripe();

		stripe2.x =
			crossCenterX +
			DOT_OFFSET * 2.1;

		stripe2.y =
			crossCenterY -
			stripe2.height / 2;

		stripe2.flipX = true;

		stripe2.visible = true;
		stripe2.active = true;
		stripe2.alpha = 0;

		activeStripes.push(stripe2);

		FlxTween.tween(
			stripe2,
			{alpha: 1},
			0.1,
			{ease: FlxEase.quadOut}
		);

		var targetX1:Float =
			crossCenterX -
			stripe1.width / 2;

		var targetY1:Float =
			crossCenterY -
			stripe1.height / 2;

		var targetX2:Float =
			crossCenterX -
			stripe2.width / 2;

		var targetY2:Float =
			crossCenterY -
			stripe2.height / 2;

		var beatDuration:Float =
			60 /
			Conductor.instance.bpm;

		var duration:Float =
			beatDuration *
			(DOT_SPEED * 0.9);

		FlxTween.tween(
			stripe1,
			{
				x: targetX1,
				y: targetY1
			},
			duration,
			{
				ease: FlxEase.linear
			}
		);

		FlxTween.tween(
			stripe2,
			{
				x: targetX2,
				y: targetY2
			},
			duration,
			{
				ease: FlxEase.linear
			}
		);

		targetFinalTime =
			Conductor.instance.songPosition +
			(60000 / Conductor.instance.bpm);

		canHitFinal = true;
		finalResultGiven = false;

		game.refresh();
	}

	function setupSnowman():Void
	{
		snowman = null;

		if (game == null)
			return;

		if (game.currentStage == null)
			return;

		snowman =
			game.currentStage.getNamedProp(
				"snowman"
			);
	}

	function fadeSnowmanForDodge():Void
	{
		if (snowman == null)
			setupSnowman();

		if (snowman == null)
			return;

		snowmanReturnPending = false;
		snowmanReturnTime = 0;

		FlxTween.cancelTweensOf(
			snowman
		);

		FlxTween.tween(
			snowman,
			{alpha: 0.4},
			0.25,
			{
				ease:
					FlxEase.backOut
			}
		);
	}

	function scheduleSnowmanReturn():Void
	{
		if (snowman == null)
			setupSnowman();

		if (snowman == null)
			return;

		snowmanReturnPending = false;
		snowmanReturnTime = 0;

		FlxTween.cancelTweensOf(
			snowman
		);

		FlxTween.tween(
			snowman,
			{alpha: 1},
			0.25,
			{
				startDelay: 0.8,
				ease:
					FlxEase.backOut
			}
		);
	}

	function updateSnowmanReturn():Void
	{
	}

	function resetSnowman():Void
	{
		snowmanReturnPending = false;
		snowmanReturnTime = 0;

		if (snowman == null)
			setupSnowman();

		if (snowman == null)
			return;

		FlxTween.cancelTweensOf(
			snowman
		);

		snowman.alpha = 1;
	}

	function setupTentacles():Void
	{
		tentacleLeft = null;
		tentacleRight = null;

		if (game == null)
			return;

		if (game.currentStage == null)
			return;

		tentacleLeft =
			game.currentStage.getNamedProp(
				"tentacleLeft"
			);

		tentacleRight =
			game.currentStage.getNamedProp(
				"tentacleRight"
			);

		if (tentacleLeft != null)
			tentacleLeft.alpha = 0;

		if (tentacleRight != null)
			tentacleRight.alpha = 0;
	}

	function chooseTentacleSide():Void
	{
		tentacleSide =
			FlxG.random.bool(50)
			? "Left"
			: "Right";
	}

	function playTentacleTick():Void
	{
		if (mode != "dodge")
			return;

		if (
			tentacleLeft == null ||
			tentacleRight == null
		)
		{
			setupTentacles();
		}

		var tentacle:Dynamic = null;

		if (tentacleSide == "Left")
			tentacle = tentacleLeft;
		else
			tentacle = tentacleRight;

		if (tentacle == null)
			return;

		tentacle.alpha = 1;
		tentacle.visible = true;
		tentacle.active = true;

		if (tentacle.animation != null)
		{
			tentacle.animation.play(
				"tick",
				true
			);
		}
	}

	function playTentacleAttack():Void
	{
		if (mode != "dodge")
			return;

		if (
			tentacleLeft == null ||
			tentacleRight == null
		)
		{
			setupTentacles();
		}

		var tentacle:Dynamic = null;

		if (tentacleSide == "Left")
			tentacle = tentacleLeft;
		else
			tentacle = tentacleRight;

		if (tentacle == null)
			return;

		tentacle.alpha = 1;
		tentacle.visible = true;
		tentacle.active = true;

		if (tentacle.animation != null)
		{
			tentacle.animation.play(
				"attack",
				true
			);

			FunkinSound.playOnce(
				Paths.sound(
					"mechanics/tentacle " +
					FlxG.random.int(1, 2)
				)
			);
		}
	}

	function scheduleTentacleAttackAfterFinalBeat():Void
	{
		if (mode != "dodge")
			return;

		tentacleAttackPending = true;

		tentacleAttackTime =
			Conductor.instance.songPosition + 50;
	}


	function updateTentacleAttackAfterFinalBeat():Void
	{
		if (!tentacleAttackPending)
			return;

		if (
			Conductor.instance.songPosition <
			tentacleAttackTime
		)
			return;

		tentacleAttackPending = false;
		tentacleAttackTime = 0;

		playTentacleAttack();
	}


	function scheduleOpponentHit():Void
	{
		opponentHitPending = true;

		opponentHitTime =
			Conductor.instance.songPosition +
			150;

		opponentReleaseTime = 0;
	}

	function updateOpponentHit():Void
	{
		if (game == null)
			return;

		if (game.currentStage == null)
			return;

		var songPos:Float =
			Conductor.instance.songPosition;

		if (
			opponentHitPending &&
			songPos >= opponentHitTime
		)
		{
			startHealthUnlockTween();

			var opponent:Dynamic =
				game.currentStage.getDad();

			if (opponent != null)
			{

				opponent.ignoreExclusionPref = ["hit"];

				opponent.playAnimation(
					"hit",
					true,
					true
				);

				if (game.camGame != null)
				{
					game.camGame.shake(
						0.005,
						0.15
					);
				}

				startOpponentIconFlicker();

				opponentReleaseTime =
					songPos + 300;
			}

			opponentHitPending = false;
			opponentHitTime = 0;
		}

		if (
			opponentReleaseTime > 0 &&
			songPos >= opponentReleaseTime
		)
		{
			var opponent:Dynamic =
				game.currentStage.getDad();

			if (opponent != null)
				opponent.canPlayOtherAnims = true;

			opponentReleaseTime = 0;
		}
	}

	function startOpponentIconFlicker():Void
	{
		if (game == null)
			return;

		var icon:Dynamic = game.iconP2;

		if (icon == null)
			return;

		var songPos:Float = Conductor.instance.songPosition;

		opponentIconFlickerActive = true;
		opponentIconFlickerStart = songPos;
		opponentIconFlickerEnd = songPos + 1500;
		opponentIconFlickerNextToggle = songPos;
		opponentIconFlickerPhase = 0;

		icon.visible = true;
	}

	function updateOpponentIconFlicker():Void
	{
		if (!opponentIconFlickerActive || game == null)
			return;

		var icon:Dynamic = game.iconP2;

		if (icon == null)
		{
			opponentIconFlickerActive = false;
			return;
		}

		var songPos:Float = Conductor.instance.songPosition;

		if (songPos >= opponentIconFlickerEnd)
		{
			icon.visible = true;
			opponentIconFlickerActive = false;
			return;
		}

		var intervalMs:Float =
			songPos < opponentIconFlickerStart + 1000
				? (1000 / 30)
				: (1000 / 60);

		if (songPos >= opponentIconFlickerNextToggle)
		{
			opponentIconFlickerPhase++;
			icon.visible = (opponentIconFlickerPhase % 2) == 0;
			opponentIconFlickerNextToggle = songPos + intervalMs;
		}
	}

	function stopOpponentIconFlicker():Void
	{
		opponentIconFlickerActive = false;
		opponentIconFlickerStart = 0;
		opponentIconFlickerEnd = 0;
		opponentIconFlickerNextToggle = 0;
		opponentIconFlickerPhase = 0;

		if (game != null && game.iconP2 != null)
			game.iconP2.visible = true;
	}

	function moveBattleIconIn(isDodge:Bool):Void
	{
		iconReturning = false;

		if (game == null)
			return;

		if (uiCross == null)
			return;

		if (iconMoveTween != null)
		{
			iconMoveTween.cancel();
			iconMoveTween = null;
		}

		if (isDodge)
			focusedIcon = game.iconP1;
		else
			focusedIcon = game.iconP2;

		if (focusedIcon == null)
			return;

		iconOriginalX = focusedIcon.x;
		iconOriginalY = focusedIcon.y;
		iconOriginalAngle = focusedIcon.angle;
		iconOriginalWidth = focusedIcon.width;
		iconOriginalHeight = focusedIcon.height;

		focusedIcon.autoUpdate = false;

		if (game.healthBarGroup != null)
		{
			game.healthBarGroup.remove(
				focusedIcon,
				false
			);
		}

		focusedIcon.camera = game.camHUD;
		focusedIcon.zIndex = 1800;

		game.add(focusedIcon);
		game.refresh();

		var targetX:Float =
			uiCross.x +
			uiCross.width / 2 -
			focusedIcon.width / 2;

		var targetY:Float =
			uiCross.y +
			uiCross.height / 2 -
			focusedIcon.height / 2;

		focusedIcon.active = false;

		iconMoveTween = FlxTween.tween(
			focusedIcon,
			{
				x: targetX,
				y: targetY,
				angle: 0
			},
			9 / 24,
			{
				ease: FlxEase.quartIn,

				onComplete:
					function(t:FlxTween)
					{
						iconMoveTween = null;
					}
			}
		);
	}

	function moveBattleIconBack():Void
	{
		if (focusedIcon == null)
			return;

		if (iconReturning)
			return;

		iconReturning = true;

		if (iconMoveTween != null)
		{
			iconMoveTween.cancel();
			iconMoveTween = null;
		}

		var iconToRestore:Dynamic = focusedIcon;

		iconMoveTween = FlxTween.tween(
			iconToRestore,
			{
				x: iconOriginalX,
				y: iconOriginalY,
				angle: iconOriginalAngle
			},
			9 / 24,
			{
				ease: FlxEase.quartIn,
				onComplete: function(t:FlxTween)
				{

					iconToRestore.x = iconOriginalX;
					iconToRestore.y = iconOriginalY;
					iconToRestore.angle = iconOriginalAngle;
					iconToRestore.visible = true;
					iconToRestore.alpha = 1;
					iconToRestore.active = true;
					iconToRestore.autoUpdate = true;


					iconMoveTween = null;
					iconReturning = false;

					if (focusedIcon == iconToRestore)
						focusedIcon = null;
				}
			}
		);
	}

	function getBattleBoyfriend():Dynamic
	{
		if (game == null)
			return null;

		if (game.currentStage == null)
			return null;

		return game.currentStage.getBoyfriend();
	}

	function playBoyfriendPreAttack():Void
	{
		var boyfriend:Dynamic =
			getBattleBoyfriend();

		if (boyfriend == null)
			return;

		boyfriend.canPlayOtherAnims = true;

		boyfriend.playAnimation(
			"pre attack",
			true,
			true
		);
	}

	function playBoyfriendParry():Void
	{
		var boyfriend:Dynamic =
			getBattleBoyfriend();

		if (boyfriend == null)
			return;

		boyfriend.playAnimation(
			"parry",
			true,
			true
		);

		boyfriend.canPlayOtherAnims = true;

		FunkinSound.playOnce(
			Paths.sound("mechanics/parry")
		);

		FunkinSound.playOnce(
			Paths.sound(
				"mechanics/tentacle " +
				FlxG.random.int(1, 2)
			)
		);

		parryHealPending = true;
		parryHealTime =
			Conductor.instance.songPosition + 500;
	}

	function updateParryHeal():Void
	{
		if (!parryHealPending)
			return;

		if (
			Conductor.instance.songPosition <
			parryHealTime
		)
			return;

		parryHealPending = false;
		parryHealTime = 0;

		if (game == null)
			return;

		game.health += PARRY_HEAL;

		if (game.health > 2)
			game.health = 2;
	}

	function playBoyfriendDodge():Void
	{
		var boyfriend:Dynamic =
			getBattleBoyfriend();

		if (boyfriend == null)
			return;

		var dodgeNumber:Int =
			FlxG.random.int(1, 3);

		var dodgeAnimation:String =
			"dodge" + dodgeNumber;

		boyfriend.canPlayOtherAnims = true;

		boyfriend.ignoreExclusionPref = [
			"dodge1",
			"dodge2",
			"dodge3"
		];

		boyfriend.playAnimation(
			dodgeAnimation,
			true,
			true
		);

		FunkinSound.playOnce(
			Paths.sound("mechanics/dodge")
		);
	}

	function damageBoyfriendOnDodgeMiss():Void
	{
		if (game == null)
			return;

		game.health -= DODGE_MISS_DAMAGE;

		if (game.health < 0)
			game.health = 0;
	}

	function playBoyfriendHit():Void
	{
		damageBoyfriendOnDodgeMiss();

		var boyfriend:Dynamic =
			getBattleBoyfriend();

		if (boyfriend == null)
			return;

		var hitAnimation:String =
			tentacleSide == "Left"
				? "left hit"
				: "right hit";

		boyfriend.ignoreExclusionPref = [];

		boyfriend.playAnimation(
			hitAnimation,
			true,
			true
		);

		boyfriend.canPlayOtherAnims = true;

		var blinkNow:Float = Conductor.instance.songPosition;

		boyfriendHitBlinking = false;
		boyfriendHitBlinkWaiting = true;
		boyfriendHitBlinkVisible = true;
		boyfriendHitBlinkStartTime = blinkNow + 150;
		boyfriendHitBlinkEndTime = boyfriendHitBlinkStartTime + 1500;
		boyfriendHitNextToggleTime = boyfriendHitBlinkStartTime;
		boyfriendHitBlinkPhase = 0;

		boyfriend.visible = true;

		if (game != null && game.iconP1 != null)
			game.iconP1.visible = true;

		FunkinSound.playOnce(
			Paths.sound("mechanics/bfhit")
		);
	}

	function updateBoyfriendMissHit():Void
	{
		if (!boyfriendMissHitPending)
			return;

		if (
			Conductor.instance.songPosition <
			boyfriendMissHitTime
		)
			return;

		boyfriendMissHitPending = false;
		boyfriendMissHitTime = 0;

		playBoyfriendHit();
	}

	function updateBoyfriendHitBlink():Void
	{
		if (!boyfriendHitBlinking && !boyfriendHitBlinkWaiting)
			return;

		var boyfriend:Dynamic = getBattleBoyfriend();

		if (boyfriend == null)
		{
			boyfriendHitBlinking = false;
			boyfriendHitBlinkWaiting = false;
			return;
		}

		var bfIcon:Dynamic = null;

		if (game != null)
			bfIcon = game.iconP1;

		var songPos:Float = Conductor.instance.songPosition;

		if (boyfriendHitBlinkWaiting)
		{
			if (songPos < boyfriendHitBlinkStartTime)
				return;

			boyfriendHitBlinkWaiting = false;
			boyfriendHitBlinking = true;
			boyfriendHitBlinkVisible = true;
			boyfriendHitBlinkPhase = 0;
			boyfriendHitNextToggleTime = songPos;
		}

		if (songPos >= boyfriendHitBlinkEndTime)
		{
			boyfriend.visible = true;

			if (bfIcon != null)
				bfIcon.visible = true;

			boyfriendHitBlinkVisible = true;
			boyfriendHitBlinking = false;
			boyfriendHitBlinkWaiting = false;
			boyfriendHitBlinkStartTime = 0;
			boyfriendHitBlinkEndTime = 0;
			boyfriendHitNextToggleTime = 0;
			boyfriendHitBlinkPhase = 0;
			return;
		}

		var intervalMs:Float =
			songPos < boyfriendHitBlinkStartTime + 1000
				? (1000 / 30)
				: (1000 / 60);

		if (songPos >= boyfriendHitNextToggleTime)
		{
			boyfriendHitBlinkPhase++;
			boyfriendHitBlinkVisible =
				(boyfriendHitBlinkPhase % 2) == 0;

			boyfriend.visible = boyfriendHitBlinkVisible;

			if (bfIcon != null)
				bfIcon.visible = boyfriendHitBlinkVisible;

			boyfriendHitNextToggleTime = songPos + intervalMs;
		}
	}

	function playBoyfriendAttack():Void
	{
		var boyfriend:Dynamic =
			getBattleBoyfriend();

		if (boyfriend == null)
			return;

		boyfriend.canPlayOtherAnims = true;
		boyfriend.ignoreExclusionPref = [
			"attack"
		];

		boyfriend.playAnimation(
			"attack",
			true,
			true
		);

		boyfriend.canPlayOtherAnims = false;

		boyfriendAttackHoldPending = true;
		boyfriendAttackReleaseTime =
			Conductor.instance.songPosition + 500;

		var attackSound:FunkinSound =
			FunkinSound.playOnce(
				Paths.sound("mechanics/attack")
			);

		if (attackSound != null)
		{
			attackSound.pitch =
				FlxG.random.float(
					0.9,
					1.1
				);
		}
	}


	function updateBoyfriendAttackHold():Void
	{
		if (!boyfriendAttackHoldPending)
			return;

		if (
			Conductor.instance.songPosition <
			boyfriendAttackReleaseTime
		)
			return;

		boyfriendAttackHoldPending = false;
		boyfriendAttackReleaseTime = 0;

		var boyfriend:Dynamic =
			getBattleBoyfriend();

		if (boyfriend == null)
			return;

		boyfriend.ignoreExclusionPref = [];
		boyfriend.canPlayOtherAnims = true;
	}


	function getDodgeTripleStartForIndex(index:Int):Int
	{

		if (
			index >= 0 &&
			index <= 2
		)
			return 0;

		if (
			index >= 4 &&
			index <= 6
		)
			return 4;

		if (
			index >= 8 &&
			index <= 10
		)
			return 8;

		if (
			index >= 12 &&
			index <= 14
		)
			return 12;

		return -1;
	}


	function prepareDodgeCameraGroup(index:Int):Void
	{
		currentBattleEventIndex = index;

		var tripleStart:Int =
			getDodgeTripleStartForIndex(index);

		if (tripleStart < 0)
		{
			dodgeTripleActive = false;
			dodgeTripleStartIndex = -1;
			dodgeTripleEndIndex = -1;
			return;
		}

		dodgeTripleActive = true;
		dodgeTripleStartIndex = tripleStart;
		dodgeTripleEndIndex = tripleStart + 2;
	}

	function shouldKeepDodgeCamera():Bool
	{
		if (!dodgeTripleActive)
			return false;

		if (currentBattleEventIndex < 0)
			return false;

		return
			currentBattleEventIndex <
			dodgeTripleEndIndex;
	}

	function finishDodgeCameraForCurrentEvent():Void
	{
		if (shouldKeepDodgeCamera())
			return;

		stopDodgeCamera();

		if (
			dodgeTripleActive &&
			currentBattleEventIndex >=
				dodgeTripleEndIndex
		)
		{
			dodgeTripleActive = false;
			dodgeTripleStartIndex = -1;
			dodgeTripleEndIndex = -1;
		}
	}

	function startDodgeCamera():Void
	{
		if (game == null)
			return;

		if (game.camGame == null)
			return;

		if (game.cameraFollowPoint == null)
			return;

		var boyfriend:Dynamic =
			getBattleBoyfriend();

		if (boyfriend == null)
			return;

		if (boyfriend.cameraFocusPoint == null)
			return;

		dodgeCameraBaseX =
			game.cameraFollowPoint.x;

		dodgeCameraBaseY =
			game.cameraFollowPoint.y;

		dodgeCameraStartZoom =
			game.currentCameraZoom;

		dodgeCameraStartAngle =
			game.camGame.scrollAngle;

		dodgeCameraTargetX =
			boyfriend.cameraFocusPoint.x + 200;

		dodgeCameraTargetY =
			boyfriend.cameraFocusPoint.y + 200;

		if (game.currentStage != null)
		{
			dodgeCameraTargetZoom =
				1.4 * game.currentStage.camZoom;
		}
		else
		{
			dodgeCameraTargetZoom =
				dodgeCameraStartZoom * 1.4;
		}

		game.resetCamera(
			false,
			false,
			false
		);

		game.cancelCameraFollowTween();

		game.cameraFollowPoint.x =
			dodgeCameraTargetX;

		game.cameraFollowPoint.y =
			dodgeCameraTargetY;

		game.cancelCameraZoomTween();

		game.currentCameraZoom =
			dodgeCameraTargetZoom;

		game.camGame.zoom =
			dodgeCameraTargetZoom;

		dodgeCameraElapsed = 0;
		dodgeCameraActive = true;
	}


	function updateDodgeCamera(elapsed:Float):Void
	{
		if (!dodgeCameraActive)
			return;

		if (game == null)
			return;

		if (game.camGame == null)
			return;

		if (game.cameraFollowPoint == null)
			return;

		var currentPlayState:PlayState =
			PlayState.instance;

		if (currentPlayState == null)
			return;

		if (currentPlayState.needsReset)
			return;

		if (game != currentPlayState)
			return;


		game.cameraFollowPoint.x =
			dodgeCameraTargetX;

		game.cameraFollowPoint.y =
			dodgeCameraTargetY;

		game.currentCameraZoom =
			dodgeCameraTargetZoom;

		game.camGame.zoom =
			dodgeCameraTargetZoom;

		dodgeCameraElapsed += elapsed;

		var progress:Float =
			dodgeCameraElapsed / 0.35;

		if (progress < 0)
			progress = 0;

		if (progress > 1)
			progress = 1;

		var eased:Float =
			FlxEase.backOut(progress);

		game.camGame.scrollAngle =
			dodgeCameraStartAngle +
			(0 - dodgeCameraStartAngle) *
			eased;
	}


	function stopDodgeCamera():Void
	{
		if (!dodgeCameraActive)
			return;

		dodgeCameraActive = false;

		if (game != null)
		{
			game.cancelCameraFollowTween();
			game.cancelCameraZoomTween();

			if (game.cameraFollowPoint != null)
			{
				game.cameraFollowPoint.x =
					dodgeCameraBaseX;

				game.cameraFollowPoint.y =
					dodgeCameraBaseY;
			}

			game.currentCameraZoom =
				dodgeCameraStartZoom;

			if (game.camGame != null)
			{
				game.camGame.zoom =
					dodgeCameraStartZoom;

				game.camGame.scrollAngle =
					dodgeCameraStartAngle;
			}

			game.resetCamera(
				false,
				false,
				false
			);
		}

		dodgeCameraElapsed = 0;
	}


	function cancelDodgeCameraForRetry():Void
	{
		dodgeCameraActive = false;
		dodgeCameraElapsed = 0;

		currentBattleEventIndex = -1;
		dodgeTripleActive = false;
		dodgeTripleStartIndex = -1;
		dodgeTripleEndIndex = -1;
	}


	function triggerEvent(
		isDodge:Bool,
		beatReserve:Int,
		isYah:Bool = false,
		eventIndex:Int = -1
	):Void
	{
		if (mechanicActive)
		{

			if (
				mode == "dodge" &&
				!finalResultGiven
			)
			{
				playBoyfriendHit();
				finalResultGiven = true;
				canHitFinal = false;
			}

			endMechanic();
		}

		if (eventIndex >= 0)
			prepareDodgeCameraGroup(eventIndex);

		if (uiCross == null)
			return;

		if (isDodge)
		{
			mode = "dodge";
			chooseTentacleSide();
			fadeSnowmanForDodge();

			if (!dodgeCameraActive)
				startDodgeCamera();
		}
		else
		{
			mode = "attack";
		}

		eventBeats =
			beatReserve + 1;

		currentBeatInEvent = 0;

		mechanicActive = true;

		eventStartBeat =
			Conductor.instance.currentBeat;

		canHitFinal = false;
		finalResultGiven = false;

		targetFinalTime = 0;

		currentEventYah = isYah;

		FlxTween.cancelTweensOf(
			uiCross
		);

		FlxTween.cancelTweensOf(
			uiCross.scale
		);

		uiCross.visible = true;
		uiCross.angle = -55;
		uiCross.alpha = 0;
		uiCross.scale.set(
			1.5,
			1.5
		);

		FlxTween.tween(
			uiCross,
			{
				angle: 0,
				alpha: 0.6
			},
			18 / 24,
			{
				ease:
					FlxEase.cubeOut
			}
		);

		FlxTween.tween(
			uiCross.scale,
			{
				x: 1,
				y: 1
			},
			18 / 24,
			{
				ease:
					FlxEase.cubeOut
			}
		);

		moveBattleIconIn(isDodge);
	}

	function animateCrossOut():Void
	{
		if (uiCross == null)
			return;

		FlxTween.cancelTweensOf(
			uiCross
		);

		FlxTween.cancelTweensOf(
			uiCross.scale
		);

		uiCross.scale.set(
			0.9,
			0.9
		);

		FlxTween.tween(
			uiCross.scale,
			{
				x: 1.4,
				y: 1.4
			},
			7 / 24,
			{
				startDelay:
					1 / 24,

				ease:
					FlxEase.quartOut
			}
		);

		FlxTween.tween(
			uiCross,
			{
				alpha: 0
			},
			7 / 24,
			{
				startDelay:
					1 / 24,

				ease:
					FlxEase.quartOut
			}
		);
	}

	function clearDotsAndStripes():Void
	{
		for (dot in activeDots)
		{
			if (dot != null)
			{
				FlxTween.cancelTweensOf(dot);

				dot.visible = false;
				dot.active = false;

				if (game != null)
				{
					game.remove(
						dot,
						true
					);
				}

				dot.destroy();
			}
		}

		activeDots = [];

		for (stripe in activeStripes)
		{
			if (stripe != null)
			{
				FlxTween.cancelTweensOf(
					stripe
				);

				stripe.visible = false;
				stripe.active = false;

				if (game != null)
				{
					game.remove(
						stripe,
						true
					);
				}

				stripe.destroy();
			}
		}

		activeStripes = [];
	}

	function endMechanic():Void
	{
		var endedDodge:Bool =
			mode == "dodge";

		moveBattleIconBack();

		if (endedDodge)
		{
			finishDodgeCameraForCurrentEvent();
			scheduleSnowmanReturn();
		}

		mechanicActive = false;

		eventBeats = 0;
		currentBeatInEvent = 0;

		canHitFinal = false;
		finalResultGiven = false;

		targetFinalTime = 0;

		currentEventYah = false;

		opponentHitPending = false;
		opponentHitTime = 0;
		opponentReleaseTime = 0;

		animateCrossOut();

		clearDotsAndStripes();
	}

	function checkBattleEvents():Void
	{
		if (!isBattleMechanicEnabled())
			return;

		if (game == null)
			return;

		if (battleEventTriggered == null)
			return;

		if (
			battleEventTriggered.length !=
			battleEventTimes.length
		)
			return;

		var songPosition:Float =
			Conductor.instance.songPosition;

		for (i in 0...battleEventTimes.length)
		{
			if (battleEventTriggered[i])
				continue;

			var eventTime:Float =
				battleEventTimes[i];

			if (songPosition >= eventTime)
			{
				battleEventTriggered[i] = true;

				var isDodge:Bool =
					battleEventTypes[i] == 0;

				var beats:Int =
					battleEventBeats[i];

				var isYah:Bool =
					i == 0;

				triggerEvent(
					isDodge,
					beats,
					isYah,
					i
				);
			}
		}
	}

	function isWithinFinalWindow():Bool
	{
		if (!canHitFinal)
			return false;

		if (targetFinalTime <= 0)
			return false;

		var beatLengthMs:Float =
			60000 /
			Conductor.instance.bpm;

		var preWindowMs:Float =
			beatLengthMs *
			FINAL_PRE_WINDOW;

		var postWindowMs:Float =
			beatLengthMs *
			FINAL_POST_WINDOW;

		var songPosition:Float =
			Conductor.instance.songPosition;

		return
			songPosition >=
				targetFinalTime - preWindowMs
			&&
			songPosition <=
				targetFinalTime + postWindowMs;
	}

	function getBattleRating():String
	{
		if (targetFinalTime <= 0)
			return "missed";

		var difference:Float =
			Math.abs(
				Conductor.instance.songPosition -
				targetFinalTime
			);

		if (difference <= 45)
			return "sick";

		if (difference <= 90)
			return "good";

		if (difference <= 150)
			return "bad";

		return "shit";
	}

	function spawnBattleRating(rating:String):Void
	{
		if (game == null)
			return;

		if (uiCross == null)
			return;

		var rat:FunkinSprite =
			new FunkinSprite();

		rat.frames =
			Paths.getSparrowAtlas(
				"mechanincs/ratings"
			);

		if (rat.frames == null)
		{
			rat.destroy();
			return;
		}

		rat.animation.addByPrefix(
			"rating",
			rating,
			24,
			false
		);

		rat.animation.play(
			"rating",
			true
		);

		rat.camera = game.camHUD;
		rat.zIndex = 2100;

		rat.screenCenter();

		rat.y =
			uiCross.y -
			rat.height -
			10;

		rat.acceleration.y = 550;

		rat.velocity.y -=
			FlxG.random.int(
				140,
				175
			);

		rat.velocity.x -=
			FlxG.random.int(
				0,
				10
			);

		rat.angle =
			FlxG.random.int(
				-5,
				5
			);

		rat.angularVelocity =
			FlxG.random.int(
				-5,
				5
			);

		rat.scale.x *= 0.85;
		rat.scale.y *= 0.85;

		var targetScaleX:Float =
			rat.scale.x / 0.85;

		var targetScaleY:Float =
			rat.scale.y / 0.85;

		var beatDuration:Float =
			60 /
			Conductor.instance.bpm;

		FlxTween.tween(
			rat.scale,
			{
				x: targetScaleX,
				y: targetScaleY
			},
			beatDuration / 2,
			{
				ease:
					FlxEase.bounceOut
			}
		);

		FlxTween.tween(
			rat,
			{
				alpha: 0,
				angle:
					FlxG.random.int(
						-8,
						8
					)
			},
			0.1,
			{
				startDelay:
					beatDuration,

				onComplete:
					function(t:FlxTween)
					{
						if (game != null)
						{
							game.remove(
								rat,
								true
							);
						}

						rat.destroy();
					}
			}
		);

		game.add(rat);
		game.refresh();
	}

	function showBattleSplash():Void
	{
		if (battleSplash == null)
			return;

		FlxTween.cancelTweensOf(
			battleSplash
		);

		battleSplash.visible = true;

		battleSplash.angle =
			FlxG.random.float(
				-50,
				50
			);

		battleSplash.animation.play(
			"splash",
			true
		);

		battleSplash.alpha = 1;

		FlxTween.tween(
			battleSplash,
			{
				alpha: 0
			},
			0.35,
			{
				startDelay: 0.15,

				ease:
					FlxEase.quadOut,

				onComplete:
					function(t:FlxTween)
					{
						if (
							battleSplash !=
							null
						)
						{
							battleSplash.visible =
								false;
						}
					}
			}
		);
	}

	function getAttackRatingReward(rating:String):Float
	{

		switch (rating)
		{
			case "sick":
				return 0.5;

			case "good":
				return 0.335;

			case "shit":
				return 0.15;

			case "bad":
				return 0.05;

			default:
				return 0;
		}
	}

	function startHealthUnlockTween():Void
	{
		if (pendingHealthUnlock <= 0)
			return;

		if (healthUnlockTween != null)
		{
			healthUnlockTween.cancel();
			healthUnlockTween = null;
		}

		var targetHealthSucked:Float =
			healthSucked -
			pendingHealthUnlock;

		if (targetHealthSucked < 0)
			targetHealthSucked = 0;

		pendingHealthUnlock = 0;

		healthUnlockTween =
			FlxTween.num(
				healthSucked,
				targetHealthSucked,
				0.25,
				{
					ease: FlxEase.sineInOut,

					onComplete:
						function(t:FlxTween)
						{
							healthSucked =
								targetHealthSucked;

							syncAMtakeHealthLock();

							healthUnlockTween = null;
						}
				},
				function(value:Float)
				{
					healthSucked = value;
					syncAMtakeHealthLock();
				}
			);
	}


	function rewardSuccessfulAttack(rating:String):Void
	{
		if (game == null)
			return;

		var ratingReward:Float =
			getAttackRatingReward(
				rating
			);

		pendingHealthUnlock =
			ratingReward;

		game.health += 0.35;

		clampLockedHealth();
	}

	function hitFinalBeat():Void
	{
		if (!canHitFinal)
			return;

		if (finalResultGiven)
			return;

		if (!isWithinFinalWindow())
			return;

		var battleRating:String =
			getBattleRating();

		finalResultGiven = true;
		canHitFinal = false;

		moveBattleIconBack();

		spawnBattleRating(
			battleRating
		);

		showBattleSplash();

		if (mode == "attack")
		{

			FunkinSound.playOnce(
				Paths.sound("mechanics/success"),
				0.8
			);

			rewardSuccessfulAttack(
				battleRating
			);

			playBoyfriendAttack();
			scheduleOpponentHit();
		}
		else if (mode == "dodge")
		{
			if (
				game != null &&
				game.health <= 0.5
			)
			{
				playBoyfriendParry();
			}
			else
			{
				playBoyfriendDodge();
			}
		}

		clearDotsAndStripes();

		animateCrossOut();

		if (mode == "dodge")
		{
			finishDodgeCameraForCurrentEvent();
			scheduleSnowmanReturn();
		}

		mechanicActive = false;
	}

	function playBoyfriendAttackMiss():Void
	{
		var boyfriend:Dynamic =
			getBattleBoyfriend();

		if (boyfriend == null)
			return;

		boyfriend.ignoreExclusionPref = [];

		boyfriend.playAnimation(
			"singLEFTmiss",
			true,
			true
		);

		boyfriend.canPlayOtherAnims = true;
	}

	function missFinalBeat():Void
	{
		if (!canHitFinal)
			return;

		if (finalResultGiven)
			return;

		finalResultGiven = true;
		canHitFinal = false;

		moveBattleIconBack();

		clearDotsAndStripes();

		animateCrossOut();

		if (mode == "dodge")
		{
			finishDodgeCameraForCurrentEvent();
			scheduleSnowmanReturn();
		}

		mechanicActive = false;
	}

	function checkFinalTimeout():Void
	{
		if (!mechanicActive)
			return;

		if (!canHitFinal)
			return;

		if (finalResultGiven)
			return;

		if (targetFinalTime <= 0)
			return;

		var beatLengthMs:Float =
			60000 /
			Conductor.instance.bpm;

		var postWindowMs:Float =
			beatLengthMs *
			FINAL_POST_WINDOW;

		if (
			Conductor.instance.songPosition >
			targetFinalTime + postWindowMs
		)
		{

			if (mode == "dodge")
			{
				boyfriendMissHitPending = true;
				boyfriendMissHitTime =
					Conductor.instance.songPosition + 20;
			}
			else if (mode == "attack")
			{

				playBoyfriendAttackMiss();

				FunkinSound.playOnce(
					Paths.sound("mechanics/failed")
				);
			}

			spawnBattleRating(
				"missed"
			);

			missFinalBeat();
		}
	}

	function updateMechanicInputMode():Void
	{
		if (
			FlxG.keys != null &&
			FlxG.keys.firstJustPressed() != -1
		)
		{
			keyboardInputMode = true;
		}

		var inputTouches = FlxG.touches.justStarted();

		if (
			inputTouches != null &&
			inputTouches.length > 0
		)
		{
			keyboardInputMode = false;
		}
	}



	function checkMechanicInput():Void
	{
		if (!mechanicActive)
			return;

		if (!canHitFinal)
			return;

		if (finalResultGiven)
			return;

		if (uiCross == null)
			return;

		if (keyboardInputMode)
		{
			if (
				FlxG.keys != null &&
				FlxG.keys.justPressed.SPACE
			)
			{
				if (isWithinFinalWindow())
					hitFinalBeat();

				return;
			}

			return;
		}

		var touches = FlxG.touches.justStarted();

		if (touches == null)
			return;

		for (touch in touches)
		{
			if (touch == null)
				continue;

			var point =
				touch.getWorldPosition(
					game.camHUD
				);

			if (point == null)
				continue;

			var insideCross:Bool =
				point.x >= uiCross.x &&
				point.x <= uiCross.x + uiCross.width &&
				point.y >= uiCross.y &&
				point.y <= uiCross.y + uiCross.height;

			if (insideCross)
			{
				if (isWithinFinalWindow())
					hitFinalBeat();

				return;
			}
		}
	}


	override function onSongEvent(event):Void
	{
		super.onSongEvent(event);

		if (!dodgeCameraActive)
			return;

		if (event == null)
			return;

		if (event.eventData == null)
			return;

		var eventKind:String =
			Std.string(
				event.eventData.eventKind
			);

		if (
			eventKind == "FocusCamera" ||
			eventKind == "ZoomCamera"
		)
		{
			event.cancelEvent();
		}
	}


	override function onUpdate(
		event
	):Void
	{
		super.onUpdate(event);

		updateMechanicInputMode();

		updateBoyfriendMissHit();
		updateParryHeal();
		updateBoyfriendHitBlink();
		updateSnowmanReturn();
		updateTentacleAttackAfterFinalBeat();
		updateBoyfriendAttackHold();

		var currentPlayState:PlayState = PlayState.instance;

		if (currentPlayState == null)
			return;

		if (!isBattleMechanicEnabled())
		{
			AMtake.healthSuckedVisual = 0;
			return;
		}

		if (
			game != currentPlayState ||
			uiCross == null ||
			battleSplash == null
		)
		{
			game = currentPlayState;
			createMechanic();
		}

		if (game == null)
			return;

		updateDodgeCamera(event.elapsed);

		clampLockedHealth();

		if (Conductor.instance.songPosition <= 0)
		{
			if (songHadStarted)
			{
				stopDodgeCamera();
				mechanicActive = false;
				eventBeats = 0;
				currentBeatInEvent = 0;
				canHitFinal = false;
				finalResultGiven = false;
				targetFinalTime = 0;
				currentEventYah = false;

				parryHealPending = false;
				parryHealTime = 0;

				boyfriendMissHitPending = false;
				boyfriendMissHitTime = 0;

				tentacleAttackPending = false;
				tentacleAttackTime = 0;

				boyfriendAttackHoldPending = false;
				boyfriendAttackReleaseTime = 0;

				opponentHitPending = false;
				opponentHitTime = 0;
				opponentReleaseTime = 0;

				stopOpponentIconFlicker();

				boyfriendHitBlinking = false;
				boyfriendHitBlinkWaiting = false;
				boyfriendHitBlinkVisible = true;
				boyfriendHitBlinkStartTime = 0;
				boyfriendHitBlinkEndTime = 0;
				boyfriendHitNextToggleTime = 0;
				boyfriendHitBlinkPhase = 0;

				var retryBoyfriend:Dynamic = getBattleBoyfriend();

				if (retryBoyfriend != null)
					retryBoyfriend.visible = true;

				if (game != null && game.iconP1 != null)
					game.iconP1.visible = true;

				if (iconMoveTween != null)
				{
					iconMoveTween.cancel();
					iconMoveTween = null;
				}

				if (focusedIcon != null)
				{
					focusedIcon.x = iconOriginalX;
					focusedIcon.y = iconOriginalY;
					focusedIcon.angle = iconOriginalAngle;
					focusedIcon.visible = true;
					focusedIcon.alpha = 1;
					focusedIcon.active = true;
					focusedIcon.autoUpdate = true;

					focusedIcon = null;
				}

				iconReturning = false;

				clearDotsAndStripes();
				resetBattleEvents();
				resetLockedHealth();
				clampLockedHealth();

				tentacleLeft = null;
				tentacleRight = null;
				tentacleSide = "Left";

				snowman = null;
				resetSnowman();

				setupTentacles();

				if (uiCross != null)
				{
					uiCross.alpha = 0;
					uiCross.visible = true;
				}

				if (battleSplash != null)
				{
					battleSplash.visible = false;
					battleSplash.alpha = 1;
				}

				songHadStarted = false;
			}

			return;
		}

		songHadStarted = true;

		checkBattleEvents();

		checkMechanicInput();

		updateOpponentHit();
		updateOpponentIconFlicker();

		checkFinalTimeout();
	}

	override function onBeatHit(
		event
	):Void
	{
		super.onBeatHit(event);

		if (!isBattleMechanicEnabled())
			return;

		if (game == null)
			return;

		if (!mechanicActive)
			return;

		if (uiCross == null)
			return;

		var beatsPassed:Int =
			Std.int(
				Math.floor(
					Conductor.instance.currentBeat -
					eventStartBeat
				)
			);

		if (beatsPassed < 0)
			return;

		if (
			beatsPassed >=
			eventBeats
		)
		{
			if (!canHitFinal)
			{
				if (!finalResultGiven)
				endMechanic();
			}

			return;
		}

		if (
			beatsPassed ==
			currentBeatInEvent &&
			beatsPassed != 0
		)
			return;

		currentBeatInEvent =
			beatsPassed;

		var cowbell:FunkinSound =
			FunkinSound.playOnce(
				Paths.sound("mechanics/cowbell")
			);

		if (
			cowbell != null &&
			mode == "attack"
		)
		{
			cowbell.pitch = 1.1;
		}

		playTentacleTick();

		if (
			beatsPassed <
			eventBeats - 1
		)
		{
			spawnDotPair();
		}
		else
		{
			if (!canHitFinal)
			{
				if (mode == "attack")
					playBoyfriendPreAttack();

				scheduleTentacleAttackAfterFinalBeat();

				spawnFinalStripes();
			}
		}
	}

	override function onStateChangeEnd(
		event
	):Void
	{
		super.onStateChangeEnd(event);

		if (
			PlayState.instance ==
			null
		)
			return;

		if (!isBattleMechanicEnabled())
		{
			AMtake.healthSuckedVisual = 0;
			return;
		}

		game =
			PlayState.instance;

		createMechanic();
	}

	function resetBattleForRetry():Void
	{
		cancelDodgeCameraForRetry();

		mechanicActive = false;

		eventBeats = 0;
		currentBeatInEvent = 0;

		canHitFinal = false;
		finalResultGiven = false;

		targetFinalTime = 0;
		currentEventYah = false;

		tentacleAttackPending = false;
		tentacleAttackTime = 0;

		boyfriendAttackHoldPending = false;
		boyfriendAttackReleaseTime = 0;

		if (uiCross != null)
		{
			FlxTween.cancelTweensOf(uiCross);
			uiCross.alpha = 0;
			uiCross.visible = false;
			uiCross.active = false;
		}

		if (battleSplash != null)
		{
			FlxTween.cancelTweensOf(battleSplash);
			battleSplash.alpha = 0;
			battleSplash.visible = false;
			battleSplash.active = false;
		}

		for (dot in activeDots)
		{
			if (dot != null)
			{
				FlxTween.cancelTweensOf(dot);
				dot.alpha = 0;
				dot.visible = false;
				dot.active = false;
			}
		}

		for (stripe in activeStripes)
		{
			if (stripe != null)
			{
				FlxTween.cancelTweensOf(stripe);
				stripe.alpha = 0;
				stripe.visible = false;
				stripe.active = false;
			}
		}

		activeDots = [];
		activeStripes = [];

		if (iconMoveTween != null)
		{
			iconMoveTween.cancel();
			iconMoveTween = null;
		}

		if (focusedIcon != null)
		{
			focusedIcon.x = iconOriginalX;
			focusedIcon.y = iconOriginalY;
			focusedIcon.angle = iconOriginalAngle;
			focusedIcon.visible = true;
			focusedIcon.alpha = 1;
			focusedIcon.active = true;
			focusedIcon.autoUpdate = true;

		}

		if (
			game != null &&
			game.iconP1 != null &&
			iconP1StartCaptured
		)
		{
			game.iconP1.x = iconP1StartX;
			game.iconP1.y = iconP1StartY;
			game.iconP1.angle = iconP1StartAngle;
			game.iconP1.visible = true;
			game.iconP1.alpha = 1;
			game.iconP1.active = true;
			game.iconP1.autoUpdate = true;
		}

		focusedIcon = null;
		iconReturning = false;

		tentacleLeft = null;
		tentacleRight = null;
		tentacleSide = "Left";

		songHadStarted = false;
		battleEventTriggered = [];

		uiCross = null;
		battleSplash = null;

		AMtake.healthSuckedVisual = 0;

		stopOpponentIconFlicker();

		iconP1StartCaptured = false;

		game = null;
	}

	override function onSongRetry(event):Void
	{
		super.onSongRetry(event);

		if (PlayState.instance != null)
		{
			if (game == null)
				game = PlayState.instance;

			resetBattleForRetry();
		}
	}

	override function onStateChangeBegin(
		event
	):Void
	{
		super.onStateChangeBegin(event);
		resetBattleForRetry();
	}
}
