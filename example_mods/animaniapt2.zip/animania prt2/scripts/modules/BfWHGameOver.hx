import funkin.modding.module.Module;
import funkin.modding.IPlayStateScriptedClass;
import funkin.play.GameOverSubState;
import funkin.play.PlayState;
import funkin.util.tools.StringTools;

class BfWHGameOver extends Module implements IPlayStateScriptedClass
{
	final gameoverSuffix:String = "-wh";
	var activeGameover:Bool = false;

	function new()
	{
		super("BfWHGameOver", 0);
	}

	function clearWHSuffix():Void
	{
		GameOverSubState.musicSuffix =
			StringTools.stripSuffix(
				GameOverSubState.musicSuffix,
				gameoverSuffix
			);

		GameOverSubState.blueBallSuffix =
			StringTools.stripSuffix(
				GameOverSubState.blueBallSuffix,
				gameoverSuffix
			);

		GameOverSubState.animationSuffix =
			StringTools.stripSuffix(
				GameOverSubState.animationSuffix,
				gameoverSuffix
			);
	}

	public override function onGameOver(event:ScriptEvent)
	{
		clearWHSuffix();

		var play = PlayState.instance;

		if (play == null || play.isMinimalMode)
		{
			activeGameover = false;
			return;
		}

		activeGameover =
			play.currentStage?.getBoyfriend()?.characterId ==
				"bf-christmas-amtake" &&
			play.currentStage?.getOpponent()?.characterId ==
				"monster-plant";

		if (!activeGameover)
			return;

		GameOverSubState.musicSuffix += gameoverSuffix;
		GameOverSubState.blueBallSuffix += gameoverSuffix;
		GameOverSubState.animationSuffix += gameoverSuffix;
	}

	override function onSubStateOpenEnd(event)
	{
		if (event.targetState is GameOverSubState && activeGameover)
		{
			if (GameOverSubState.instance == null)
				return;

			GameOverSubState.instance.cameraFollowPoint.x -= 250;
			GameOverSubState.instance.cameraFollowPoint.y -= 375;
		}
	}

	override function onSubStateCloseBegin(event)
	{
		if (event.targetState is GameOverSubState)
		{
			clearWHSuffix();
			activeGameover = false;
		}
	}

	override function onStateChangeBegin(event)
	{
		clearWHSuffix();
		activeGameover = false;
	}
}
