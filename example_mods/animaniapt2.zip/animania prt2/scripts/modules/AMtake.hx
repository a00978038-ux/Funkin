import funkin.play.PlayState;
import funkin.graphics.FunkinSprite;
import flixel.math.FlxRect;
import flixel.FlxG;
import funkin.Paths;
import funkin.modding.module.Module;
import flixel.FlxSprite;
import flixel.math.FlxMath;
import flixel.tweens.FlxTween;
import flixel.tweens.FlxEase;
import funkin.Conductor;
import flixel.util.FlxColor;

class AMtake extends Module
{
    var healthBarBG:FunkinSprite;
    var healthBarGreen:FunkinSprite;
    var healthBarBlocked:FunkinSprite;
    var healthBar:FunkinSprite;

    // Sincronizado por WinterHorrorlandAmtakeBattleModule.
    // 1.0 = mitad de la barra bloqueada.
    // 0.0 = barra completamente desbloqueada.
    public static var healthSuckedVisual:Float = 0;

    var game:PlayState;
    var added:Bool = false;
    var isAMtakeActive:Bool = false;

    var fcFirstHit:Bool = false;
    var fcFailed:Bool = false;

    var scoreStatic:FunkinSprite;
    var scoreDigits:Array<FunkinSprite> = [];

    var fcStatic:FlxSprite;

    var blotRating:FunkinSprite;
    var rankRating:FunkinSprite;
    var comboRating:FunkinSprite;

    var blotHue:Float = 0;
    var targetHue:Float = 0;
    var hueStep:Float = 10;
    var smoothSpeed:Float = 35;

    public function new()
    {
        super("AMtake", 99999);
    }

    // SOLO se activa en estas 3 canciones:
    // dadbattle-amtake
    // cocoa-amtake
    // eggnog-amtake
    function isAMtakeSong():Bool
    {
        if (game == null || game.currentSong == null)
            return false;

        var songId:String = Std.string(game.currentSong.id).toLowerCase();

        return songId == "dadbattle-amtake"
            || songId == "cocoa-amtake"
            || songId == "eggnog-amtake"
            || songId == "bopeebo-amtake"
            || songId == "fresh-amtake"
            || songId == "winter-horrorland-amtake";
    }

    function removeCustomHUD():Void
    {
        if (healthBarBG != null)
        {
            if (healthBarBG.exists)
            {
                game.remove(healthBarBG, true);
                healthBarBG.destroy();
            }
            healthBarBG = null;
        }

        if (healthBarGreen != null)
        {
            if (healthBarGreen.exists)
            {
                game.remove(healthBarGreen, true);
                healthBarGreen.destroy();
            }
            healthBarGreen = null;
        }

        if (healthBarBlocked != null)
        {
            if (healthBarBlocked.exists)
            {
                game.remove(healthBarBlocked, true);
                healthBarBlocked.destroy();
            }
            healthBarBlocked = null;
        }

        if (healthBar != null)
        {
            if (healthBar.exists)
            {
                game.remove(healthBar, true);
                healthBar.destroy();
            }
            healthBar = null;
        }

        if (scoreStatic != null)
        {
            if (scoreStatic.exists)
            {
                game.remove(scoreStatic, true);
                scoreStatic.destroy();
            }
            scoreStatic = null;
        }

        for (digit in scoreDigits)
        {
            if (digit != null && digit.exists)
            {
                game.remove(digit, true);
                digit.destroy();
            }
        }

        scoreDigits = [];

        if (fcStatic != null)
        {
            if (fcStatic.exists)
            {
                game.remove(fcStatic, true);
                fcStatic.destroy();
            }
            fcStatic = null;
        }

        if (blotRating != null)
        {
            if (blotRating.exists)
            {
                game.remove(blotRating, true);
                blotRating.destroy();
            }
            blotRating = null;
        }

        if (rankRating != null)
        {
            if (rankRating.exists)
            {
                game.remove(rankRating, true);
                rankRating.destroy();
            }
            rankRating = null;
        }

        if (comboRating != null)
        {
            if (comboRating.exists)
            {
                game.remove(comboRating, true);
                comboRating.destroy();
            }
            comboRating = null;
        }
    }

    override function onSongLoaded(event:Dynamic)
    {
        super.onSongLoaded(event);

        game = PlayState.instance;

        if (game != null)
            removeCustomHUD();

        added = false;
        isAMtakeActive = false;
        fcFirstHit = false;
        fcFailed = false;

        blotHue = 0;
        targetHue = 0;

        scoreDigits = [];

        if (game == null)
            return;

        isAMtakeActive = isAMtakeSong();

        if (!isAMtakeActive)
            return;

        Paths.getSparrowAtlas("ui/rating/GAMEPLAY_UI_ASSETS");
    }

    override function onCountdownStart(event:Dynamic):Void
    {
        super.onCountdownStart(event);

        if (!isAMtakeActive || game == null || !game.exists)
            return;

        removeCustomHUD();

        added = true;

        if (game.healthBarBG == null || game.healthBar == null)
            return;

        var barY:Float = game.healthBarBG.y;
        var hbzIndex:Int = game.healthBarBG.zIndex;

        game.healthBar.visible = false;
        game.healthBar.alpha = 0;

        game.healthBarBG.visible = false;
        game.healthBarBG.alpha = 0;

        createHealthBar(barY, hbzIndex);
        createScoreHUD();
        createFCHUD();
        createRatingSystem();

        game.refresh();
    }

    function createHealthBar(barY:Float, hbzIndex:Int):Void
    {
        healthBarBG = new FunkinSprite(
            0,
            0,
            Paths.image("ui/Amtake-healthbar/hp")
        );

        healthBarBG.screenCenter(0x01);
        healthBarBG.y = barY;
        healthBarBG.zIndex = hbzIndex;
        healthBarBG.cameras = [game.camHUD];
        healthBarBG.scrollFactor.set();
        healthBarBG.color = 0xFFFF0000;

        game.add(healthBarBG);

        healthBarGreen = new FunkinSprite(
            0,
            0,
            Paths.image("ui/Amtake-healthbar/hp")
        );

        healthBarGreen.screenCenter(0x01);
        healthBarGreen.y = barY;
        healthBarGreen.zIndex = hbzIndex + 1;
        healthBarGreen.cameras = [game.camHUD];
        healthBarGreen.scrollFactor.set();
        healthBarGreen.color = 0xFF66FF33;
        healthBarGreen.clipRect = null;

        game.add(healthBarGreen);

        /*
         * Capa visual de vida bloqueada para winter-horrorland-amtake.
         * Usa el MISMO gráfico "hp" del HUD AMtake, así que coincide
         * exactamente con la barra roja/verde personalizada.
         */
        healthBarBlocked = new FunkinSprite(
            0,
            0,
            Paths.image("ui/Amtake-healthbar/hp")
        );

        healthBarBlocked.screenCenter(0x01);
        healthBarBlocked.y = barY;
        healthBarBlocked.zIndex = hbzIndex + 2;
        healthBarBlocked.cameras = [game.camHUD];
        healthBarBlocked.scrollFactor.set();
        healthBarBlocked.color = 0xFF362B4D;
        healthBarBlocked.clipRect = null;
        healthBarBlocked.visible = false;

        game.add(healthBarBlocked);

        healthBar = new FunkinSprite(
            0,
            0,
            Paths.image("ui/Amtake-healthbar/bar")
        );

        healthBar.screenCenter(0x01);
        healthBar.y = barY - 4;
        healthBar.zIndex = hbzIndex + 3;
        healthBar.cameras = [game.camHUD];
        healthBar.scrollFactor.set();

        game.add(healthBar);
    }

    function createScoreHUD():Void
    {
        var scoreX:Float = FlxG.width - 220;
        var scoreY:Float = FlxG.height - 180;

        scoreStatic = new FunkinSprite(scoreX, scoreY);

        scoreStatic.frames = Paths.getSparrowAtlas(
            "ui/rating/GAMEPLAY_UI_ASSETS"
        );

        scoreStatic.animation.addByPrefix(
            "score",
            "score",
            24,
            false
        );

        scoreStatic.animation.play("score");

        scoreStatic.scale.set(0.6, 0.6);
        scoreStatic.updateHitbox();

        scoreStatic.cameras = [game.camHUD];
        scoreStatic.scrollFactor.set();
        scoreStatic.zIndex = 100;

        game.add(scoreStatic);

        for (i in 0...10)
        {
            var digit = new FunkinSprite();

            digit.frames = Paths.getSparrowAtlas(
                "ui/rating/GAMEPLAY_UI_ASSETS"
            );

            for (n in 0...10)
            {
                digit.animation.addByPrefix(
                    n + "anim",
                    n + " d num",
                    24,
                    false
                );
            }

            digit.cameras = [game.camHUD];
            digit.scrollFactor.set();
            digit.zIndex = 101 + i;
            digit.visible = false;

            game.add(digit);
            scoreDigits.push(digit);
        }

        updateScoreDigits(0);
    }

    function createFCHUD():Void
    {
        fcStatic = new FunkinSprite(
            20,
            FlxG.height - 160,
            Paths.image("ui/rating/fc")
        );

        fcStatic.scale.set(0.5, 0.5);
        fcStatic.updateHitbox();

        fcStatic.cameras = [game.camHUD];
        fcStatic.scrollFactor.set();
        fcStatic.zIndex = 100;
        fcStatic.alpha = 0;

        game.add(fcStatic);
    }

    function createRatingSystem():Void
    {
        var baseX:Float = FlxG.width / 2 - 100;
        var baseY:Float = FlxG.height / 2 + 50;

        blotRating = new FunkinSprite();

        blotRating.frames = Paths.getSparrowAtlas(
            "ui/rating/GAMEPLAY_UI_ASSETS"
        );

        blotRating.animation.addByPrefix(
            "blot",
            "blot",
            24,
            false
        );

        blotRating.scale.set(0.6, 0.6);
        blotRating.updateHitbox();

        blotRating.setPosition(
            baseX - blotRating.width / 2,
            baseY + 50 - blotRating.height / 2
        );

        blotRating.cameras = [game.camHUD];
        blotRating.scrollFactor.set();
        blotRating.zIndex = 10;
        blotRating.alpha = 0;

        game.add(blotRating);

        rankRating = new FunkinSprite();

        rankRating.frames = Paths.getSparrowAtlas(
            "ui/rating/GAMEPLAY_UI_ASSETS"
        );

        rankRating.animation.addByPrefix("sick", "sick", 24, false);
        rankRating.animation.addByPrefix("good", "good", 24, false);
        rankRating.animation.addByPrefix("bad", "bad", 24, false);
        rankRating.animation.addByPrefix("shit", "shit", 24, false);

        rankRating.scale.set(0.48, 0.48);
        rankRating.updateHitbox();

        rankRating.cameras = [game.camHUD];
        rankRating.scrollFactor.set();
        rankRating.zIndex = 11;
        rankRating.alpha = 0;

        game.add(rankRating);

        comboRating = new FunkinSprite();

        comboRating.frames = Paths.getSparrowAtlas(
            "ui/rating/GAMEPLAY_UI_ASSETS"
        );

        comboRating.animation.addByPrefix(
            "combo",
            "combo",
            24,
            false
        );

        comboRating.scale.set(0.48, 0.48);
        comboRating.updateHitbox();

        comboRating.cameras = [game.camHUD];
        comboRating.scrollFactor.set();
        comboRating.zIndex = 12;
        comboRating.alpha = 0;

        game.add(comboRating);
    }

    override function onBeatHit(event:Dynamic)
    {
        super.onBeatHit(event);

        if (!isAMtakeActive || !added || fcStatic == null || !fcStatic.exists)
            return;

        FlxTween.cancelTweensOf(fcStatic.scale);

        fcStatic.scale.set(0.45, 0.45);

        FlxTween.tween(
            fcStatic.scale,
            {x: 0.5, y: 0.5},
            0.15,
            {ease: FlxEase.quadOut}
        );
    }

    override function onNoteHit(event:Dynamic):Void
    {
        if (!isAMtakeActive || !added || game == null || !game.exists)
            return;

        if (event.note == null)
            return;

        if (event.note.isSustainNote)
            return;

        if (event.note.noteData == null)
            return;

        if (!event.note.noteData.getMustHitNote())
            return;

        var rating:String = event.judgement;

        if (rating == null)
            rating = "sick";

        if (!fcFirstHit && !fcFailed)
        {
            fcFirstHit = true;
            showFC();
        }

        if (rating == "shit" || rating == "bad")
        {
            if (!fcFailed)
            {
                fcFailed = true;
                hideFC();
            }
        }

        showRating(rating);
    }

    override function onNoteMiss(event:Dynamic):Void
    {
        super.onNoteMiss(event);

        if (!isAMtakeActive || !added)
            return;

        if (!fcFailed)
        {
            fcFailed = true;
            hideFC();
        }
    }

    function showFC():Void
    {
        if (fcStatic == null || !fcStatic.exists)
            return;

        fcStatic.alpha = 0;
        fcStatic.angle = 60;
        fcStatic.scale.set(0.7, 0.7);

        FlxTween.tween(
            fcStatic,
            {angle: 0},
            0.8,
            {ease: FlxEase.quadOut}
        );

        FlxTween.tween(
            fcStatic.scale,
            {x: 0.5, y: 0.5},
            0.8,
            {ease: FlxEase.quadOut}
        );

        FlxTween.tween(
            fcStatic,
            {alpha: 1},
            0.5,
            {ease: FlxEase.quadOut}
        );
    }

    function hideFC():Void
    {
        if (fcStatic == null || !fcStatic.exists)
            return;

        FlxTween.tween(
            fcStatic,
            {angle: -60},
            0.7,
            {ease: FlxEase.quadOut}
        );

        FlxTween.tween(
            fcStatic.scale,
            {x: 0.7, y: 0.7},
            0.7,
            {ease: FlxEase.quadOut}
        );

        FlxTween.tween(
            fcStatic,
            {alpha: 0},
            0.5,
            {ease: FlxEase.quadOut}
        );
    }

    function showRating(ratingName:String):Void
    {
        if (!isAMtakeActive || game == null || !game.exists)
            return;

        if (blotRating == null || rankRating == null || comboRating == null)
            return;

        if (!blotRating.exists || !rankRating.exists || !comboRating.exists)
            return;

        targetHue += hueStep;

        if (targetHue >= 360)
            targetHue -= 360;

        var baseX:Float = FlxG.width / 2 - 100 - 100;
        var baseY:Float = FlxG.height / 2 + 50 - 170;

        FlxTween.cancelTweensOf(blotRating);
        FlxTween.cancelTweensOf(rankRating);
        FlxTween.cancelTweensOf(comboRating);

        blotRating.setPosition(
            baseX - blotRating.width / 2,
            baseY + 50 - blotRating.height / 2
        );

        rankRating.setPosition(
            baseX - rankRating.width / 2 - 30,
            baseY + 120 - rankRating.height / 2
        );

        comboRating.setPosition(
            baseX - comboRating.width / 2 - 60,
            baseY + 190 - comboRating.height / 2
        );

        blotRating.alpha = 1;
        blotRating.angle = 3;
        blotRating.animation.play("blot", true);

        rankRating.alpha = 1;
        rankRating.angle = 3;
        rankRating.animation.play(ratingName, true);

        comboRating.alpha = 1;
        comboRating.angle = 3;
        comboRating.animation.play("combo", true);

        FlxTween.tween(
            blotRating,
            {
                alpha: 0,
                y: blotRating.y + 100,
                angle: 0
            },
            0.5,
            {
                ease: FlxEase.cubeIn,
                startDelay: 0.3
            }
        );

        FlxTween.tween(
            rankRating,
            {
                alpha: 0,
                y: rankRating.y + 100,
                angle: 0
            },
            0.5,
            {
                ease: FlxEase.cubeIn,
                startDelay: 0.3
            }
        );

        FlxTween.tween(
            comboRating,
            {
                alpha: 0,
                y: comboRating.y + 100,
                angle: 0
            },
            0.5,
            {
                ease: FlxEase.cubeIn,
                startDelay: 0.3
            }
        );
    }

    function updateScoreDigits(value:Int):Void
    {
        if (!isAMtakeActive || game == null || scoreStatic == null || !scoreStatic.exists)
            return;

        var strVal:String = Std.string(value);
        var numDigits:Int = strVal.length;

        var anchorX:Float = scoreStatic.x + scoreStatic.width - 40;
        var baseY:Float = scoreStatic.y + scoreStatic.height / 2 + 50;
        var baseScale:Float = 0.6;

        for (i in 0...scoreDigits.length)
        {
            var digit = scoreDigits[i];

            if (digit == null || !digit.exists)
                continue;

            if (i < numDigits)
            {
                var charIdx:Int = numDigits - i - 1;
                var num:Int = Std.parseInt(strVal.charAt(charIdx));

                digit.visible = true;
                digit.animation.play(num + "anim");

                var dynamicScale:Float = baseScale - (i * 0.05);

                if (dynamicScale < 0.2)
                    dynamicScale = 0.2;

                digit.scale.set(dynamicScale, dynamicScale);
                digit.updateHitbox();

                digit.x = anchorX - (i * 35);
                digit.y = baseY;
            }
            else
            {
                digit.visible = false;
            }
        }
    }

    function hslToColor(
        hue:Float,
        saturation:Float,
        lightness:Float
    ):Int
    {
        var c:Float =
            (1 - Math.abs(2 * lightness - 1)) * saturation;

        var x:Float =
            c * (1 - Math.abs((hue / 60) % 2 - 1));

        var m:Float = lightness - c / 2;

        var r:Float = 0;
        var g:Float = 0;
        var b:Float = 0;

        if (hue < 60)
        {
            r = c;
            g = x;
        }
        else if (hue < 120)
        {
            r = x;
            g = c;
        }
        else if (hue < 180)
        {
            g = c;
            b = x;
        }
        else if (hue < 240)
        {
            g = x;
            b = c;
        }
        else if (hue < 300)
        {
            r = x;
            b = c;
        }
        else
        {
            r = c;
            b = x;
        }

        return FlxColor.fromRGB(
            Std.int((r + m) * 255),
            Std.int((g + m) * 255),
            Std.int((b + m) * 255)
        );
    }

    override function onUpdate(event:Dynamic)
    {
        super.onUpdate(event);

        if (!isAMtakeActive || !added || game == null || !game.exists)
            return;

        if (blotRating != null && blotRating.exists)
        {
            blotHue = FlxMath.lerp(
                blotHue,
                targetHue,
                Math.min(1, FlxG.elapsed * smoothSpeed)
            );

            blotRating.color = hslToColor(
                blotHue % 360,
                1,
                0.5
            );
        }

        if (healthBarGreen != null && healthBarGreen.exists)
        {
            var healthPercent:Float = game.health / 2;

            healthPercent = FlxMath.bound(
                healthPercent,
                0,
                1
            );

            var fullWidth:Float = healthBarGreen.frameWidth;
            var fullHeight:Float = healthBarGreen.frameHeight;
            var visibleWidth:Float = fullWidth * healthPercent;
            var clipStart:Float = fullWidth - visibleWidth;

            healthBarGreen.clipRect = new FlxRect(
                clipStart,
                0,
                visibleWidth,
                fullHeight
            );
        }

        /*
         * VIDA BLOQUEADA DE WINTER HORRORLAND AMTAKE
         *
         * La capa morada se dibuja directamente sobre la barra roja
         * personalizada. Ya no depende de game.healthBar.
         */
        if (healthBarBlocked != null && healthBarBlocked.exists)
        {
            var currentSongId:String = "";

            if (game.currentSong != null)
                currentSongId = Std.string(game.currentSong.id);

            if (
                currentSongId == "winter-horrorland-amtake" &&
                healthSuckedVisual > 0
            )
            {
                var blockedAmount:Float = FlxMath.bound(
                    healthSuckedVisual,
                    0,
                    2
                );

                var blockedPercent:Float =
                    blockedAmount / 2;

                var blockedFullWidth:Float =
                    healthBarBlocked.frameWidth;

                var blockedFullHeight:Float =
                    healthBarBlocked.frameHeight;

                var blockedWidth:Float =
                    blockedFullWidth *
                    blockedPercent;

                /*
                 * El rojo del oponente ocupa el lado izquierdo.
                 * Por eso el recorte empieza en X = 0.
                 */
                healthBarBlocked.clipRect = new FlxRect(
                    0,
                    0,
                    blockedWidth,
                    blockedFullHeight
                );

                healthBarBlocked.visible = true;
            }
            else
            {
                healthBarBlocked.visible = false;
            }
        }

        try
        {
            updateScoreDigits(
                Std.int(Math.max(0, game.songScore))
            );
        }
        catch (e:Dynamic) {}
    }
}