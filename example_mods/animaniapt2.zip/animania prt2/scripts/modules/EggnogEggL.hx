import funkin.play.PlayState;
import funkin.modding.module.Module;
import funkin.audio.FunkinSound;

import flixel.tweens.FlxTween;
import flixel.tweens.FlxEase;

class EggnogEggL extends Module
{
	function new()
	{
		super("EggnogEggL");
	}

	function onBeatHit(event)
	{
		if (event == null)
			return;

		if (PlayState.instance == null)
			return;

		// SOLO funciona en eggnog-amtake
		if (PlayState.instance.currentSong == null)
			return;

		if (PlayState.instance.currentSong.id != "eggnog-amtake")
			return;

		var stage = PlayState.instance.currentStage;

		if (stage == null)
			return;

		var dad = stage.getDad();

		if (dad == null)
			return;

		switch (event.beat)
		{
			case 221:
				var snowman = stage.getNamedProp("snowman");

				if (snowman != null)
				{
					FlxTween.tween(
						snowman,
						{alpha: 0.4},
						0.25,
						{ease: FlxEase.backOut}
					);
				}

			case 222:
				var cops = stage.getNamedProp("cops");

				if (cops != null)
				{
					cops.playAnimation(
						"throw",
						true,
						true
					);
				}

			case 224:
				if (PlayState.instance.health > 0.3)
					PlayState.instance.health -= 0.2;

			case 226:
				dad.playAnimation(
					"eggL",
					true,
					true
				);

				var snowman = stage.getNamedProp("snowman");

				if (snowman != null)
				{
					FlxTween.tween(
						snowman,
						{alpha: 1},
						0.25,
						{ease: FlxEase.backOut}
					);
				}

			case 232:
				dad.idleSuffix = "-angry";
				dad.shouldAlternate = false;

			case 284:
				dad.idleSuffix = "-angry";
				dad.shouldAlternate = false;
		}
	}
}