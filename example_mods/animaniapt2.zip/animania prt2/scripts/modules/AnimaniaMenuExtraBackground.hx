import flixel.FlxG;
import funkin.Paths;
import funkin.graphics.FunkinSprite;
import funkin.modding.module.Module;

class AnimaniaMenuExtraBackground extends Module
{
    var extraBG:FunkinSprite = null;

    // Imagen:
    // Mods/Animania/images/menu/extraBG.png
    var imageName:String = "extraBG";

    var posX:Float = 590;
    var posY:Float = 0;

    var scaleValue:Float = 1.0;

    public function new()
    {
        super("AnimaniaMenuExtraBackground", 1);
    }

    override function onStateChangeEnd(event)
    {
        if (event == null)
            return;

        if (event.targetState == null)
            return;

        var state = event.targetState;

        // Solo en el menú principal
        if (state.menuItems != null)
        {
            createExtraBG();
        }
        else
        {
            destroyExtraBG();
        }
    }

    function createExtraBG()
    {
        if (extraBG != null)
            return;

        extraBG = new FunkinSprite();

        extraBG.loadGraphic(
            Paths.image("menu/" + imageName)
        );

        if (extraBG.graphic == null)
        {
            extraBG.destroy();
            extraBG = null;
            return;
        }

        extraBG.x = posX;
        extraBG.y = posY;

        extraBG.scale.set(
            scaleValue,
            scaleValue
        );

        extraBG.updateHitbox();

        extraBG.scrollFactor.set(0, 0);

        extraBG.antialiasing = true;

        var state = FlxG.state;

        // Primero lo añadimos al estado.
        state.add(extraBG);

        // Buscamos directamente menuItems.
        var menuIndex:Int = state.members.indexOf(state.menuItems);

        if (menuIndex >= 0)
        {
            // Lo quitamos de su posición actual.
            state.remove(extraBG, true);

            // Lo ponemos JUSTO ANTES de los botones.
            state.insert(menuIndex, extraBG);
        }
    }

    function destroyExtraBG()
    {
        if (extraBG == null)
            return;

        extraBG.kill();
        extraBG.destroy();

        extraBG = null;
    }

    override function onDestroy(event)
    {
        destroyExtraBG();
    }
}