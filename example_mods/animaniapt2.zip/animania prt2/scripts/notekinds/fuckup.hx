import funkin.play.PlayState;
import funkin.play.notes.notekind.NoteKind;
import funkin.Conductor;
import funkin.play.notes.NoteSplash;
import funkin.play.notes.NoteSprite;
import funkin.play.notes.Strumline;
import funkin.data.notestyle.NoteStyleRegistry;

import flixel.FlxG;
import flixel.util.FlxTimer;

using StringTools;

class FuckUpNoteKind extends NoteKind
{
	function new()
	{
		super("Fuck Up", "Fuck Up", "fuckup", [
			{
				name: "Custom Anim",
				description: "Custom Anim Name",
				type: "String",
				data: {
					defaultValue: ""
				}
			},
			{
				name: "valMin",
				description: "MinRandomTime",
				type: "Float",
				data: {
					min: -0.3,
					max: 0.3,
					step: 0.01,
					precision: 2,
					defaultValue: 0.1
				}
			},
			{
				name: "valMax",
				description: "MaxRandomTime",
				type: "Float",
				data: {
					min: -0.3,
					max: 0.3,
					step: 0.01,
					precision: 2,
					defaultValue: 0.2
				}
			},
			{
				name: "holdTimer",
				description: "hold Timer",
				type: "Float",
				data: {
					min: 0.0,
					max: 12,
					step: 0.1,
					precision: 2,
					defaultValue: 0
				}
			},
			{
				name: "conOrPress",
				description: "Confirm or Press",
				type: "Int",
				data: {
					min: 0,
					max: 1,
					step: 1,
					precision: 0,
					defaultValue: 1
				}
			},
			{
				name: "sex",
				description: "Reddit Mode",
				type: "Bool",
				data: {
					defaultValue: false
				}
			}
		]);

		this.scoreable = false;
	}

	override function onNoteHit(event:NoteScriptEvent)
	{
		event.cancel();
		super.onNoteHit(event);
	}

	function playForcedAnimRandom()
	{
	}

	override function onNoteMiss(event)
	{
		super.onNoteMiss(event);
	}

	override function onUpdate(event:UpdateScriptEvent)
	{
		super.onUpdate(event);
	}

	override function onNoteIncoming(event:NoteScriptEvent)
	{
		var delay:Float =
			((event.note.strumTime - Conductor.instance.songPosition) / 1000)
			- FlxG.random.float(
				event.note.getParam("valMin") ?? 0.1,
				event.note.getParam("valMax") ?? 0.2
			);

		// Evita tiempos negativos.
		if (delay < 0)
			delay = 0;

		FlxTimer.wait(delay, () ->
		{
			if (PlayState.instance == null)
				return;

			var customAnim:String = event.note.getParam("Custom Anim");
			var hasCustomAnim:Bool =
				customAnim != null &&
				customAnim.trim() != "";

			var mustHit:Bool = event.note.noteData.getMustHitNote();

			/*
			 * Si NO hay Custom Anim:
			 * usamos hitNote() normalmente.
			 *
			 * Si SÍ hay Custom Anim:
			 * NO usamos hitNote(), porque en Mobile puede
			 * disparar singLEFT/singDOWN/etc. y mezclarla
			 * con la animación personalizada.
			 */
			if (!hasCustomAnim)
			{
				var pPress:Bool =
					((event.note.getParam("conOrPress") ?? 1) == 1);

				if (!mustHit)
				{
					PlayState.instance.opponentStrumline.hitNote(
						event.note,
						false,
						pPress
					);
				}
				else
				{
					PlayState.instance.playerStrumline.hitNote(
						event.note,
						false,
						pPress
					);
				}
			}
			else
			{
				var char = PlayState.instance.currentStage?.getDad();

				if (mustHit)
				char = PlayState.instance.currentStage?.getBoyfriend();

				if (char != null)
				{
					var customHold:Float =
						event.note.getParam("holdTimer") ?? 0;

					/*
					 * Fuerza únicamente la animación personalizada.
					 */
					char.canPlayOtherAnims = true;
					char.playAnimation(customAnim, true, true);
					char.holdTimer = -customHold;
				}
			}

			/*
			 * Marcamos la nota como golpeada después
			 * de ejecutar su comportamiento.
			 */
			if (mustHit)
				event.note.hasBeenHit = true;
		});

		/*
		 * Para las notas del jugador evitamos que después
		 * sean procesadas como una nota normal.
		 */
		if (event.note.noteData.getMustHitNote())
			event.note.hasBeenHit = true;

		super.onNoteIncoming(event);
	}
}