import funkin.play.event.SongEvent;
import funkin.play.PlayState;
import funkin.data.event.SongEventSchema;
import funkin.modding.module.ModuleHandler;
import funkin.modding.events.CountdownScriptEvent;
import funkin.play.Countdown;
import funkin.play.CountdownStep;

class ConteoEvent extends SongEvent
{
	public function new()
	{
		super("CountDown");
	}

	public override function getEventSchema()
	{
		return [
			{
				name: "isPixel",
				title: "Is it pixel?",
				type: "bool",
				defaultValue: false
			},
			{
				name: "curStep",
				title: "CountDown Step",
				type: "string",
				defaultValue: "3"
			}
		];
	}

	public override function handleEvent(data):Void
	{
		if (PlayState.instance == null)
			return;

		if (PlayState.instance.currentSong == null)
			return;

		var game = PlayState.instance;

		var step:String = data.value.curStep;

		var countStep:CountdownStep = switch (step.toLowerCase())
		{
			case "3":
				CountdownStep.THREE;

			case "2":
				CountdownStep.TWO;

			case "1":
				CountdownStep.ONE;

			case "after":
				CountdownStep.AFTER;

			default:
				CountdownStep.GO;
		};

		/*
		 * Nuestro countdown personalizado.
		 */
		var module = ModuleHandler.getModule(
			"CountdownAnimAMTAKEModule"
		);

		if (module != null)
		{
			module.playCustomCountdownStep(step);
		}

		/*
		 * Reproducir el sonido original del countdown.
		 */
		Countdown.playCountdownSound(
			countStep,
			data.value.isPixel
		);

		/*
		 * Mantener el evento de script para que
		 * otros scripts puedan detectar el countdown.
		 */
		var event:ScriptEvent = new CountdownScriptEvent(
			countStep != CountdownStep.AFTER
				? "COUNTDOWN_STEP"
				: "COUNTDOWN_END",
			countStep
		);

		game.dispatchEvent(event);

		game.refresh();
	}

	public override function loadEvent():Void
	{
		trace("CountDown Event loaded");
	}

	public override function getTitle():String
	{
		return "CountDown Event";
	}
}