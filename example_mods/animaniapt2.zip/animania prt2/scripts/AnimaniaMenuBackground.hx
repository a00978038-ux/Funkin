import flixel.FlxG;
import funkin.Paths;
import funkin.graphics.FunkinSprite;
import funkin.modding.module.Module;

class AnimaniaMenuBackground extends Module
{
    var caramel:FunkinSprite = null;

    var imageName:String = "caramen-dance";
    var posX:Float = -75;
    var posY:Float = 225;
    var scaleValue:Float = 1.1;
    var layerValue:Int = 1;
    var animationName:String = "caramel";

    public function new()
    {
        super("AnimaniaMenuBackground", 1);
    }

    override function onStateChangeEnd(event)
    {
        if (event == null)
            return;

        if (event.targetState == null)
            return;

        var state = event.targetState;

        /*
         * Por ahora solamente comprobamos si el estado
         * tiene menuItems.
         */
        if (state.menuItems != null)
        {
            createCaramel();
        }
        else
        {
            destroyCaramel();
        }
    }

    function createCaramel()
    {
        if (caramel != null)
            return;

        caramel = new FunkinSprite();

        caramel.frames = Paths.getSparrowAtlas(
            "menu/" + imageName
        );

        if (caramel.frames == null)
        {
            caramel.destroy();
            caramel = null;
            return;
        }

        caramel.animation.addByPrefix(
            animationName,
            "caramel",
            24,
            true
        );

        caramel.animation.play(
            animationName,
            true
        );

        /*
         * Valores del JSON original.
         */
        caramel.x = posX;
        caramel.y = posY;

        caramel.scale.set(
            scaleValue,
            scaleValue
        );

        caramel.updateHitbox();

        caramel.scrollFactor.set(0, 0);

        caramel.zIndex = layerValue;

        caramel.antialiasing = true;

        FlxG.state.add(caramel);
    }

    function destroyCaramel()
    {
        if (caramel == null)
            return;

        caramel.kill();
        caramel.destroy();

        caramel = null;
    }

    override function onDestroy(event)
    {
        destroyCaramel();
    }
}