import funkin.play.character.AnimateAtlasCharacter;
import funkin.play.character.CharacterType;

class DadAMtakeCharacter extends AnimateAtlasCharacter
{
	function new()
	{
		super('dad-AMtake');
	}

	function onCreate()
	{
		super.onCreate();
	}

	public override function playAnimation(
		name:String,
		restart:Bool = false,
		ignoreOther:Bool = false,
		reversed:Bool = false
	):Void
	{
		switch (name)
		{
			case "angy":
				idleSuffix = "-angry";

			case "imok":
				idleSuffix = "";

			default:
				super.playAnimation(
					name,
					restart,
					ignoreOther,
					reversed
				);
		}
	}

	function onNoteHit(event:HitNoteScriptEvent)
	{
		if (event.note.noteData.getMustHitNote())
			return;

		if (characterType != CharacterType.DAD)
			return;

		if (event.eventCanceled)
			return;

		if (event.note.holdNoteSprite != null)
		{
			lastHoldFinish =
				event.note.strumTime +
				event.note.noteData.length;
		}

		switch (event.note.kind)
		{
			case "mom":
				holdTimer = 0;

				this.playSingAnimation(
					event.note.noteData.getDirection(),
					false,
					"alt"
				);

			case "beatbox":
				holdTimer = 0;

				this.playSingAnimation(
					event.note.noteData.getDirection(),
					false,
					"beatbox"
				);

			default:
				holdTimer = 0;

				this.playSingAnimation(
					event.note.noteData.getDirection(),
					false,
					idleSuffix.indexOf("angry") != -1
						? "angry"
						: ""
				);
		}
	}

	function initHealthIcon(isOpponent:Bool)
	{
		return super.initHealthIcon(isOpponent);
	}
}