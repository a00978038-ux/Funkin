import funkin.play.character.MultiAnimateAtlasCharacter;
import funkin.play.character.CharacterType;
import funkin.play.PlayState;
import flixel.util.FlxTimerManager;
import funkin.play.GameOverSubState;
import funkin.FunkinMemory;

class BoyfriendAmtakeCharacter extends MultiAnimateAtlasCharacter
{
	function new()
	{
		super('boyfriendAMtake');
	}

	function onCreate(e)
	{
		super.onCreate(e);

		ignoreExclusionPref.push("singDOWN");

		// Descomenta esta línea si quieres que BF
		// utilice las variantes angry desde el inicio.
		// idleSuffix = "-angry";
	}

	function onNoteHit(event:HitNoteScriptEvent)
	{
		// Nota especial: stop bope
		if (event?.note?.kind == "stop bope")
		{
			canPlayOtherAnims = true;
			playAnimation("singDOWN", true, true);
			return;
		}

		// Solo procesar notas del jugador BF
		if (event.note.noteData.getMustHitNote()
			&& characterType == CharacterType.BF
			&& !event.eventCanceled)
		{
			// Hold note
			if (event.note.holdNoteSprite != null)
			{
				lastHoldFinish =
					event.note.strumTime +
					event.note.noteData.length;
			}

			holdTimer = 0;

			switch (event.note.kind)
			{
				// Beatbox
				case "beatbox":
					this.playSingAnimation(
						event.note.noteData.getDirection(),
						false,
						"beatbox"
					);

				// Blush
				case "blush":
					this.playSingAnimation(
						event.note.noteData.getDirection(),
						false,
						"blush"
					);

				// Mom
				case "mom":
					this.playSingAnimation(
						event.note.noteData.getDirection(),
						false, 'alt' + (idleSuffix.indexOf("angry") != -1
							? "-angry"
							: ""
					));

				// Fresh
				case "fresh":
					this.playSingAnimation(
						event.note.noteData.getDirection(),
						false,
						"fresh"
					);

				// Cheer
				case "cheer":
					playAnimation("hey", true, false);

				// Cheer alternate
				case "cheer-alt":
					playAnimation("cheer-alt", true, false);

				// Erect up
				case "erect-up":
					playAnimation("erect up", true, false);

				// Normal note
				default:
					this.playSingAnimation(
						event.note.noteData.getDirection(),
						false,
						idleSuffix.indexOf("angry") != -1
							? "angry"
							: ""
					);
			}
		}
	}

	function onNoteMiss(event)
	{
		// Solo procesar notas del jugador BF
		if (event.note.noteData.getMustHitNote()
			&& characterType == CharacterType.BF
			&& !event.eventCanceled)
		{
			lastHoldFinish = null;
			holdTimer = 0;

			switch (event.note.kind)
			{
				// Mom miss
				case "mom":
					this.playSingAnimation(
						event.note.noteData.getDirection(),
						true,
						"alt"
					);

				// Fresh miss
				case "fresh":
					this.playSingAnimation(
						event.note.noteData.getDirection(),
						true,
						"fresh"
					);

				// Normal miss
				default:
					this.playSingAnimation(
						event.note.noteData.getDirection(),
						true,
						""
					);
			}
		}
	}

	/**
	 * Icono de vida.
	 *
	 * Se utiliza el sistema normal de V-Slice Mobile.
	 * Se eliminó scriptCall() porque no existe
	 * en el objeto Module de esta versión.
	 */
	function initHealthIcon(isOpponent:Bool)
	{
		return super.initHealthIcon(isOpponent);
	}

	/**
	 * Variables conservadas del script original.
	 */
	var coolDeathSprite:FunkinSprite;
	var deathTimerManager:FlxTimerManager;

	/**
	 * Animaciones que necesitan mantener el holdTimer
	 * durante más tiempo.
	 */
	override function playAnimation(
		name:String,
		restart:Bool = false,
		ignoreOther:Bool = false,
		reverse:Bool = false
	):Void
	{
		if (name == "erect up")
		{
			holdTimer = -5;
		}

		if (name == "cheer-alt")
		{
			holdTimer = -12;
		}

		super.playAnimation(
			name,
			restart,
			ignoreOther,
			reverse
		);
	}

	/**
	 * Finalización de animaciones.
	 */
	override function onAnimationFinished(prefix:String):Void
	{
		switch (prefix)
		{
			case "cheer-alt":
				// No hacer nada especial.

			default:
				super.onAnimationFinished(prefix);
		}
	}
}