import funkin.play.character.MultiAnimateAtlasCharacter;
import funkin.play.character.CharacterType;
import funkin.play.GameOverSubState;

import flixel.tweens.FlxEase;
import flixel.tweens.FlxTween;
import flixel.FlxG;

class XMasAmTakeBoyfriendCharacter extends MultiAnimateAtlasCharacter
{
	function new()
	{
		super('bf-christmas-amtake');
	}

	function onCreate(event:ScriptEvent)
	{
		super.onCreate(event);

		GameOverSubState.musicSuffix = '-xmas';
		GameOverSubState.blueBallSuffix = '-xmas';
	}

	function onNoteHit(event:HitNoteScriptEvent)
	{
		if (event.note == null)
			return;

		if (event.note.noteData.getMustHitNote()
			&& characterType == CharacterType.BF
			&& !event.eventCanceled)
		{
			if (event.note.holdNoteSprite != null)
			{
				lastHoldFinish =
					event.note.strumTime + event.note.noteData.length;
			}

			switch (event.note.kind)
			{
				case "mom":
					holdTimer = 0;

					playSingAnimation(
						event.note.noteData.getDirection(),
						false,
						"alt"
					);

					return;

				case "cheer":
					holdTimer = 0;
					playAnimation("hey", true, false);
					return;

				default:
					holdTimer = 0;

					playSingAnimation(
						event.note.noteData.getDirection(),
						false,
						""
					);

					return;
			}
		}
	}

	function onNoteMiss(event:NoteScriptEvent)
	{
		if (event.note == null)
			return;

		if (event.note.noteData.getMustHitNote()
			&& characterType == CharacterType.BF
			&& !event.eventCanceled)
		{
			switch (event.note.kind)
			{
				case "mom":
					holdTimer = 0;

					playSingAnimation(
						event.note.noteData.getDirection(),
						true,
						"alt"
					);

					return;

				case "fresh":
					holdTimer = 0;

					playSingAnimation(
						event.note.noteData.getDirection(),
						true,
						"both"
					);

					return;

				default:
					holdTimer = 0;

					playSingAnimation(
						event.note.noteData.getDirection(),
						true,
						""
					);

					return;
			}
		}

		super.onNoteMiss(event);
	}

	function initHealthIcon(isOpponent:Bool)
	{
		return super.initHealthIcon(isOpponent);
	}

	function playAnimation(
		name:String,
		restart:Bool,
		ignoreOther:Bool
	)
	{
		if (!debug)
		{
			switch (name)
			{
				case "firstDeath", "firstDeath-wh":
					shader = null;

				case "deathLoop", "deathLoop-wh":

				case "deathConfirm", "deathConfirm-wh":
					if (GameOverSubState.instance != null)
					{
						GameOverSubState.instance.targetCameraZoom *= 1.15;

						FlxTween.tween(
							FlxG.camera,
							{
								zoom: GameOverSubState.instance.targetCameraZoom
							},
							2,
							{
								ease: FlxEase.backOut
							}
						);

						GameOverSubState.instance.cameraFollowPoint.x += 225;
						GameOverSubState.instance.cameraFollowPoint.y -= 75;
					}
			}
		}

		super.playAnimation(
			name,
			restart,
			ignoreOther
		);
	}
}
