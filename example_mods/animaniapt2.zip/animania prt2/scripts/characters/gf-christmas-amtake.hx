import funkin.play.character.AnimateAtlasCharacter;
import funkin.play.PlayState;
import funkin.graphics.FunkinSprite;

class GirlfriendChristmasCharacter extends AnimateAtlasCharacter
{
	function new()
	{
		super('gf-christmas-amtake');
	}

	var fgSnow:FunkinSprite;

	override function onAnimationFinished(prefix:String):Void
	{
		switch (prefix)
		{
			case "combo251":
				hasDanced = false;
				super.onAnimationFinished(prefix);

			default:
				super.onAnimationFinished(prefix);
		}
	}

	override function onUpdate(e)
	{
	}
}