import funkin.play.character.AnimateAtlasCharacter;
import funkin.play.character.CharacterType;
import funkin.play.PlayState;
import funkin.modding.module.Module;
import funkin.modding.module.ModuleHandler;


class DadBeastCharacter extends AnimateAtlasCharacter {
	function new() {
		super('dad-beast');
	}

	function onCreate()
	{
		super.onCreate();
		//idleSuffix = "-alt";
	}

	function onNoteHit(event:HitNoteScriptEvent)
	{
		if (!event.note.noteData.getMustHitNote() && characterType == CharacterType.DAD && !event.eventCanceled) {
			if (event.note.holdNoteSprite != null) lastHoldFinish = event.note.strumTime + event.note.noteData.length;
			switch(event.note.kind) {
				case "mom":
					holdTimer = 0;
					this.playSingAnimation(event.note.noteData.getDirection(), false, 'alt');
					return;

				default:
					holdTimer = 0;
					this.playSingAnimation(event.note.noteData.getDirection(), false, "");
					return;
			}
		}
		//super.onNoteHit(event);
	}

	var DEATH_THRESHOLD:Float = 0.2 * 2;
	var LOSING_THRESHOLD:Float = 0.3 * 2;
	var WINING_THRESHOLD:Float = 0.8 * 2;



}
