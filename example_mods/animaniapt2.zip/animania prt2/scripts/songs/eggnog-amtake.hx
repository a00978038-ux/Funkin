import funkin.play.song.Song;
import funkin.play.PlayState;
import funkin.play.PlayStatePlaylist;
import funkin.audio.FunkinSound;
import funkin.graphics.FunkinSprite;
import funkin.save.Save;

import flixel.util.FlxColor;
import flixel.tweens.FlxEase;
import flixel.util.FlxTimer;

class EggnogAmtakeSong extends Song
{
	/*
	 * =========================================================
	 * CONSTRUCTOR
	 * =========================================================
	 */

	public function new()
	{
		super('eggnog-amtake');
	}


	/*
	 * =========================================================
	 * CUTSCENE
	 * =========================================================
	 */

	var hasPlayedCutscene:Bool = false;


	/*
	 * =========================================================
	 * HEALTH DRAIN
	 * =========================================================
	 *
	 * Usa la misma opción que DadbattleAmtakeSong:
	 *
	 *     DadBeastHealthDrain
	 *
	 * ON  = El oponente drena vida.
	 * OFF = No drena vida.
	 *
	 * La vida nunca baja de 0.10 mediante el drenaje.
	 */

	static var HEALTH_DRAIN_OPTION:String =
		"DadBeastHealthDrain";


	var healthDrainPerNote:Float =
		0.035;


	var healthDrainMinimum:Float =
		0.10;


	var lethalMissPending:Bool =
		false;


	/*
	 * =========================================================
	 * COMPROBAR HEALTH DRAIN
	 * =========================================================
	 */

	function isHealthDrainEnabled():Bool
	{
		if (Save.instance == null)
			return false;


		var optionValue =
			Save.instance.modOptions.get(
				HEALTH_DRAIN_OPTION
			);


		if (optionValue == null)
			return false;


		return optionValue == true;
	}


	/*
	 * =========================================================
	 * UPDATE
	 * =========================================================
	 *
	 * Procesa una muerte pendiente.
	 *
	 * Esto se utiliza cuando el jugador falla una nota
	 * estando exactamente en el mínimo de vida.
	 */

	override function onUpdate(
		event:UpdateScriptEvent
	):Void
	{
		super.onUpdate(event);


		if (!lethalMissPending)
			return;


		var state =
			PlayState.instance;


		if (state == null)
			return;


		state.health = 0;


		lethalMissPending = false;
	}


	/*
	 * =========================================================
	 * NOTA DEL OPONENTE
	 * =========================================================
	 *
	 * Cada nota normal acertada por el oponente
	 * provoca daño a la vida del jugador.
	 */

	override function onNoteHit(
		event:HitNoteScriptEvent
	):Void
	{
		super.onNoteHit(event);


		/*
		 * Health Damage OFF.
		 */

		if (!isHealthDrainEnabled())
			return;


		/*
		 * Si por alguna razón se está reproduciendo
		 * la cutscene final, no aplicar daño.
		 */

		if (event.note == null)
			return;


		/*
		 * Si la nota pertenece al jugador,
		 * no hacer nada.
		 */

		if (
			event.note.noteData.getMustHitNote()
		)
		{
			return;
		}


		var state =
			PlayState.instance;


		if (state == null)
			return;


		/*
		 * =====================================================
		 * VIDA ACTUAL
		 * =====================================================
		 */

		var currentHealth:Float =
			state.health;


		/*
		 * Si ya estamos en el mínimo,
		 * no seguir drenando.
		 */

		if (
			currentHealth <=
			healthDrainMinimum
		)
		{
			event.healthChange = 0;
			return;
		}


		/*
		 * =====================================================
		 * DAÑO
		 * =====================================================
		 */

		var damage:Float =
			healthDrainPerNote;


		/*
		 * Evitar bajar de 0.10.
		 */

		if (
			currentHealth - damage <
			healthDrainMinimum
		)
		{
			damage =
				currentHealth -
				healthDrainMinimum;
		}


		/*
		 * Aplicar el daño mediante el sistema
		 * de healthChange del NoteHit.
		 */

		event.healthChange =
			-damage;
	}


	/*
	 * =========================================================
	 * NOTA FALLADA
	 * =========================================================
	 *
	 * Si el jugador falla una nota estando en 0.10,
	 * se permite que ocurra el Game Over.
	 */

	override function onNoteMiss(
		event:NoteScriptEvent
	):Void
	{
		var state =
			PlayState.instance;


		var shouldKill:Bool =
			false;


		if (
			state != null &&
			isHealthDrainEnabled() &&
			event.note != null
		)
		{
			/*
			 * Solamente las notas del jugador.
			 */

			if (
				event.note.noteData.getMustHitNote() &&
				state.health <= healthDrainMinimum
			)
			{
				shouldKill = true;
			}
		}


		/*
		 * Mantener el comportamiento normal
		 * de onNoteMiss.
		 */

		super.onNoteMiss(event);


		/*
		 * La muerte se procesa en onUpdate().
		 */

		if (shouldKill)
			lethalMissPending = true;
	}


	/*
	 * =========================================================
	 * SONG END / CUTSCENE
	 * =========================================================
	 */

	public override function onSongEnd(
		event:CountdownScriptEvent
	):Void
	{
		super.onSongEnd(event);


		if (!PlayStatePlaylist.isStoryMode)
		{
			hasPlayedCutscene = true;
		}


		if (!hasPlayedCutscene)
		{
			hasPlayedCutscene = true;


			event.cancel();


			PlayState.instance.disableKeys =
				true;


			var blacky =
				new FunkinSprite();


			blacky.makeGraphic(
				1,
				1,
				FlxColor.BLACK
			);


			blacky.scale.set(
				2000,
				2000
			);


			blacky.scrollFactor.set();


			blacky.screenCenter();


			blacky.alpha =
				0;


			blacky.zIndex =
				999999;


			PlayState.instance.currentStage.add(
				blacky
			);


			PlayState.instance.currentStage.refresh();


			var parents =
				PlayState.instance.currentStage.getDad();


			parents.isDead =
				true;


			PlayState.instance.tweenCameraZoom(
				1.5,
				7.5,
				false,
				FlxEase.backOut
			);


			PlayState.instance.tweenCameraToPosition(
				-550,
				-70,
				7.25,
				FlxEase.backOut
			);


			FlxTimer.wait(
				1.75,
				() ->
				{
					parents.playAnimation(
						"endCutscene",
						true,
						true
					);


					FunkinSound.playOnce(
						Paths.sound(
							"gameplay/stages/CityMall/parentsPress"
						)
					);


					parents.animation.onFrameChange.add(
						(n, f, i) ->
						{
							if (f == 39)
							{
								PlayState.instance.camHUD.alpha =
									0.001;


								FunkinSound.playOnce(
									Paths.sound(
										"gameplay/stages/CityMall/lightsOff"
									)
								);


								blacky.alpha =
									1;


								parents.zIndex =
									101000100;


								PlayState.instance.currentStage.refresh();
							}
						}
					);
				}
			);


			FlxTimer.wait(
				6.75,
				() ->
				{
					PlayState.instance.endSong(
						true
					);
				}
			);
		}
		else
		{
			hasPlayedCutscene =
				false;
		}
	}
}