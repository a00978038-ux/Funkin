import funkin.play.song.Song;
import funkin.play.PlayState;
import funkin.save.Save;

import flixel.tweens.FlxTween;
import flixel.tweens.FlxEase;

class BopeeboAmtakeSong extends Song
{
	/*
	 * =========================================================
	 * HEALTH DRAIN
	 * =========================================================
	 */

	static var HEALTH_DRAIN_OPTION:String =
		"DadBeastHealthDrain";

	var healthDrainPerNote:Float =
		0.035;

	var healthDrainMinimum:Float =
		0.10;

	var lethalMissPending:Bool =
		false;


	/*
	 * =========================================================
	 * CONSTRUCTOR
	 * =========================================================
	 */

	public function new()
	{
		super("bopeebo-amtake");
	}


	/*
	 * =========================================================
	 * COMPROBAR HEALTH DRAIN
	 * =========================================================
	 */

	function isHealthDrainEnabled():Bool
	{
		if (Save.instance == null)
			return false;

		var optionValue =
			Save.instance.modOptions.get(
				HEALTH_DRAIN_OPTION
			);

		if (optionValue == null)
			return false;

		return optionValue == true;
	}


	/*
	 * =========================================================
	 * UPDATE
	 * =========================================================
	 */

	override function onUpdate(
		event:UpdateScriptEvent
	):Void
	{
		super.onUpdate(event);

		if (!lethalMissPending)
			return;

		var state =
			PlayState.instance;

		if (state == null)
			return;

		state.health = 0;

		lethalMissPending = false;
	}


	/*
	 * =========================================================
	 * HEALTH DRAIN - NOTAS DEL OPONENTE
	 * =========================================================
	 */

	override function onNoteHit(
		event:HitNoteScriptEvent
	):Void
	{
		super.onNoteHit(event);

		if (!isHealthDrainEnabled())
			return;

		if (event.note == null)
			return;

		// No aplicar drain a las notas del jugador.
		if (
			event.note.noteData.getMustHitNote()
		)
		{
			return;
		}

		var state =
			PlayState.instance;

		if (state == null)
			return;

		var currentHealth:Float =
			state.health;

		// El drain nunca baja de 0.10.
		if (
			currentHealth <=
			healthDrainMinimum
		)
		{
			event.healthChange = 0;
			return;
		}

		var damage:Float =
			healthDrainPerNote;

		// Evitar bajar de 0.10.
		if (
			currentHealth - damage <
			healthDrainMinimum
		)
		{
			damage =
				currentHealth -
				healthDrainMinimum;
		}

		event.healthChange =
			-damage;
	}


	/*
	 * =========================================================
	 * NOTA FALLADA
	 * =========================================================
	 */

	override function onNoteMiss(
		event:NoteScriptEvent
	):Void
	{
		var state =
			PlayState.instance;

		var shouldKill:Bool =
			false;

		if (
			state != null &&
			isHealthDrainEnabled() &&
			event.note != null
		)
		{
			if (
				event.note.noteData.getMustHitNote() &&
				state.health <= healthDrainMinimum
			)
			{
				shouldKill = true;
			}
		}

		super.onNoteMiss(event);

		if (shouldKill)
			lethalMissPending = true;
	}


	/*
	 * =========================================================
	 * BEAT 96 - VIN2
	 * =========================================================
	 */

	override function onBeatHit(
		event:SongTimeScriptEvent
	):Void
	{
		super.onBeatHit(event);

		if (event.beat == 96)
		{
			var state =
				PlayState.instance;

			if (state == null)
				return;

			if (state.currentStage == null)
				return;

			var vin2 =
				state.currentStage.getNamedProp("vin2");

			if (vin2 == null)
				return;

			FlxTween.cancelTweensOf(vin2);

			// Original de funnies.hx:
			// 0.25 segundos hasta alpha 0.6.
			FlxTween.tween(
				vin2,
				{alpha: 0.6},
				0.25,
				{
					ease: FlxEase.cubeIn,

					onComplete: function(tween)
					{
						// Después desaparece
						// lentamente durante 9 segundos.
						FlxTween.tween(
							vin2,
							{alpha: 0},
							9,
							{
								ease:
									FlxEase.sineInOut
							}
						);
					}
				}
			);
		}
	}
}