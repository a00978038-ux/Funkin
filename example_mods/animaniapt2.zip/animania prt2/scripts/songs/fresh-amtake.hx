import funkin.play.song.Song;
import funkin.play.PlayState;
import funkin.audio.FunkinSound;
import funkin.Paths;
import funkin.graphics.FunkinSprite;
import funkin.save.Save;

import flixel.FlxG;
import flixel.FlxSprite;
import flixel.util.FlxColor;
import flixel.tweens.FlxTween;
import flixel.tweens.FlxEase;

import openfl.display.BlendMode;

class FreshSongMobile extends Song
{
	var sfxSounds:FunkinSound = null;

	var blackScreen:FlxSprite = null;
	var soloTime:FunkinSprite = null;

	var soloTurnActive:Bool = false;
	var soloTurnTime:Float = 0;

	var ver:FunkinSprite = null;

	var gfSoloActive:Bool = false;
	var gfEventStarted:Bool = false;
	var gfEventTime:Float = 0;

	var gfSymb333:Bool = false;
	var gfSymb369:Bool = false;
	var gfSymb371:Bool = false;
	var gfSymb377:Bool = false;
	var gfSymb379:Bool = false;
	var gfSymb381:Bool = false;
	var gfSymb383:Bool = false;
	var gfSymb387:Bool = false;
	var gfSymb389:Bool = false;

	var dadOriginalZ:Int = 0;
	var dadZSaved:Bool = false;

	static var HEALTH_DRAIN_OPTION:String =
		"DadBeastHealthDrain";

	var healthDrainPerNote:Float =
		0.035;

	var healthDrainMinimum:Float =
		0.10;

	var lethalMissPending:Bool =
		false;


	public function new()
	{
		super("fresh-amtake");
	}

	function isHealthDrainEnabled():Bool
	{
		if (Save.instance == null)
			return false;

		var optionValue =
			Save.instance.modOptions.get(
				HEALTH_DRAIN_OPTION
			);

		if (optionValue == null)
			return false;

		return optionValue == true;
	}


	override function onCreate(event):Void
	{
		super.onCreate(event);

		// Reinicia la referencia al volver a entrar a la canción.
		// El sprite anterior pertenece al PlayState viejo y no debe reutilizarse.
		if (blackScreen != null)
		{
			FlxTween.cancelTweensOf(blackScreen);
		}

		blackScreen = null;

		var state = PlayState.instance;

		if (state == null)
			return;

		if (state.currentStage == null)
			return;

		var dad = state.currentStage.getDad();

		if (dad != null)
		{
			dadOriginalZ = dad.zIndex;
			dadZSaved = true;

			dad.idleSuffix = "";
		}

		var gf = state.currentStage.getGirlfriend();

		if (gf != null)
		{
			ver = new FunkinSprite();

			ver.loadGraphic(
				Paths.image(
					"stages/mainStageAmTake/gf_event",
					"shared"
				)
			);

			ver.zIndex = gf.zIndex - 1;

			ver.x = 520;
			ver.y = -580;

			ver.visible = false;

			// Igual que el original.
			ver.y -= 800;

			state.currentStage.add(
				ver
			);
		}

		soloTime = new FunkinSprite(
			0,
			0,
			Paths.animateAtlas(
				"stages/mainStageAmTake/solotime_cardboard",
				"shared"
			)
		);

		soloTime.zIndex = 8;

		soloTime.anim.addByFrameLabel(
			"off",
			"off loop",
			24,
			false
		);

		soloTime.anim.addByFrameLabel(
			"turn",
			"turned on",
			24,
			false
		);

		soloTime.anim.addByFrameLabel(
			"on",
			"on loop",
			24,
			true
		);

		soloTime.anim.play(
			"off",
			true
		);

		soloTime.applyStageMatrix = true;

		state.currentStage.add(
			soloTime
		);

		soloTime.x += 325;
		soloTime.y -= 350;
		soloTime.y -= 800;

		state.currentStage.refresh();
	}


	override function onCountdownStart(event):Void
	{
		super.onCountdownStart(event);

		var state = PlayState.instance;

		if (
			state != null
			&& state.currentStage != null
		)
		{
			var dad = state.currentStage.getDad();

			if (dad != null)
			{
				dad.idleSuffix = "";

				dad.playAnimation(
					"idle",
					true,
					true
				);
			}
		}

		sfxSounds = FunkinSound.load(
			Paths.inst(
				"fresh-amtake",
				"-sfx"
			)
		);

		if (sfxSounds != null)
		{
			sfxSounds.volume = 1;
		}
	}


	override function onSongStart(event):Void
	{
		super.onSongStart(event);

		var state = PlayState.instance;

		if (
			state != null
			&& state.currentStage != null
		)
		{
			var dad = state.currentStage.getDad();

			if (dad != null)
			{
				dad.idleSuffix = "";

				dad.playAnimation(
					"idle",
					true,
					true
				);
			}
		}

		if (sfxSounds != null)
		{
			sfxSounds.volume = 1;

			sfxSounds.play(true);
		}
	}

	override function onUpdate(event):Void
	{
		super.onUpdate(event);

		var state = PlayState.instance;

		if (state == null)
			return;

		if (lethalMissPending)
		{
			state.health = 0;

			lethalMissPending = false;

			return;
		}


		if (state.currentStage == null)
			return;

		if (soloTurnActive)
		{
			soloTurnTime += event.elapsed;

			if (soloTurnTime >= 1.0)
			{
				soloTurnActive = false;

				if (soloTime != null)
				{
					soloTime.anim.play(
						"on",
						true
					);
				}
			}
		}

		var gf = state.currentStage.getGirlfriend();

		if (gf == null)
			return;

		var currentAnim = gf.getCurrentAnimation();

		if (currentAnim == "fresh solo")
		{
			if (!gfSoloActive)
			{
				gfSoloActive = true;

				startGFEvent();
			}
		}
		else
		{
			if (gfSoloActive)
			{
				gfSoloActive = false;
			}
		}

		if (gfEventStarted)
		{
			gfEventTime += event.elapsed;

			if (
				!gfSymb333
				&& gfEventTime >= 13.875
			)
			{
				gfSymb333 = true;

				if (ver != null)
				{
					ver.zIndex = gf.zIndex + 1;

					state.currentStage.refresh();
				}
			}

			if (
				!gfSymb369
				&& gfEventTime >= 15.375
			)
			{
				gfSymb369 = true;

				if (ver != null)
				{
					ver.zIndex = gf.zIndex - 1;

					state.currentStage.refresh();
				}
			}

			if (
				!gfSymb371
				&& gfEventTime >= 15.458333
			)
			{
				gfSymb371 = true;

				if (ver != null)
				{
					ver.y += 2;
				}
			}

			if (
				!gfSymb377
				&& gfEventTime >= 15.708333
			)
			{
				gfSymb377 = true;

				if (ver != null)
				{
					ver.y += 2;
				}
			}

			if (
				!gfSymb379
				&& gfEventTime >= 15.791667
			)
			{
				gfSymb379 = true;

				if (ver != null)
				{
					ver.y += 5;
				}
			}

			if (
				!gfSymb381
				&& gfEventTime >= 15.875
			)
			{
				gfSymb381 = true;

				if (ver != null)
				{
					ver.y -= 5;
				}
			}

			if (
				!gfSymb383
				&& gfEventTime >= 15.958333
			)
			{
				gfSymb383 = true;

				if (ver != null)
				{
					ver.y -= 4;
				}
			}

			if (
				!gfSymb387
				&& gfEventTime >= 16.125
			)
			{
				gfSymb387 = true;

				if (ver != null)
				{
					ver.zIndex = 12;

					state.currentStage.refresh();
				}
			}

			if (
				!gfSymb389
				&& gfEventTime >= 16.208333
			)
			{
				gfSymb389 = true;

				if (ver != null)
				{
					FlxTween.cancelTweensOf(
						ver
					);

					FlxTween.tween(
						ver,
						{
							y: ver.y - 800
						},
						4,
						{
							ease:
								FlxEase.cubeIn
						}
					);
				}
			}
		}
	}

	override function onNoteHit(
		event:HitNoteScriptEvent
	):Void
	{
		super.onNoteHit(event);

		if (!isHealthDrainEnabled())
			return;

		if (event.note == null)
			return;

		if (
			event.note.noteData.getMustHitNote()
		)
		{
			return;
		}

		var state =
			PlayState.instance;

		if (state == null)
			return;

		var currentHealth:Float =
			state.health;

		if (
			currentHealth <=
			healthDrainMinimum
		)
		{
			event.healthChange = 0;
			return;
		}

		var damage:Float =
			healthDrainPerNote;

		if (
			currentHealth - damage <
			healthDrainMinimum
		)
		{
			damage =
				currentHealth -
				healthDrainMinimum;
		}

		event.healthChange =
			-damage;
	}

	override function onNoteMiss(
		event:NoteScriptEvent
	):Void
	{
		var state =
			PlayState.instance;

		var shouldKill:Bool =
			false;

		if (
			state != null &&
			isHealthDrainEnabled() &&
			event.note != null
		)
		{
			if (
				event.note.noteData.getMustHitNote() &&
				state.health <= healthDrainMinimum
			)
			{
				shouldKill = true;
			}
		}

		super.onNoteMiss(event);

		if (shouldKill)
			lethalMissPending = true;
	}


	function startGFEvent():Void
	{
		if (gfEventStarted)
			return;

		if (ver == null)
			return;

		gfEventStarted = true;
		gfEventTime = 0;

		gfSymb333 = false;
		gfSymb369 = false;
		gfSymb371 = false;
		gfSymb377 = false;
		gfSymb379 = false;
		gfSymb381 = false;
		gfSymb383 = false;
		gfSymb387 = false;
		gfSymb389 = false;

		ver.visible = true;

		FlxTween.cancelTweensOf(
			ver
		);

		FlxTween.tween(
			ver,
			{
				y: ver.y + 800
			},
			6,
			{
				startDelay: 6,

				ease:
					FlxEase.cubeOut
			}
		);
	}


	function createBlackScreenIfNeede