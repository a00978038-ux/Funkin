import funkin.play.song.Song;
import funkin.play.PlayState;
import funkin.play.cutscene.VideoCutscene;
import funkin.Paths;
import funkin.graphics.video.FunkinVideoSprite;
import funkin.graphics.shaders.RuntimeRainShader;
import funkin.save.Save;
import funkin.Preferences;

import flixel.FlxG;
import flixel.FlxSprite;
import flixel.util.FlxColor;
import flixel.addons.display.FlxRuntimeShader;
import flixel.tweens.FlxTween;
import flixel.tweens.FlxEase;

import openfl.filters.ShaderFilter;
import openfl.utils.Assets;

class DadbattleAmtakeSong extends Song
{
    var loadingCountdownSkipped:Bool = false;
	var hasPlayedCutscene:Bool = false;
	var hasPlayedMidVideo:Bool = false;

	var midVideo:FunkinVideoSprite = null;
	var midVideoPlaying:Bool = false;

	var soloTimeEndBeat:Int = 223;

	static var HEALTH_DRAIN_OPTION:String = "DadBeastHealthDrain";

	var healthDrainPerNote:Float = 0.035;
	var healthDrainMinimum:Float = 0.10;

	var lethalMissPending:Bool = false;

	var rainShader:RuntimeRainShader = null;
	var rainShaderFilter:ShaderFilter = null;
	var rainShaderEnabled:Bool = false;
	var rainIntensity:Float = 0.20;

	var chromShader:FlxRuntimeShader = null;
	var chromShaderFilter:ShaderFilter = null;
	var chromChangeTween:FlxTween = null;

	var godRaysShader:FlxRuntimeShader = null;
	var godRaysSpr:FlxSprite = null;

	var endScreen:FlxSprite = null;
	var endScreenTween:FlxTween = null;

	var inIdle:Bool = true;
	var funnyA:Float = -300;

	var playerBaseX:Float = 0;
	var playerBaseY:Float = 0;

	// Ajuste de color para los personajes


	var godlight:String = "
#pragma header

uniform float iTime;
uniform vec2 resolution;
uniform vec3 rayColor;

float rayStrength(
	vec2 raySource,
	vec2 rayRefDirection,
	vec2 coord,
	float seedA,
	float seedB,
	float speed
)
{
	vec2 sourceToCoord =
		coord - raySource;

	float cosAngle =
		dot(
			normalize(sourceToCoord),
			rayRefDirection
		);

	return clamp(
		(
			0.45 +
			0.15 *
			sin(
				cosAngle *
				seedA +
				iTime *
				speed
			)
		) +
		(
			0.30 +
			0.20 *
			cos(
				-cosAngle *
				seedB +
				iTime *
				speed
			)
		),
		0.0,
		1.0
	) *
	clamp(
		(
			resolution.x -
			length(sourceToCoord)
		) / resolution.x,
		0.5,
		1.0
	);
}

void main()
{
	vec2 uv =
		openfl_TextureCoordv;

	vec2 coord =
		vec2(
			uv.x * resolution.x,
			(1.0 - uv.y) * resolution.y
		);

	vec2 rayPos1 =
		vec2(
			resolution.x * 0.2,
			resolution.y * 1.5
		);

	vec2 rayRefDir1 =
		normalize(
			vec2(1.0, -0.116)
		);

	vec2 rayPos2 =
		vec2(
			resolution.x * 0.3,
			resolution.y * 1.6
		);

	vec2 rayRefDir2 =
		normalize(
			vec2(1.0, 0.241)
		);

	vec4 rays1 =
		vec4(1.0) *
		rayStrength(
			rayPos1,
			rayRefDir1,
			coord,
			36.2214,
			21.11349,
			1.5
		);

	vec4 rays2 =
		vec4(1.0) *
		rayStrength(
			rayPos2,
			rayRefDir2,
			coord,
			22.39910,
			18.0234,
			1.1
		);

	vec4 rays =
		rays1 * 0.5 +
		rays2 * 0.4;

	rays.rgb *= rayColor;

	float contrast = 2.0;

	rays.rgb =
		(rays.rgb - 0.5) *
		contrast + 0.5;

	rays.rgb =
		clamp(
			rays.rgb,
			0.0,
			1.0
		);

	float spriteAlpha =
		flixel_texture2D(
			bitmap,
			uv
		).a;

	rays.rgb *= spriteAlpha;

	gl_FragColor =
		vec4(
			rays.rgb,
			spriteAlpha
		);
}
";


	public function new()
	{
		super("dadbattle-amtake");

		isBoss = true;
		
        loadingCountdownSkipped = false;
		hasPlayedCutscene = false;
		hasPlayedMidVideo = false;
		midVideoPlaying = false;
		lethalMissPending = false;

		rainShader = null;
		rainShaderFilter = null;
		rainShaderEnabled = false;

		chromShader = null;
		chromShaderFilter = null;
		chromChangeTween = null;

		godRaysShader = null;
		godRaysSpr = null;
	}


	function isHealthDrainEnabled():Bool
	{
		if (Save.instance == null)
			return false;

		var optionValue =
			Save.instance.modOptions.get(
				HEALTH_DRAIN_OPTION
			);

		if (optionValue == null)
			return false;

		return optionValue == true;
	}


	function updateCameraFilters():Void
	{
		var filters:Array<ShaderFilter> = [];

		if (
			rainShaderEnabled &&
			rainShaderFilter != null
		)
		{
			filters.push(rainShaderFilter);
		}

		if (chromShaderFilter != null)
		{
			filters.push(chromShaderFilter);
		}

		FlxG.camera.filters = filters;
	}


	function createRainShader():Void
	{
		if (rainShader != null)
			return;

		rainShader =
			new RuntimeRainShader();

		rainShader.scale =
			FlxG.height / 500;

		rainShader.intensity =
			rainIntensity;

		rainShaderFilter =
			new ShaderFilter(rainShader);

		enableRainShader();
	}


	function enableRainShader():Void
	{
		if (rainShader == null)
			return;

		if (rainShaderFilter == null)
			return;

		rainShader.updateViewInfo(
			FlxG.width,
			FlxG.height,
			FlxG.camera
		);

		rainShaderEnabled = true;

		updateCameraFilters();
	}


	function disableRainShader():Void
	{
		rainShaderEnabled = false;

		updateCameraFilters();
	}


	function updateRainShader(
		elapsed:Float
	):Void
	{
		if (rainShader == null)
			return;

		if (!rainShaderEnabled)
			return;

		rainShader.updateViewInfo(
			FlxG.width,
			FlxG.height,
			FlxG.camera
		);

		rainShader.update(elapsed);
	}


	function createChromShader():Void
	{
		if (chromShader != null)
			return;

		chromShader =
			new FlxRuntimeShader(
				Assets.getText(
					Paths.frag(
						"chromaticAbberation"
					)
				)
			);

		chromShader.setFloat(
			"strength",
			0.1
		);

		chromShaderFilter =
			new ShaderFilter(chromShader);

		updateCameraFilters();
	}


	function chromaEffect(
		strength:Float,
		time:Float,
		easeStr:String
	):Void
	{
		if (!Preferences.shaders)
			return;

		if (chromShader == null)
			return;

		if (chromChangeTween != null)
			chromChangeTween.cancel();

		var easeFunction:Null<Float->Float> =
			Reflect.field(
				FlxEase,
				easeStr
			);

		if (time <= 0)
		{
			chromShader.setFloat(
				"strength",
				strength
			);

			return;
		}

		chromChangeTween =
			FlxTween.num(
				chromShader.getFloat(
					"strength"
				),
				strength,
				time,
				{
					ease:
						easeFunction ??
						FlxEase.smootherStepOut
				},
				(value:Float) ->
				{
					if (chromShader != null)
					{
						chromShader.setFloat(
							"strength",
							value
						);
					}
				}
			);
	}


	function createEffects():Void
	{
		if (!Preferences.shaders)
			return;

		var state =
			PlayState.instance;

		if (state == null)
			return;

		if (godRaysSpr != null)
			return;

		godRaysShader =
			new FlxRuntimeShader(
				godlight
			);

		godRaysShader.setFloatArray(
			"rayColor",
			[1.3, 1.2, 0.9]
		);

		godRaysSpr =
			new FlxSprite();

		godRaysSpr.makeGraphic(
			Std.int(FlxG.width * 1.5),
			FlxG.height
		);

		godRaysSpr.scrollFactor.set(
			1,
			0
		);

		godRaysSpr.screenCenter();

		godRaysSpr.alpha = 0;

		godRaysSpr.cameras =
			[state.camGame];

		godRaysShader.setFloatArray(
			"resolution",
			[
				godRaysSpr.width,
				godRaysSpr.height
			]
		);

		godRaysSpr.shader =
			godRaysShader;

		state.add(godRaysSpr);
	}


	function onCreate(
		event:ScriptEvent
	):Void
	{
		super.onCreate(event);

		// Cada nueva entrada debe reservar el primer COUNTDOWN_START al loading.
		loadingCountdownSkipped = false;

		hasPlayedCutscene = false;
		hasPlayedMidVideo = false;
		midVideoPlaying = false;
		lethalMissPending = false;
		inIdle = true;

		createRainShader();
		createChromShader();

		var state =
			PlayState.instance;

		if (state != null)
		{

			if (state.playerStrumline != null)
			{
				playerBaseX = state.playerStrumline.x;
				playerBaseY = state.playerStrumline.y;
			}
			if (state.currentStage != null)
			{
				var boyfriend =
					state.currentStage.getBoyfriend();

				if (boyfriend != null)
					boyfriend.idleSuffix =
						"-angry";
			}

			createEffects();

			// Preparar holygrad sin cambiar el resto del stage.
			try
			{
				var holygrad = state.currentStage.getNamedProp("holygrad");
				if (holygrad != null)
				{
					holygrad.visible = true;
					holygrad.alpha = 0;
				}
			}
			catch (e:Dynamic) {}

			midVideo =
				new FunkinVideoSprite();

			midVideo.load(
				Paths.videos(
					"dadbattle-amtake-mid"
				)
			);

			midVideo.scrollFactor.set(
				0,
				0
			);

			midVideo.visible = false;
			midVideo.alpha = 1;
			midVideo.zIndex = 1000;
			midVideo.bitmap.volumeAdjust = 0;

			midVideo.bitmap.onFormatSetup.add(() ->
			{
				if (midVideo == null)
					return;

				var videoWidth:Float =
					midVideo.frameWidth;

				var videoHeight:Float =
					midVideo.frameHeight;

				if (
					videoWidth <= 0 ||
					videoHeight <= 0
				)
					return;

				var scaleX:Float =
					FlxG.width /
					videoWidth;

				var scaleY:Float =
					FlxG.height /
					videoHeight;

				var coverScale:Float =
					Math.max(
						scaleX,
						scaleY
					);

				midVideo.scale.set(
					coverScale,
					coverScale
				);

				midVideo.updateHitbox();
				midVideo.screenCenter();
			});

			state.add(midVideo);

			if (state.camHUD != null)
			{
				midVideo.cameras =
					[state.camHUD];
			}

			state.refresh();
		}
	}


		override function onUpdate(event:UpdateScriptEvent):Void
	{
		super.onUpdate(event);

		updateRainShader(event.elapsed);

		if (godRaysShader != null)
		{
			godRaysShader.setFloat("iTime", FlxG.game.ticks / 1000);
		}


		if (lethalMissPending)
		{
			var state = PlayState.instance;
			if (state != null) state.health = 0;
			lethalMissPending = false;
		}
	}



		override function onNoteHit(event:HitNoteScriptEvent):Void
	{
		super.onNoteHit(event);

		if (event == null || event.note == null) return;

		var state = PlayState.instance;
		if (state == null) return;

		if (!event.note.noteData.getMustHitNote() && !midVideoPlaying && !Preferences.lowQuality)
		{
			inIdle = false;

		}

		if (!isHealthDrainEnabled() || midVideoPlaying) return;
		if (event.note.noteData.getMustHitNote()) return;

		var currentHealth:Float = state.health;
		if (currentHealth <= healthDrainMinimum)
		{
			event.healthChange = 0;
			return;
		}

		var damage:Float = healthDrainPerNote;
		if (currentHealth - damage < healthDrainMinimum)
			damage = currentHealth - healthDrainMinimum;

		if (damage > 0) event.healthChange = -damage;
	}



	override function onNoteMiss(
		event:NoteScriptEvent
	):Void
	{
		var state =
			PlayState.instance;

		var shouldKill:Bool = false;

		if (
			state != null &&
			isHealthDrainEnabled() &&
			event.note != null
		)
		{
			if (
				event.note.noteData.getMustHitNote() &&
				state.health <=
				healthDrainMinimum
			)
			{
				shouldKill = true;
			}
		}

		super.onNoteMiss(event);

		if (shouldKill)
			lethalMissPending = true;
	}


override function onCountdownStart(
	event:CountdownScriptEvent
):Void
{
	super.onCountdownStart(event);

	/*
	 * PRIMER COUNTDOWN
	 *
	 * Lo dejamos exclusivamente para
	 * AnimaniaLoadingScreen.
	 *
	 * El módulo de loading será el encargado
	 * de cancelar este countdown.
	 */
	if (!loadingCountdownSkipped)
	{
		loadingCountdownSkipped = true;
		return;
	}


	/*
	 * SEGUNDO COUNTDOWN
	 *
	 * AnimaniaLoadingScreen terminó y llamó
	 * nuevamente a startCountdown().
	 *
	 * Ahora sí reproducimos el cutscene.
	 */
	if (!hasPlayedCutscene)
	{
		hasPlayedCutscene = true;

		disableRainShader();

		event.cancel();

		startVideo();

		return;
	}


	/*
	 * DESPUÉS DEL CUTSCENE
	 *
	 * El siguiente intento de countdown
	 * ya puede iniciar normalmente.
	 */
	enableRainShader();
}


	function startVideo():Void
	{
		disableRainShader();

		VideoCutscene.play(
			Paths.videos(
				"dadbattle-amtake"
			)
		);
	}


		override function onBeatHit(event:SongTimeScriptEvent):Void
	{
		super.onBeatHit(event);

		var state = PlayState.instance;
		if (state == null) return;

		if (event.beat > 283 && event.beat % 2 == 0 && !Preferences.lowQuality)
		{
			if (state.camHUD != null)
			{
				state.camHUD.zoom = 1.05;
				FlxTween.tween(state.camHUD, {zoom: 1.0}, 0.18, {ease: FlxEase.sineOut});
			}
		}

		if (event.beat == 31)
		{
			if (state.healthBarGroup != null)
			{
				state.healthBarGroup.alpha = 0;
				FlxTween.tween(state.healthBarGroup, {alpha: 1}, 0.75, {ease: FlxEase.backOut});
			}

			if (!Preferences.lowQuality)
			{
				if (state.opponentStrumline != null)
				{
					state.opponentStrumline.visible = true;
					state.opponentStrumline.alpha = 1;
				}

				if (state.playerStrumline != null)
				{
					state.playerStrumline.alpha = 0;
					state.playerStrumline.x = playerBaseX + 50;
					state.playerStrumline.y = playerBaseY + 50;
					FlxTween.tween(state.playerStrumline, {alpha: 1, x: playerBaseX, y: playerBaseY}, 1.0, {startDelay: 0.25, ease: FlxEase.circOut});
				}
			}
		}

		if (event.beat == 223)
		{
			if (!hasPlayedMidVideo)
			{
				hasPlayedMidVideo = true;

				if (!Preferences.lowQuality && state.playerStrumline != null)
					FlxTween.tween(state.playerStrumline, {alpha: 0}, 1.0, {ease: FlxEase.circOut});

				if (state.timeBar != null)
					FlxTween.tween(state.timeBar, {alpha: 0}, 1, {ease: FlxEase.sineIn});

				playMidVideo();
			}
		}

		if (event.beat > 222 && event.beat < 250)
		{
			if (state.vocals != null)
				state.vocals.playerVolume = 1;
		}

		if (event.beat == 284)
		{
			if (!Preferences.lowQuality && state.playerStrumline != null)
			{
				state.playerStrumline.alpha = 0;
				FlxTween.tween(state.playerStrumline, {alpha: 1}, 1.75, {ease: FlxEase.sineInOut});
			}
		}

		if (event.beat == 384)
		{
			var whereWeGo = Preferences.downscroll ? 30 : -30;

			if (!Preferences.lowQuality && state.playerStrumline != null)
				FlxTween.tween(state.playerStrumline, {alpha: 0, y: playerBaseY + whereWeGo}, 0.6, {ease: FlxEase.sineIn});

			if (state.healthBarGroup != null)
				FlxTween.tween(state.healthBarGroup, {alpha: 0}, 0.6, {ease: FlxEase.sineIn});

			if (state.timeBar != null)
				FlxTween.tween(state.timeBar, {alpha: 0}, 1, {ease: FlxEase.sineIn});
		}

		if (event.beat == 392)
		{
			// FINAL: cubrir absolutamente todo, incluido el HUD.
			// Se crean dos capas: una para el mundo y otra para camHUD.
			endScreen = new FlxSprite();
			endScreen.makeGraphic(1, 1, FlxColor.BLACK);

			var endCam = state.camOther;
			if (endCam != null)
			{
				endScreen.cameras = [endCam];
				var zoom = endCam.zoom;
				if (zoom <= 0) zoom = 1;
				endScreen.scale.set(
					(FlxG.width / zoom) * 8,
					(FlxG.height / zoom) * 8
				);
			}
			else
			{
				endScreen.cameras = [FlxG.camera];
				endScreen.scale.set(FlxG.width * 8, FlxG.height * 8);
			}

			endScreen.scrollFactor.set(0, 0);
			endScreen.screenCenter();
			endScreen.zIndex = 999999;
			endScreen.alpha = 0;
			state.add(endScreen);

			// Segunda capa exclusiva para el HUD.
			// Esto evita que camHUD quede por encima del negro.
			var hudScreen = new FlxSprite();
			hudScreen.makeGraphic(1, 1, FlxColor.BLACK);
			hudScreen.cameras = [state.camHUD];
			hudScreen.scrollFactor.set(0, 0);
			hudScreen.scale.set(FlxG.width * 8, FlxG.height * 8);
			hudScreen.screenCenter();
			hudScreen.zIndex = 999999;
			hudScreen.alpha = 0;
			state.add(hudScreen);

			// Ambos overlays aparecen juntos.
			endScreenTween = FlxTween.tween(
				endScreen,
				{alpha: 1},
				2.5,
				{ease: FlxEase.sineOut}
			);

			FlxTween.tween(
				hudScreen,
				{alpha: 1},
				2.5,
				{ease: FlxEase.sineOut}
			);
		}
	}



	function playMidVideo():Void
	{
		if (midVideo == null)
			return;

		if (midVideoPlaying)
			return;

		var state =
			PlayState.instance;

		if (state == null)
			return;

		midVideoPlaying = true;

		disableRainShader();

		state.disableKeys = true;

		if (state.healthBarGroup != null)
		{
			FlxTween.cancelTweensOf(
				state.healthBarGroup
			);

			state.healthBarGroup.alpha = 0;
			state.healthBarGroup.visible = false;
		}

		if (state.timeBar != null)
		{
			FlxTween.cancelTweensOf(
				state.timeBar
			);

			state.timeBar.alpha = 0;
			state.timeBar.visible = false;
		}

		if (state.playerStrumline != null)
		{
			state.playerStrumline.alpha = 0;
			state.playerStrumline.visible = false;
		}

		if (state.opponentStrumline != null)
		{
			state.opponentStrumline.alpha = 0;
			state.opponentStrumline.visible = false;
		}

		midVideo.visible = true;
		midVideo.alpha = 1;
		midVideo.bitmap.volumeAdjust = 0;
		midVideo.bitmap.time = 0;

		midVideo.bitmap.onEndReached.add(
			onMidVideoFinished
		);

		midVideo.play();
	}


		function onMidVideoFinished():Void
	{
		if (midVideo == null) return;

		var state = PlayState.instance;
		if (state == null) return;
		if (!midVideoPlaying) return;

		midVideoPlaying = false;
		midVideo.stop();
		midVideo.visible = false;
		enableRainShader();

		if (state.currentStage != null)
		{
			var boyfriend = state.currentStage.getBoyfriend();
			if (boyfriend != null) boyfriend.idleSuffix = "";

			var dad = state.currentStage.getDad();
			if (dad != null) dad.idleSuffix = "-alt";
		}

		state.disableKeys = false;

		if (state.healthBarGroup != null)
		{
			state.healthBarGroup.visible = true;
			state.healthBarGroup.alpha = 0;
			FlxTween.tween(state.healthBarGroup, {alpha: 1}, 0.8, {ease: FlxEase.sineInOut});
		}

		if (state.timeBar != null)
		{
			state.timeBar.visible = true;
			state.timeBar.alpha = 0;
			FlxTween.tween(state.timeBar, {alpha: 0.8}, 0.8, {ease: FlxEase.sineInOut});
		}

		if (state.playerStrumline != null)
		{
			state.playerStrumline.visible = true;
			state.playerStrumline.alpha = 0;
			state.playerStrumline.x = playerBaseX;
			state.playerStrumline.y = playerBaseY;
			FlxTween.tween(state.playerStrumline, {alpha: 1}, 0.2, {ease: FlxEase.linear});
		}

		if (state.opponentStrumline != null)
		{
			state.opponentStrumline.visible = true;
			state.opponentStrumline.alpha = 0;
			FlxTween.tween(state.opponentStrumline, {alpha: 1}, 0.2, {ease: FlxEase.linear});
		}

		if (godRaysSpr != null)
		{
			FlxTween.tween(godRaysSpr, {alpha: 0.1}, 3, {startDelay: 2, ease: FlxEase.sineInOut});
		}

		chromaEffect(0.35, 1.5, "sineInOut");

		if (state.currentStage != null)
		{
			try
			{
				var holygrad = state.currentStage.getNamedProp("holygrad");
				if (holygrad != null)
				{
					FlxTween.cancelTweensOf(holygrad);
					holygrad.visible = true;
					holygrad.alpha = 0;
					FlxTween.tween(holygrad, {alpha: 0.8}, 3, {startDelay: 2, ease: FlxEase.sineInOut});
					FlxTween.tween(holygrad, {alpha: 0}, 6, {startDelay: 20.75, ease: FlxEase.sineInOut});
				}
			}
			catch (e:Dynamic) {}

			try
			{
				var fgRedOverlay = state.currentStage.getNamedProp("fgRedOverlay");
				if (fgRedOverlay != null)
				{
					FlxTween.cancelTweensOf(fgRedOverlay);
					FlxTween.tween(fgRedOverlay, {alpha: 0}, 8, {startDelay: 1, ease: FlxEase.sineInOut});
				}
			}
			catch (e:Dynamic) {}
		}
	}




	function onCreatePost():Void
	{
	}

	override function onPause():Void
	{
		super.onPause();

		if (
			midVideo != null &&
			midVideoPlaying
		)
		{
			midVideo.pause();
		}
	}


	override function onResume():Void
	{
		super.onResume();

		if (
			midVideo != null &&
			midVideoPlaying
		)
		{
			midVideo.resume();
		}
	}


	override function onSongRetry(
		event:ScriptEvent
	):Void
	{
		super.onSongRetry(event);

		hasPlayedCutscene = true;
		hasPlayedMidVideo = false;
		midVideoPlaying = false;
		lethalMissPending = false;
		inIdle = true;

		enableRainShader();

		if (midVideo != null)
		{
			midVideo.stop();
			midVideo.visible = false;
		}

		var state =
			PlayState.instance;

		if (state == null)
			return;

		if (state.currentStage != null)
		{
			var boyfriend =
				state.currentStage.getBoyfriend();

			if (boyfriend != null)
				boyfriend.idleSuffix =
					"-angry";

			var dad =
				state.currentStage.getDad();

			if (dad != null)
				dad.idleSuffix = "";
		}

		state.disableKeys = false;

		if (state.healthBarGroup != null)
		{
			state.healthBarGroup.visible = true;
			state.healthBarGroup.alpha = 1;
		}

		if (state.timeBar != null)
		{
			state.timeBar.visible = true;
			state.timeBar.alpha = 0.8;
		}

		if (state.playerStrumline != null)
		{
			state.playerStrumline.visible = true;
			state.playerStrumline.alpha = 1;
		}

		if (state.opponentStrumline != null)
		{
			state.opponentStrumline.visible = true;
			state.opponentStrumline.alpha = 1;
		}

		if (godRaysSpr != null)
			godRaysSpr.alpha = 0;

		chromaEffect(
			0.1,
			0,
			"linear"
		);
	}


	override function onGameOver(
		event:ScriptEvent
	):Void
	{
		super.onGameOver(event);

		lethalMissPending = false;

		disableRainShader();

		if (chromChangeTween != null)
		{
			chromChangeTween.cancel();
			chromChangeTween = null;
		}

		if (midVideo != null)
		{
			midVideo.stop();
			midVideo.visible = false;
		}

		midVideoPlaying = false;
	}


	override function kill():Void
	{
		disableRainShader();

		if (endScreenTween != null)
		{
			endScreenTween.cancel();
			endScreenTween = null;
		}

		if (endScreen != null)
		{
			endScreen.kill();
			endScreen.destroy();
			endScreen = null;
		}

		if (chromChangeTween != null)
		{
			chromChangeTween.cancel();
			chromChangeTween = null;
		}

		if (midVideo != null)
		{
			midVideo.stop();
			midVideo.visible = false;
			midVideo.destroy();
			midVideo = null;
		}

		if (godRaysSpr != null)
		{
			godRaysSpr.destroy();
			godRaysSpr = null;
		}

		godRaysShader = null;

		midVideoPlaying = false;
		lethalMissPending = false;


		super.kill();
	}

	/*
	 * Al salir del PlayState, dejamos preparado el flag para que
	 * una futura entrada vuelva a reservar el primer countdown
	 * exclusivamente a AnimaniaLoadingScreen.
	 */
	function onStateChangeBegin(event):Void
	{
		loadingCountdownSkipped = false;
	}

}