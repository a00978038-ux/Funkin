import funkin.play.song.Song;
import funkin.play.PlayState;
import funkin.save.Save;

class CocoaAmtakeSong extends Song
{
/*
* =========================================================
* CONSTRUCTOR
* =========================================================
*/

public function new()
{
	super('cocoa-amtake');
}


/*
 * =========================================================
 * HEALTH DRAIN
 * =========================================================
 *
 * Usa la misma opción que DadBeast y Eggnog AMtake:
 *
 *     DadBeastHealthDrain
 *
 * ON  = El oponente drena vida.
 * OFF = No drena vida.
 *
 * La vida nunca baja de 0.10 mediante el drenaje.
 */

static var HEALTH_DRAIN_OPTION:String =
	"DadBeastHealthDrain";


var healthDrainPerNote:Float =
	0.035;


var healthDrainMinimum:Float =
	0.10;


var lethalMissPending:Bool =
	false;


/*
 * =========================================================
 * COMPROBAR HEALTH DRAIN
 * =========================================================
 */

function isHealthDrainEnabled():Bool
{
	if (Save.instance == null)
		return false;


	var optionValue =
		Save.instance.modOptions.get(
			HEALTH_DRAIN_OPTION
		);


	if (optionValue == null)
		return false;


	return optionValue == true;
}


/*
 * =========================================================
 * UPDATE
 * =========================================================
 *
 * Procesa una muerte pendiente.
 *
 * Esto permite que el jugador muera al fallar
 * una nota estando exactamente en el mínimo de vida.
 */

override function onUpdate(
	event:UpdateScriptEvent
):Void
{
	super.onUpdate(event);


	if (!lethalMissPending)
		return;


	var state =
		PlayState.instance;


	if (state == null)
		return;


	state.health = 0;


	lethalMissPending = false;
}


/*
 * =========================================================
 * NOTA DEL OPONENTE
 * =========================================================
 *
 * Cada nota normal acertada por el oponente
 * provoca daño a la vida del jugador.
 */

override function onNoteHit(
	event:HitNoteScriptEvent
):Void
{
	super.onNoteHit(event);


	/*
	 * Health Drain OFF.
	 */

	if (!isHealthDrainEnabled())
		return;


	/*
	 * Evitar errores si la nota no existe.
	 */

	if (event.note == null)
		return;


	/*
	 * Si la nota pertenece al jugador,
	 * no hacer nada.
	 */

	if (
		event.note.noteData.getMustHitNote()
	)
	{
		return;
	}


	var state =
		PlayState.instance;


	if (state == null)
		return;


	/*
	 * =====================================================
	 * VIDA ACTUAL
	 * =====================================================
	 */

	var currentHealth:Float =
		state.health;


	/*
	 * Si ya estamos en el mínimo,
	 * no seguir drenando.
	 */

	if (
		currentHealth <=
		healthDrainMinimum
	)
	{
		event.healthChange = 0;
		return;
	}


	/*
	 * =====================================================
	 * DAÑO
	 * =====================================================
	 */

	var damage:Float =
		healthDrainPerNote;


	/*
	 * Evitar bajar de 0.10.
	 */

	if (
		currentHealth - damage <
		healthDrainMinimum
	)
	{
		damage =
			currentHealth -
			healthDrainMinimum;
	}


	/*
	 * Aplicar el daño mediante el sistema
	 * healthChange de NoteHit.
	 */

	event.healthChange =
		-damage;
}


/*
 * =========================================================
 * NOTA FALLADA
 * =========================================================
 *
 * Si el jugador falla una nota estando en 0.10,
 * se permite que ocurra el Game Over.
 */

override function onNoteMiss(
	event:NoteScriptEvent
):Void
{
	var state =
		PlayState.instance;


	var shouldKill:Bool =
		false;


	if (
		state != null &&
		isHealthDrainEnabled() &&
		event.note != null
	)
	{
		/*
		 * Solamente las notas del jugador.
		 */

		if (
			event.note.noteData.getMustHitNote() &&
			state.health <= healthDrainMinimum
		)
		{
			shouldKill = true;
		}
	}


	/*
	 * Mantener el comportamiento normal
	 * de onNoteMiss.
	 */

	super.onNoteMiss(event);


	/*
	 * La muerte se procesa en onUpdate().
	 */

	if (shouldKill)
		lethalMissPending = true;
}

}