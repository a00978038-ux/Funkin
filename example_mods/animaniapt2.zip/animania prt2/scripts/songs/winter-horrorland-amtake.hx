import funkin.play.song.Song;
import flixel.FlxG;
import funkin.Paths;
import funkin.graphics.FunkinSprite;
import funkin.graphics.shaders.AdjustColorShader;
import funkin.play.PlayState;
import funkin.save.Save;
import flixel.tweens.FlxTween;
import flixel.tweens.FlxEase;
import flixel.util.FlxTimer;
import flixel.util.FlxColor;
import flixel.text.FlxText;
import funkin.audio.FunkinSound;
import funkin.Preferences;
import flixel.addons.display.FlxRuntimeShader;
import openfl.filters.ShaderFilter;
import openfl.utils.Assets;

class WinterHorrorlandAmtakeSong extends Song
{
	public function new()
	{
		super("winter-horrorland-amtake");

		isBoss = true;
	}


	/*
	 * =========================================================
	 * HEALTH DRAIN
	 * =========================================================
	 *
	 * Usa la misma opción:
	 *
	 *     DadBeastHealthDrain
	 *
	 * ON  = El oponente drena vida.
	 * OFF = No drena vida.
	 *
	 * La vida nunca baja de 0.10 mediante el drenaje.
	 */

	static var HEALTH_DRAIN_OPTION:String =
		"DadBeastHealthDrain";


	var healthDrainPerNote:Float =
		0.035;


	var healthDrainMinimum:Float =
		0.10;


	var lethalMissPending:Bool =
		false;

	// =========================================================
	// DELAY DEL FINAL ORIGINAL
	// =========================================================
	var allowDelayedEnd:Bool = false;
	var songEndDelayTimer:FlxTimer = null;

	// =========================================================
	// HINT MOBILE - HARD
	// =========================================================
	var mobileHintCircle:FunkinSprite = null;
	var mobileHintText:FlxText = null;


	/*
	 * =========================================================
	 * CHROMA MOBILE
	 * =========================================================
	 */

	var chromShader:FlxRuntimeShader = null;
	var chromShaderFilter:ShaderFilter = null;
	var chromChangeTween:FlxTween = null;

	function updateCameraFilters():Void
	{
		var filters:Array<ShaderFilter> = [];

		if (chromShaderFilter != null)
			filters.push(chromShaderFilter);

		FlxG.camera.filters = filters;
	}

	function createChromShader():Void
	{
		if (chromShader != null)
			return;

		chromShader = new FlxRuntimeShader(
			Assets.getText(Paths.frag("chromaticAbberation"))
		);

		chromShader.setFloat("strength", 0.1);
		chromShaderFilter = new ShaderFilter(chromShader);

		// Igual que Dadbattle: aplicar mediante la función de filtros.
		updateCameraFilters();
	}

	function chromaEffect(strength:Float, time:Float, easeFunction:Float->Float):Void
	{
		if (chromShader == null)
			return;

		updateCameraFilters();

		if (chromChangeTween != null)
			chromChangeTween.cancel();

		if (time <= 0)
		{
			chromShader.setFloat("strength", strength);
			return;
		}

		chromChangeTween = FlxTween.num(
			chromShader.getFloat("strength"),
			strength,
			time,
			{ease: easeFunction},
			function(value:Float)
			{
				if (chromShader != null)
					chromShader.setFloat("strength", value);
			}
		);
	}

	/*
	 * =========================================================
	 * ILUMINACIÓN DEL STAGE
	 * =========================================================
	 */

	var dark = null;
	var darkLight = null;
	var blend2 = null;

	var darkInitialAlpha:Float = 1;
	var darkLightInitialAlpha:Float = 1;
	var blend2InitialAlpha:Float = 0.6;


	function getStageLights():Void
	{
		var state =
			PlayState.instance;


		if (state == null)
			return;


		if (state.currentStage == null)
			return;


		var newDark =
			state.currentStage.getNamedProp(
				"horrorlight"
			);


		var newDarkLight =
			state.currentStage.getNamedProp(
				"darkLight"
			);


		var newBlend2 =
			state.currentStage.getNamedProp(
				"blend2"
			);


		/*
		 * Si Restart reconstruyó el stage, estas referencias cambian.
		 * Guardamos el alpha REAL con el que nació cada prop antes
		 * de que esta canción lo modifique.
		 */
		dark = newDark;
		darkLight = newDarkLight;
		blend2 = newBlend2;
	}


	function forceInitialStageLights():Void
	{
		getStageLights();

		if (dark != null)
		{
			FlxTween.cancelTweensOf(dark);
			dark.alpha = 1;
		}

		if (darkLight != null)
		{
			FlxTween.cancelTweensOf(darkLight);
			darkLight.alpha = 1;
		}

		if (blend2 != null)
		{
			FlxTween.cancelTweensOf(blend2);
			blend2.alpha = 0.6;
		}
	}


	/*
	 * =========================================================
	 * COMPROBAR HEALTH DRAIN
	 * =========================================================
	 */

	function isHealthDrainEnabled():Bool
	{
		if (Save.instance == null)
			return false;


		var optionValue =
			Save.instance.modOptions.get(
				HEALTH_DRAIN_OPTION
			);


		if (optionValue == null)
			return false;


		return optionValue == true;
	}


	/*
	 * =========================================================
	 * HA - WINTER HORRORLAND
	 * =========================================================
	 */

	var haSprites:Array<FunkinSprite> = [];


	function createHahaha(x:Float, y:Float):Void
	{
		var state =
			PlayState.instance;


		if (state == null)
			return;


		if (state.currentStage == null)
			return;


		var ha =
			new FunkinSprite(x, y);


		ha.loadGraphic(
			Paths.image(
				"stages/xMassCityMallNasty/ha"
			)
		);


		ha.zIndex = 10000;

		ha.angle =
			FlxG.random.float(
				-10,
				10
			);


		ha.scrollFactor.set(1, 1);

		ha.scale.set(0.9, 0.9);


		state.currentStage.add(ha);

		state.currentStage.refresh();


		haSprites.push(ha);


		FlxTween.tween(
			ha,
			{
				"scale.x": 1.1,
				"scale.y": 1.1,
				angle:
					ha.angle +
					FlxG.random.float(
						-7,
						7
					)
			},
			0.15,
			{
				ease: FlxEase.cubeOut
			}
		);
	}


	function removeHahaha():Void
	{
		var state =
			PlayState.instance;


		if (state == null)
			return;


		if (state.currentStage == null)
			return;


		var sprites =
			haSprites.copy();


		for (ha in sprites)
		{
			if (ha == null)
				continue;


			FlxTween.cancelTweensOf(ha);


			FlxTween.tween(
				ha,
				{
					"scale.x": 0.5,
					"scale.y": 0.5,
					angle:
						ha.angle +
						FlxG.random.float(
							-10,
							10
						),
					alpha: 0
				},
				0.25,
				{
					ease: FlxEase.cubeOut,

					onComplete: function(tween)
					{
						if (
							PlayState.instance != null &&
							PlayState.instance.currentStage != null
						)
						{
							PlayState.instance.currentStage.remove(ha);
						}


						ha.kill();
						ha.destroy();

						haSprites.remove(ha);
					}
				}
			);
		}
	}


	/*
	 * =========================================================
	 * STRUMLINE DEL OPONENTE
	 * =========================================================
	 *
	 * Solo se oculta. No cambia su posición y no modifica
	 * la strumline del jugador.
	 */

	function hideOpponentStrumline():Void
	{
		var state =
			PlayState.instance;


		if (state == null)
			return;


		if (state.opponentStrumline != null)
		{
			state.opponentStrumline.visible = false;
		}
	}


	/*
	 * =========================================================
	 * HINT MOBILE
	 * =========================================================
	 *
	 *            [FIGHTING_UI]
	 * TAP THE CIRCLE TO DODGE OR ATTACK
	 *
	 * Solo aparece en Hard.
	 */

	function isHardDifficultyForHint():Bool
	{
		var state = PlayState.instance;

		if (state == null)
			return false;

		return Std.string(state.currentDifficulty) == "hard";
	}


	function createMobileBattleHint():Void
	{
		var state = PlayState.instance;

		if (state == null || state.isChartingMode)
			return;

		if (!isHardDifficultyForHint())
			return;

		if (state.camCutscene == null)
			return;

		if (mobileHintCircle == null)
		{
			mobileHintCircle = new FunkinSprite();

			mobileHintCircle.loadGraphic(
				Paths.image("mechanincs/FIGHTING_UI")
			);

			mobileHintCircle.applyStageMatrix = false;
			mobileHintCircle.scrollFactor.set(0, 0);
			mobileHintCircle.cameras = [state.camCutscene];

			mobileHintCircle.scale.set(0.35, 0.35);
			mobileHintCircle.updateHitbox();

			mobileHintCircle.x =
				(FlxG.width - mobileHintCircle.width) / 2;

			mobileHintCircle.y =
				FlxG.height * 0.42;

			mobileHintCircle.alpha = 0;

			state.add(mobileHintCircle);
		}

		if (mobileHintText == null)
		{
			mobileHintText = new FlxText(
				0,
				0,
				FlxG.width,
"TAP THE CIRCLE TO
DODGE OR ATTACK",
				50
			);

			mobileHintText.scrollFactor.set(0, 0);
			mobileHintText.cameras = [state.camCutscene];

			mobileHintText.font =
				Paths.font("alphabet-white.ttf");

			mobileHintText.alignment = "center";
			mobileHintText.color = 0xFFFFE066;

			mobileHintText.y =
				mobileHintCircle.y +
				mobileHintCircle.height +
				90;

			mobileHintText.alpha = 0;

			state.add(mobileHintText);
		}
	}


	function showMobileBattleHint():Void
	{
		if (!isHardDifficultyForHint())
			return;

		createMobileBattleHint();

		if (mobileHintCircle != null)
		{
			FlxTween.cancelTweensOf(mobileHintCircle);

			mobileHintCircle.alpha = 0;
			mobileHintCircle.scale.set(0.31, 0.31);

			FlxTween.tween(
				mobileHintCircle,
				{
					alpha: 1,
					"scale.x": 1.0,
					"scale.y": 1.0
				},
				1.25,
				{ease: FlxEase.cubeOut}
			);
		}

		if (mobileHintText != null)
		{
			FlxTween.cancelTweensOf(mobileHintText);
			mobileHintText.alpha = 0;

			FlxTween.tween(
				mobileHintText,
				{alpha: 1},
				1.25,
				{ease: FlxEase.cubeOut}
			);
		}
	}


	function hideMobileBattleHint():Void
	{
		if (mobileHintCircle != null)
		{
			FlxTween.cancelTweensOf(mobileHintCircle);

			FlxTween.tween(
				mobileHintCircle,
				{
					alpha: 0,
					"scale.x": 0.31,
					"scale.y": 0.31
				},
				2.25,
				{ease: FlxEase.sineIn}
			);
		}

		if (mobileHintText != null)
		{
			FlxTween.cancelTweensOf(mobileHintText);

			FlxTween.tween(
				mobileHintText,
				{alpha: 0},
				2.25,
				{ease: FlxEase.sineIn}
			);
		}
	}


	function cleanupMobileBattleHint():Void
	{
		var state = PlayState.instance;

		if (mobileHintCircle != null)
		{
			FlxTween.cancelTweensOf(mobileHintCircle);

			if (state != null)
				state.remove(mobileHintCircle);

			mobileHintCircle.kill();
			mobileHintCircle.destroy();
			mobileHintCircle = null;
		}

		if (mobileHintText != null)
		{
			FlxTween.cancelTweensOf(mobileHintText);

			if (state != null)
				state.remove(mobileHintText);

			mobileHintText.kill();
			mobileHintText.destroy();
			mobileHintText = null;
		}
	}


	/*
	 * =========================================================
	 * ENTRADA DEL HUD
	 * =========================================================
	 *
	 * Primera prueba Mobile:
	 * - Oculta camHUD al crear la canción.
	 * - En el beat 22 aparece con el mismo tween del ui.hx de PC.
	 *
	 * Todavía NO mueve strumlines ni healthBar.
	 */

	function hideHudForIntro():Void
	{
		var state =
			PlayState.instance;


		if (state == null)
			return;


		if (state.isChartingMode)
			return;


		if (state.camHUD != null)
		{
			FlxTween.cancelTweensOf(state.camHUD);

			state.camHUD.alpha = 0;
		}
	}


	function showHudAtBeat22():Void
	{
		var state =
			PlayState.instance;


		if (state == null)
			return;


		if (state.isChartingMode)
			return;


		if (state.camHUD != null)
		{
			FlxTween.cancelTweensOf(state.camHUD);

			FlxTween.tween(
				state.camHUD,
				{alpha: 1},
				1.25,
				{
					ease: FlxEase.backOut
				}
			);
		}
	}


	/*
	 * =========================================================
	 * RESET AL REINICIAR
	 * =========================================================
	 *
	 * Cancela los tweens de esta canción y devuelve los elementos
	 * que ya modificamos a su estado inicial antes de comenzar
	 * nuevamente.
	 */

	function resetWinterHorrorlandState():Void
	{
		var state =
			PlayState.instance;


		lethalMissPending = false;


		if (state == null)
			return;


		/*
		 * IMPORTANTE:
		 * En Restart el stage puede reconstruir sus props.
		 * Por eso no confiamos en las referencias viejas.
		 */
		forceInitialStageLights();


		/*
		 * Game Over / Retry puede reconstruir al Boyfriend.
		 * Forzamos visible al BF NORMAL del stage nuevo.
		 * La cutscene lo volverá a ocultar solamente mientras
		 * cutsceneBf esté activo.
		 */
		if (state.currentStage != null)
		{
			var restartBf = state.currentStage.getBoyfriend();

			if (restartBf != null)
				restartBf.visible = true;
		}


		// HUD: estado limpio antes de volver a aplicar la intro.
		if (state.camHUD != null)
		{
			FlxTween.cancelTweensOf(state.camHUD);

			state.camHUD.alpha = 1;
			state.camHUD.x = 0;
			state.camHUD.y = 0;
			state.camHUD.angle = 0;
		}


		// ILUMINACIÓN: estado inicial de esta canción.
		if (dark != null)
		{
			FlxTween.cancelTweensOf(dark);

			dark.alpha = darkInitialAlpha;
		}


		if (darkLight != null)
		{
			FlxTween.cancelTweensOf(darkLight);

			darkLight.alpha = darkLightInitialAlpha;
		}


		if (blend2 != null)
		{
			FlxTween.cancelTweensOf(blend2);

			blend2.alpha = blend2InitialAlpha;
		}


		// Eliminar cualquier HA que haya quedado vivo.
		if (
			state.currentStage != null &&
			haSprites != null
		)
		{
			var sprites =
				haSprites.copy();


			for (ha in sprites)
			{
				if (ha == null)
					continue;


				FlxTween.cancelTweensOf(ha);

				state.currentStage.remove(ha);

				ha.kill();
				ha.destroy();
			}
		}


		haSprites = [];
	}


	function prepareWinterHorrorlandStart():Void
	{
		resetWinterHorrorlandState();

		/*
		 * Después de limpiar todo, aplicamos únicamente
		 * el estado que debe tener la canción al comenzar.
		 */
		hideHudForIntro();

		hideOpponentStrumline();
	}


	/*
	 * =========================================================
	 * CUTSCENE MOBILE
	 * =========================================================
	 *
	 * Se reproduce tanto en Story Mode como en Freeplay.
	 * No usa CutsceneHandler, FlxFixedText ni overlays nuevos.
	 */

	var loadingCountdownSkipped:Bool = false;
	var cutscenePlayed:Bool = false;
	var cutsceneRunning:Bool = false;
	var cutsceneTimer:FlxTimer = null;
	var cameraTimer1:FlxTimer = null;
	var cameraTimer2:FlxTimer = null;
	var cutsceneSound:FunkinSound = null;
	var cutsceneBf:FunkinSprite = null;

	var poopBarUp:FunkinSprite = null;
	var poopBarDown:FunkinSprite = null;

	var barReturnTimer:FlxTimer = null;
	var cutsceneBarUpTween:FlxTween = null;
	var cutsceneBarDownTween:FlxTween = null;

	// =========================================================
	// CONFIGURACIÓN DE BARRAS EN PANTALLA
	// =========================================================
	// Estas posiciones pertenecen a camCutscene, así que NO siguen
	// el zoom ni el movimiento de camGame.
	var BAR_UP_SCREEN_Y:Float = -600;
	var BAR_DOWN_SCREEN_Y:Float = 600;

	// Ancho extra para cubrir pantallas móviles/ultrawide.
	var BAR_SCREEN_WIDTH_MULT:Float = 4.0;
	var BAR_ALLOW_AUTOMATIC_MOVES:Bool = true;
	var barsPostUpdateHooked:Bool = false;


	function moveBarsRelative(
		distance:Float,
		outward:Bool,
		duration:Float,
		easeFunction:Float->Float
	):Void
	{
		// Cuando está en false, las barras permanecen totalmente
		// fijas a sus coordenadas de pantalla.
		if (!BAR_ALLOW_AUTOMATIC_MOVES)
			return;
		if (poopBarUp == null || poopBarDown == null)
			return;

		if (cutsceneBarUpTween != null)
		{
			cutsceneBarUpTween.cancel();
			cutsceneBarUpTween = null;
		}

		if (cutsceneBarDownTween != null)
		{
			cutsceneBarDownTween.cancel();
			cutsceneBarDownTween = null;
		}

		var upStart:Float = poopBarUp.y;
		var downStart:Float = poopBarDown.y;

		var upTarget:Float;
		var downTarget:Float;

		if (outward)
		{
			// ALEJAR:
			// la barra superior SUBE y la inferior BAJA.
			upTarget = upStart - distance;
			downTarget = downStart + distance;
		}
		else
		{
			// ACERCAR:
			// la barra superior BAJA y la inferior SUBE.
			upTarget = upStart + distance;
			downTarget = downStart - distance;
		}

		cutsceneBarUpTween = FlxTween.num(
			upStart,
			upTarget,
			duration,
			{ease: easeFunction},
			function(value:Float)
			{
				if (poopBarUp != null)
					poopBarUp.y = value;
			}
		);

		cutsceneBarDownTween = FlxTween.num(
			downStart,
			downTarget,
			duration,
			{ease: easeFunction},
			function(value:Float)
			{
				if (poopBarDown != null)
					poopBarDown.y = value;
			}
		);
	}



	function cleanupCinematicBars():Void
	{
		unhookBarsPostUpdate();

		var state = PlayState.instance;

		if (barReturnTimer != null)
		{
			barReturnTimer.cancel();
			barReturnTimer = null;
		}

		if (cutsceneBarUpTween != null)
		{
			cutsceneBarUpTween.cancel();
			cutsceneBarUpTween = null;
		}

		if (cutsceneBarDownTween != null)
		{
			cutsceneBarDownTween.cancel();
			cutsceneBarDownTween = null;
		}

		if (poopBarUp != null)
		{
			if (state != null)
				state.remove(poopBarUp);

			poopBarUp.kill();
			poopBarUp.destroy();
			poopBarUp = null;
		}

		if (poopBarDown != null)
		{
			if (state != null)
				state.remove(poopBarDown);

			poopBarDown.kill();
			poopBarDown.destroy();
			poopBarDown = null;
		}
	}


	function createCinematicBars():Void
	{
		var state = PlayState.instance;

		if (state == null || state.isChartingMode)
			return;

		cleanupCinematicBars();

		/*
		 * BARRAS MOBILE
		 *
		 * No usamos:
		 *
		 * Las barras se dibujan en camCutscene para que no les afecte
		 * el zoom/paneo de camGame.
		 */

		poopBarUp = new FunkinSprite();
		poopBarUp.applyStageMatrix = false;
		poopBarUp.scrollFactor.set(0, 0);
		poopBarUp.makeGraphic(1, 1, FlxColor.BLACK);
		poopBarUp.scale.set(
			FlxG.width * BAR_SCREEN_WIDTH_MULT,
			FlxG.height
		);
		poopBarUp.updateHitbox();
		poopBarUp.x =
			(FlxG.width - poopBarUp.width) / 2;
		poopBarUp.y = BAR_UP_SCREEN_Y;
		poopBarUp.visible = true;
		poopBarUp.alpha = 1;

		if (state.camCutscene != null)
			poopBarUp.cameras = [state.camCutscene];

		state.add(poopBarUp);


		poopBarDown = new FunkinSprite();
		poopBarDown.applyStageMatrix = false;
		poopBarDown.scrollFactor.set(0, 0);
		poopBarDown.makeGraphic(1, 1, FlxColor.BLACK);
		poopBarDown.scale.set(
			FlxG.width * BAR_SCREEN_WIDTH_MULT,
			FlxG.height
		);
		poopBarDown.updateHitbox();
		poopBarDown.x =
			(FlxG.width - poopBarDown.width) / 2;
		poopBarDown.y = BAR_DOWN_SCREEN_Y;
		poopBarDown.visible = true;
		poopBarDown.alpha = 1;

		if (state.camCutscene != null)
			poopBarDown.cameras = [state.camCutscene];

		state.add(poopBarDown);
	}



	function barsPostUpdate():Void
	{
		lockBarsToScreenCamera();
		hookBarsPostUpdate();
	}


	function hookBarsPostUpdate():Void
	{
		if (barsPostUpdateHooked)
			return;

		FlxG.signals.postUpdate.add(barsPostUpdate);
		barsPostUpdateHooked = true;
	}


	function unhookBarsPostUpdate():Void
	{
		if (!barsPostUpdateHooked)
			return;

		FlxG.signals.postUpdate.remove(barsPostUpdate);
		barsPostUpdateHooked = false;
	}


	function keepCutsceneCameraBelowHud():Void
	{
		var state = PlayState.instance;

		if (
			state == null ||
			state.camCutscene == null ||
			state.camHUD == null
		)
			return;

		var cutIndex:Int = FlxG.cameras.list.indexOf(state.camCutscene);
		var hudIndex:Int = FlxG.cameras.list.indexOf(state.camHUD);

		if (cutIndex < 0 || hudIndex < 0)
			return;

		// Si camCutscene ya está debajo de camHUD, no hacemos nada.
		if (cutIndex < hudIndex)
			return;

		/*
		 * Quitamos camCutscene SIN destruirla y la insertamos
		 * justo antes de camHUD.
		 *
		 * Orden final:
		 *   ... -> camCutscene -> camHUD -> ...
		 *
		 * Así las barras siguen en camCutscene, pero el HUD
		 * se renderiza encima.
		 */
		FlxG.cameras.remove(state.camCutscene, false);

		hudIndex = FlxG.cameras.list.indexOf(state.camHUD);

		if (hudIndex < 0)
			return;

		FlxG.cameras.insert(
			state.camCutscene,
			hudIndex,
			false
		);
	}


	function lockBarsToScreenCamera():Void
	{
		keepCutsceneCameraBelowHud();
		var state = PlayState.instance;

		if (
			state == null ||
			state.camCutscene == null
		)
			return;

		/*
		 * camCutscene es una cámara de pantalla administrada por PlayState.
		 * No comparte el zoom de camGame y tampoco depende del alpha de camHUD.
		 */
		state.camCutscene.zoom = 1;
		state.camCutscene.scroll.set(0, 0);
		state.camCutscene.x = 0;
		state.camCutscene.y = 0;
		state.camCutscene.angle = 0;
		state.camCutscene.alpha = 1;
		state.camCutscene.visible = true;

		if (poopBarUp != null)
		{
			poopBarUp.applyStageMatrix = false;
			poopBarUp.scrollFactor.set(0, 0);
			poopBarUp.cameras = [state.camCutscene];

			if (!BAR_ALLOW_AUTOMATIC_MOVES)
				poopBarUp.y = BAR_UP_SCREEN_Y;
		}

		if (poopBarDown != null)
		{
			poopBarDown.applyStageMatrix = false;
			poopBarDown.scrollFactor.set(0, 0);
			poopBarDown.cameras = [state.camCutscene];

			if (!BAR_ALLOW_AUTOMATIC_MOVES)
				poopBarDown.y = BAR_DOWN_SCREEN_Y;
		}
	}



	function cleanupCutscene():Void
	{
		var state = PlayState.instance;

		if (cutsceneTimer != null)
		{
			cutsceneTimer.cancel();
			cutsceneTimer.destroy();
			cutsceneTimer = null;
		}

		if (cameraTimer1 != null)
		{
			cameraTimer1.cancel();
			cameraTimer1.destroy();
			cameraTimer1 = null;
		}

		if (cameraTimer2 != null)
		{
			cameraTimer2.cancel();
			cameraTimer2.destroy();
			cameraTimer2 = null;
		}

		if (cutsceneSound != null)
		{
			cutsceneSound.stop();
			cutsceneSound = null;
		}

		if (state != null && state.currentStage != null)
		{
			var bf = state.currentStage.getBoyfriend();

			if (bf != null)
				bf.visible = true;

			if (cutsceneBf != null)
			{
				state.currentStage.remove(cutsceneBf);
				cutsceneBf.kill();
				cutsceneBf.destroy();
				cutsceneBf = null;

				state.currentStage.refresh();
			}
		}

		if (state != null && state.currentStage != null)
		{
			var dad = state.currentStage.getDad();

			if (dad != null)
				dad.visible = true;
		}

		cutsceneRunning = false;
	}


	function finishMobileCutscene():Void
	{
		var state = PlayState.instance;

		if (state == null)
			return;

		cleanupCutscene();

		state.isInCutscene = false;

		state.startCountdown();
	}


	function startMobileCutscene():Void
	{
		createChromShader();
		chromaEffect(0.1, 0, FlxEase.sineOut);

		var state = PlayState.instance;

		if (state == null)
			return;

		if (state.isChartingMode)
		{
			state.startCountdown();
			return;
		}

		if (cutsceneRunning)
			return;

		cutsceneRunning = true;
		cutscenePlayed = true;
		PlayState.seenCutscene = true;
		state.isInCutscene = true;

		/*
		 * PANTALLA NEGRA INICIAL - equivalente Mobile al ui.script de PC.
		 * Usamos las cámaras en vez de crear un sprite fullscreen nuevo.
		 */
		if (state.camGame != null)
			state.camGame.fade(
				FlxColor.BLACK,
				0,
				false
			);

		if (state.camCutscene != null)
			state.camCutscene.fade(
				FlxColor.BLACK,
				0,
				false
			);

		// Movimiento inicial de las barras de la cutscene:
		// superior sube 100 px, inferior baja 100 px.
		if (poopBarUp != null)
			poopBarUp.y -= 0;

		if (poopBarDown != null)
			poopBarDown.y += 0;

		// Posicion inicial de la camara durante la intro.
		// +X = derecha, +Y = abajo.
		state.cameraFollowPoint.x += 600;
		state.cameraFollowPoint.y += 400;

		var stage = state.currentStage;

		if (stage != null)
		{
			// Movimiento original del snowman durante la intro.
			// No modifica su alpha.
			var snowman = stage.getNamedProp("snowman");

			if (snowman != null)
				snowman.x += 350;

			var introDad = stage.getDad();

			if (introDad != null)
				introDad.visible = false;
		}

		if (stage != null)
		{
			var bf = stage.getBoyfriend();

			if (bf != null)
			{
				cutsceneBf = new FunkinSprite(
					bf.x + 592,
					bf.y + 233,
					Paths.animateAtlas(
						"stages/xMassCityMallNasty/intro-cutscene",
						"shared"
					)
				);

				cutsceneBf.zIndex = bf.zIndex + 15;
				cutsceneBf.applyStageMatrix = false;

		// Shader de color original del BF de la cutscene.
		var cutsceneColorShader = new AdjustColorShader();
		cutsceneColorShader.hue = -10;
		cutsceneColorShader.saturation = -20;
		cutsceneColorShader.contrast = 0;
		cutsceneColorShader.brightness = 0;
		cutsceneBf.shader = cutsceneColorShader;


				stage.add(cutsceneBf);
				stage.refresh();

				bf.visible = false;

				cutsceneBf.animation.play(
					"spritemap",
					true
				);
			}

			var dad = stage.getDad();

			if (dad != null)
			{
				new FlxTimer().start(
					4.19,
					function(timer)
					{
						if (
							PlayState.instance != null &&
							PlayState.instance.currentStage != null
						)
						{
							var currentDad =
								PlayState.instance.currentStage.getDad();

							if (currentDad != null)
							{
								currentDad.visible = true;

								currentDad.playAnimation(
									"trans",
									true
								);

								// Al terminar "trans", pasa a "singRIGHT-alt".
								// 13 frames a 24 FPS = ~0.542 segundos.
								new FlxTimer().start(
									13 / 24,
									function(animTimer)
									{
										var animState = PlayState.instance;

										if (
											animState == null ||
											animState.currentStage == null
										)
											return;

										var animDad =
											animState.currentStage.getDad();

										if (animDad != null)
										{
											animDad.playAnimation(
												"singRIGHT-alt",
												true
											);
										}
									}
								);
							}

							// IMPORTANTE:
							// El alejamiento anterior debe seguir moviéndose durante
							// estos 0.6 s, igual que en el ui.script original.
							if (barReturnTimer != null)
								barReturnTimer.cancel();

							barReturnTimer = new FlxTimer().start(
								0.6,
								function(barTimer)
								{
									barReturnTimer = null;
									// Mobile: regreso parcial equivalente a 125 -> 80.
									moveBarsRelative(
										80,
										true,
										0.35,
										FlxEase.backOut
									);
								}
							);

							// Zoom original que acompaña la aparición.
							PlayState.instance.tweenCameraZoom(
								1.1,
								0.35,
								false,
								FlxEase.backOut
							);
						}
					}
				);
			}
		}

		cutsceneSound =
			FunkinSound.load(
				Paths.sound("songs/lemon-intro"),
				1,
				false,
				true,
				false
			);

		/*
		 * Original PC:
		 * a los 0.15 s comienza lemon-intro y la pantalla negra
		 * desaparece durante 0.5 s.
		 */
		new FlxTimer().start(
			0.15,
			function(introTimer)
			{
				if (cutsceneSound != null)
					cutsceneSound.play(true);

				var introState = PlayState.instance;

				if (introState == null)
					return;

				if (introState.camGame != null)
					introState.camGame.fade(
						FlxColor.BLACK,
						0.5,
						true
					);

				if (introState.camCutscene != null)
					introState.camCutscene.fade(
						FlxColor.BLACK,
						0.5,
						true
					);
			}
		);

		// ZOOMS Y MOVIMIENTOS DE CÁMARA DEL UI.HX ORIGINAL.
		// 0.15 s: zoom 2 -> 1.8.
		state.tweenCameraZoom(2, 0, false);
		state.tweenCameraZoom(1.8, 0.75, false, FlxEase.cubeOut);

		// 0.15 + 33/24 = 1.525 s:
		// zoom 1.7 y desplaza el punto de cámara.
		cameraTimer1 = new FlxTimer().start(
			0.15 + 33 / 24,
			function(timer)
			{
				var currentState = PlayState.instance;

				if (currentState == null)
					return;

				currentState.tweenCameraZoom(
					1.7,
					13 / 24,
					false,
					FlxEase.quadInOut
				);

				currentState.tweenCameraToPosition(
					currentState.cameraFollowPoint.x + 10,
					currentState.cameraFollowPoint.y - 50,
					13 / 24,
					FlxEase.quadInOut
				);

				chromaEffect(0, 0.15, FlxEase.sineOut);

				// Mobile: acercamiento equivalente al cambio 100 -> 75.
				// Se amplifica para que sea visible en pantalla móvil.
				moveBarsRelative(
					10,
					true,
					1.1,
					FlxEase.backOut
				);

			}
		);

		// 0.15 + 90/24 = 3.9 s:
		// alejamiento fuerte y movimiento a la posición de Dad.
		cameraTimer2 = new FlxTimer().start(
			0.15 + 90 / 24,
			function(timer)
			{
				var currentState = PlayState.instance;

				if (currentState == null)
					return;

				currentState.tweenCameraZoom(
					0.9,
					26 / 24,
					false,
					FlxEase.quadInOut
				);

				currentState.tweenCameraToPosition(
					-250,
					-500,
					26 / 24,
					FlxEase.quadInOut
				);

				// Alejamiento visual:
				// barra superior sube, barra inferior baja.
				// Mobile: alejamiento fuerte confirmado funcionando.
				// Arriba sube 220 px y abajo baja 220 px.
				moveBarsRelative(
					20,
					false,
					1.1,
					FlxEase.backOut
				);
			}
		);


		// ~4.9 s: shake de cámara + transición de darkLight del original.
		new FlxTimer().start(
			0.15 + 114 / 24,
			function(lightTimer)
			{
				var lightState = PlayState.instance;

				if (lightState == null)
					return;

				chromaEffect(0.25, 0.15, FlxEase.sineOut);

				if (lightState.camGame != null)
					lightState.camGame.shake(0.0025, 15 / 25);

				getStageLights();

				if (darkLight != null)
				{
					FlxTween.cancelTweensOf(darkLight);
					darkLight.alpha = 0.5;

					FlxTween.tween(
						darkLight,
						{alpha: 0.6},
						1,
						{ease: FlxEase.bounceIn}
					);

					// Segunda transición del original.
					FlxTween.tween(
						darkLight,
						{alpha: 0.9},
						25 / 24,
						{
							startDelay: 1,
							onStart: function(_)
							{
								chromaEffect(0.05, 1, FlxEase.cubeOut);
							},
							ease: FlxEase.quadOut
						}
					);
				}
			}
		);

		cutsceneTimer =
			new FlxTimer().start(
				7.8,
				function(timer)
				{
					finishMobileCutscene();
				}
			);
	}


	function onCountdownStart(event)
	{
		var state = PlayState.instance;

		if (state == null)
			return;

		if (state.isChartingMode)
			return;

		/*
		 * PRIMER COUNTDOWN
		 *
		 * Se reserva exclusivamente para AnimaniaLoadingScreen.
		 * El loading será quien lo cancele.
		 */
		if (!loadingCountdownSkipped)
		{
			loadingCountdownSkipped = true;
			return;
		}

		/*
		 * SEGUNDO COUNTDOWN
		 *
		 * El loading terminó y llamó otra vez a startCountdown().
		 * Ahora Winter Horrorland puede controlar su cutscene.
		 */
		if (PlayState.seenCutscene)
		{
			if (state.currentStage != null)
			{
				var retryBf = state.currentStage.getBoyfriend();

				if (retryBf != null)
					retryBf.visible = true;

				var retryDad = state.currentStage.getDad();

				if (retryDad != null)
					retryDad.visible = true;
			}

			cutscenePlayed = true;
			return;
		}

		if (!cutscenePlayed)
		{
			event.cancel();

			startMobileCutscene();
		}
	}



	/*
	 * =========================================================
	 * SUBTÍTULOS NATIVOS - ALPHABET WHITE TTF
	 * =========================================================
	 *
	 * NO reemplaza el sistema SRT de V-Slice.
	 *
	 * V-Slice sigue encargándose de:
	 * - leer song-lyrics.srt
	 * - sincronizar tiempos
	 * - interpretar colores/tamaños HTML del SRT
	 * - posicionar los subtítulos
	 *
	 * Aquí únicamente cambiamos la fuente del FlxText nativo.
	 *
	 * Archivo requerido:
	 *
	 *     fonts/alphabet-white.ttf
	 */

	var nativeSubtitleFontApplied:Bool = false;

	function applyAlphabetSubtitleFont():Void
	{
		if (nativeSubtitleFontApplied)
			return;

		var state = PlayState.instance;

		if (state == null)
			return;

		if (state.subtitles == null)
			return;

		/*
		 * Subtitles nativo agrega sus objetos en este orden:
		 *
		 * members[0] = fondo negro
		 * members[1] = SubtitlesText
		 *
		 * Evitamos Reflect/Type para Mobile.
		 */
		if (
			state.subtitles.members == null ||
			state.subtitles.members.length < 2
		)
			return;

		var subtitleText = state.subtitles.members[1];

		if (subtitleText == null)
			return;

		/*
		 * Cambiar SOLO la fuente.
		 *
		 * No cambiamos subtitleText.text/htmlText, por lo que
		 * las etiquetas <font color="..."> del SRT continúan
		 * siendo procesadas por el sistema nativo.
		 */
		subtitleText.font =
			Paths.font("alphabet-white.ttf");

		/*
		 * Mantener el tamaño base nativo de Subtitles (30).
		 * Las etiquetas size del SRT pueden seguir modificándolo.
		 */
		subtitleText.size = 40;

		nativeSubtitleFontApplied = true;
	}


	/*
	 * =========================================================
	 * CREATE
	 * =========================================================
	 */

	function onCreate(event)
	{
		super.onCreate(event);

		lethalMissPending = false;
		allowDelayedEnd = false;
		nativeSubtitleFontApplied = false;

		if (songEndDelayTimer != null)
		{
			songEndDelayTimer.cancel();
			songEndDelayTimer.destroy();
			songEndDelayTimer = null;
		}

		cleanupCutscene();
		cleanupMobileBattleHint();
		loadingCountdownSkipped = false;
		cutscenePlayed = false;

		prepareWinterHorrorlandStart();
		createCinematicBars();
	}


	/*
	 * =========================================================
	 * SONG START
	 * =========================================================
	 */


	function onCreatePost(event)
	{
		super.onCreatePost(event);

		keepCutsceneCameraBelowHud();

		applyAlphabetSubtitleFont();

		forceInitialStageLights();
		lockBarsToScreenCamera();
	}

	function onSongStart(event)
	{
		super.onSongStart(event);

		lethalMissPending = false;

		applyAlphabetSubtitleFont();

		var state = PlayState.instance;

		if (state != null && state.currentStage != null)
		{
			var bf = state.currentStage.getBoyfriend();

			if (bf != null)
				bf.visible = true;
		}
	}


	/*
	 * =========================================================
	 * UPDATE
	 * =========================================================
	 *
	 * Procesa una muerte pendiente.
	 */

	override function onUpdate(
		event:UpdateScriptEvent
	):Void
	{
		super.onUpdate(event);

		// Mantener camCutscene como cámara de pantalla fija.
		lockBarsToScreenCamera();

		// Fallback: si Subtitles todavía no existía en onCreatePost,
		// aplicamos la fuente en cuanto el objeto nativo esté disponible.
		if (!nativeSubtitleFontApplied)
			applyAlphabetSubtitleFont();

		if (!lethalMissPending)
			return;


		var state =
			PlayState.instance;


		if (state == null)
			return;


		state.health = 0;


		lethalMissPending = false;
	}


	/*
	 * =========================================================
	 * NOTA DEL OPONENTE
	 * =========================================================
	 *
	 * Cada nota normal acertada por el oponente
	 * drena 0.035 de vida.
	 */

	override function onNoteHit(
		event:HitNoteScriptEvent
	):Void
	{
		super.onNoteHit(event);


		if (!isHealthDrainEnabled())
			return;


		if (event.note == null)
			return;


		/*
		 * Ignorar las notas del jugador.
		 */

		if (
			event.note.noteData.getMustHitNote()
		)
		{
			return;
		}


		var state =
			PlayState.instance;


		if (state == null)
			return;


		var currentHealth:Float =
			state.health;


		/*
		 * El Health Drain no puede bajar
		 * la vida de 0.10.
		 */

		if (
			currentHealth <=
			healthDrainMinimum
		)
		{
			event.healthChange = 0;
			return;
		}


		var damage:Float =
			healthDrainPerNote;


		/*
		 * Limitar el último drenaje para
		 * dejar exactamente 0.10 de vida.
		 */

		if (
			currentHealth - damage <
			healthDrainMinimum
		)
		{
			damage =
				currentHealth -
				healthDrainMinimum;
		}


		event.healthChange =
			-damage;
	}


	/*
	 * =========================================================
	 * NOTA FALLADA
	 * =========================================================
	 *
	 * Si el jugador está en 0.10 y falla
	 * una nota, se permite el Game Over.
	 */

	override function onNoteMiss(
		event:NoteScriptEvent
	):Void
	{
		var state =
			PlayState.instance;


		var shouldKill:Bool =
			false;


		if (
			state != null &&
			isHealthDrainEnabled() &&
			event.note != null
		)
		{
			if (
				event.note.noteData.getMustHitNote() &&
				state.health <= healthDrainMinimum
			)
			{
				shouldKill = true;
			}
		}


		/*
		 * Mantener el comportamiento normal
		 * del fallo.
		 */

		super.onNoteMiss(event);


		/*
		 * Procesar la muerte en onUpdate().
		 */

		if (shouldKill)
			lethalMissPending = true;
	}


	/*
	 * =========================================================
	 * ILUMINACIÓN POR BEAT
	 * =========================================================
	 */

	override function onBeatHit(
		event:SongTimeScriptEvent
	):Void
	{
		super.onBeatHit(event);


		var beat:Int =
			event.beat;


		switch (beat)
		{
			case 8:
				// Comportamiento original de ui.script adaptado a Mobile.
				chromaEffect(0.35, 0, FlxEase.sineOut);
				chromaEffect(0.15, 41 / 24, FlxEase.cubeOut);

				if (darkLight != null)
				{
					FlxTween.cancelTweensOf(darkLight);
					darkLight.alpha = 0.4;
					FlxTween.tween(
						darkLight,
						{alpha: 0.7},
						41 / 24,
						{ease: FlxEase.cubeOut}
					);
				}

				if (blend2 != null)
				{
					FlxTween.cancelTweensOf(blend2);
					blend2.alpha = 1;
					FlxTween.tween(
						blend2,
						{alpha: 0.6},
						41 / 24,
						{ease: FlxEase.cubeOut}
					);
				}

				if (PlayState.instance != null && PlayState.instance.currentStage != null)
				{
					var snowman = PlayState.instance.currentStage.getNamedProp("snowman");

					if (snowman != null && snowman.x > 350)
						snowman.x -= 350;
				}

				showMobileBattleHint();

				// Movimiento de barras del beat 8 desactivado por ahora.
				// Las barras siguen en camCutscene y no reciben el zoom.


			case 16:
				hideMobileBattleHint();


			case 22:
				showHudAtBeat22();

				// Comportamiento original de ui.script adaptado a Mobile.
				chromaEffect(
					0.075,
					3,
					FlxEase.sineOut
				);

				if (darkLight != null)
				{
					FlxTween.cancelTweensOf(darkLight);
					FlxTween.tween(
						darkLight,
						{alpha: 0.85},
						15 / 24,
						{ease: FlxEase.linear}
					);
				}


			case 24:
				if (poopBarUp != null && poopBarDown != null)
				{
					// Mobile: gran alejamiento final.
					moveBarsRelative(
						0,
						true,
						1.1,
						FlxEase.backOut
					);
				}


			case 40:
				if (darkLight != null)
				{
					FlxTween.cancelTweensOf(darkLight);
					FlxTween.tween(
						darkLight,
						{alpha: 1},
						25 / 24,
						{ease: FlxEase.quadInOut}
					);
				}


			case 56:
				if (darkLight != null)
				{
					FlxTween.cancelTweensOf(darkLight);
					FlxTween.tween(
						darkLight,
						{alpha: 0.6},
						30 / 24,
						{ease: FlxEase.quadInOut}
					);
				}


			case 72:
				if (darkLight != null)
				{
					FlxTween.cancelTweensOf(darkLight);
					FlxTween.tween(
						darkLight,
						{alpha: 1},
						56 / 24,
						{ease: FlxEase.linear}
					);
				}


			case 84:
				if (darkLight != null)
				{
					FlxTween.cancelTweensOf(darkLight);
					FlxTween.tween(
						darkLight,
						{alpha: 0},
						12 / 24,
						{ease: FlxEase.cubeOut}
					);
				}

				createHahaha(-800, -800);


			case 85:
				createHahaha(-1150, -665);


			case 86:
				createHahaha(-1350, -1115);


			case 87:
				createHahaha(-850, -1150);


			case 88:
				if (blend2 != null)
				{
					FlxTween.cancelTweensOf(blend2);
					blend2.alpha = 1;
					FlxTween.tween(
						blend2,
						{alpha: 0.7},
						18 / 24,
						{ease: FlxEase.cubeOut}
					);
				}

				removeHahaha();


			case 386:
				// Fade final del ui.script original.
				// Aplicado a todas las cámaras para cubrir toda la pantalla.
				var endState = PlayState.instance;

				if (endState != null)
				{
					if (endState.camGame != null)
						endState.camGame.fade(
							FlxColor.BLACK,
							1.5,
							false
						);

					if (endState.camHUD != null)
						endState.camHUD.fade(
							FlxColor.BLACK,
							1.5,
							false
						);

					if (endState.camCutscene != null)
						endState.camCutscene.fade(
							FlxColor.BLACK,
							1.5,
							false
						);
				}
		}
	}


	/*
	 * =========================================================
	 * SONG END
	 * =========================================================
	 */

	function onSongEnd(event)
	{
		/*
		 * ui.script original:
		 * bloquea el final durante 1 segundo y después llama endSong().
		 */
		if (!allowDelayedEnd)
		{
			event.cancel();
			allowDelayedEnd = true;

			if (songEndDelayTimer != null)
			{
				songEndDelayTimer.cancel();
				songEndDelayTimer.destroy();
				songEndDelayTimer = null;
			}

			songEndDelayTimer = new FlxTimer().start(
				1,
				function(timer)
				{
					songEndDelayTimer = null;

					var state = PlayState.instance;

					if (state != null)
						state.endSong();
				}
			);

			return;
		}

		cleanupCutscene();
		cleanupCinematicBars();
		cleanupMobileBattleHint();

		resetWinterHorrorlandState();

		super.onSongEnd(event);
	}

	/*
	 * Al salir del PlayState, dejamos preparado el flag para que
	 * una futura entrada vuelva a reservar el primer countdown
	 * exclusivamente a AnimaniaLoadingScreen.
	 */
	function onStateChangeBegin(event):Void
	{
		loadingCountdownSkipped = false;
	}

}