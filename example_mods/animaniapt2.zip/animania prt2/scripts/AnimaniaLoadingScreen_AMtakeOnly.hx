import flixel.FlxG;
import flixel.FlxSprite;
import flixel.FlxCamera;
import flixel.util.FlxColor;
import flixel.math.FlxMath;

import funkin.Paths;
import funkin.play.PlayState;
import funkin.audio.FunkinSound;
import funkin.graphics.FunkinSprite;

import funkin.modding.module.Module;
import funkin.modding.module.ModuleHandler;
import funkin.modding.events.ScriptEvent;

class AnimaniaLoadingScreen extends Module implements IPlayStateScriptedClass
{
	var game:PlayState = null;

	var loadingCamera:FlxCamera = null;
	var loadingBG:FlxSprite = null;

	var longBar:FlxSprite = null;
	var boxOfNoodles:FlxSprite = null;
	var bfSpr:FlxSprite = null;
	var dadbattleViz:Array<FunkinSprite> = [];
	var dadbattleVizTime:Float = 0;

	var pressEnter:FlxSprite = null;
	var blackLoading:FlxSprite = null;

	var loadingMusic:FunkinSound = null;

	var loadingActive:Bool = false;
	var loadingFinished:Bool = false;
	var ready:Bool = false;
	var fadingOut:Bool = false;

	var loadTime:Float = 0;
	var loadDelay:Float = 2.0;

	var fadeTime:Float = 0;
	var fadeDuration:Float = 1.5;

	var barStartWidth:Float = 900;
	var barEndWidth:Float = 100;

	var songId:String = "";
	var imagePath:String = null;

	public function new()
	{
		super("AnimaniaLoadingScreen", 1000);
	}

	public function onScriptEvent(event:ScriptEvent):Void
	{
		if (event == null)
			return;

		if (event.type == "COUNTDOWN_START")
			handleCountdown(event);
	}

	function handleCountdown(event:ScriptEvent):Void
	{
		if (loadingFinished)
			return;

		game = PlayState.instance;

		if (game == null || game.currentSong == null)
			return;

		songId = Std.string(game.currentSong.id);
		imagePath = getLoadingImage(songId);

		// Solo las canciones AMtake usan esta pantalla de carga.
		if (imagePath == null)
			return;

		event.cancel();

		if (loadingActive)
			return;

		createLoadingScreen();
	}

	function getLoadingImage(id:String):String
	{
		switch (id)
		{
			case "bopeebo-amtake" | "fresh-amtake":
				return "loadingScreen/funkin-week1";

			case "dadbattle-amtake":
				return "loadingScreen/funkin-week1-dadbattle";

			case "cocoa-amtake" | "eggnog-amtake":
				return "loadingScreen/funkin";

			case "winter-horrorland-amtake":
				return "loadingScreen/funkin-wh";
		}

		return null;
	}
	
	function createLoadingScreen():Void
	{
		if (game == null)
			return;

		loadingActive = true;
		loadingFinished = false;
		ready = false;
		fadingOut = false;
		loadTime = 0;
		fadeTime = 0;

		startLoadingMusic();


		if (game.camGame != null)
			game.camGame.visible = false;

		if (game.camHUD != null)
			game.camHUD.visible = false;

		loadingCamera = new FlxCamera();
		loadingCamera.bgColor = 0;
		FlxG.cameras.add(loadingCamera, false);

		loadingBG = new FlxSprite();
		loadingBG.loadGraphic(Paths.image(imagePath));
		loadingBG.setGraphicSize(FlxG.width, FlxG.height);
		loadingBG.updateHitbox();
		loadingBG.screenCenter();
		loadingBG.scrollFactor.set(0, 0);
		loadingBG.cameras = [loadingCamera];
		game.add(loadingBG);

		pressEnter = new FlxSprite(0, 635);
		pressEnter.frames = Paths.getSparrowAtlas("loadingScreen/pressEnter");
		pressEnter.animation.addByPrefix("idle", "press to start образец 1000", 24, false);
		pressEnter.animation.play("idle", true);
		pressEnter.x = (FlxG.width - pressEnter.width) / 2;
		pressEnter.scrollFactor.set(0, 0);
		pressEnter.visible = false;
		pressEnter.cameras = [loadingCamera];
		game.add(pressEnter);

		if (songId == "dadbattle-amtake")
		{
			createDadbattleViz();
		}
		else if (songId == "winter-horrorland-amtake")
		{
			// Winter Horrorland no usa BF, longNoodle ni boxOfNoodles.
		}
		else if (
			songId == "bopeebo-amtake" ||
			songId == "fresh-amtake" ||
			songId == "cocoa-amtake" ||
			songId == "eggnog-amtake"
		)
		{
			longBar = new FlxSprite(50, 670);
			longBar.loadGraphic(Paths.image("loadingScreen/longNoodle"));
			longBar.scrollFactor.set(0, 0);
			longBar.cameras = [loadingCamera];
			game.add(longBar);

			boxOfNoodles = new FlxSprite(0, 585);
			boxOfNoodles.loadGraphic(Paths.image("loadingScreen/boxOfNoodles"));
			boxOfNoodles.scrollFactor.set(0, 0);
			boxOfNoodles.cameras = [loadingCamera];
			game.add(boxOfNoodles);

			createLoadingBF();
		}

		blackLoading = new FlxSprite(0, 0);
		blackLoading.makeGraphic(FlxG.width, FlxG.height, FlxColor.BLACK);
		blackLoading.scrollFactor.set(0, 0);
		blackLoading.alpha = 0;
		blackLoading.cameras = [loadingCamera];
		game.add(blackLoading);
	}

	function createLoadingBF():Void
	{
		if (game == null || boxOfNoodles == null)
			return;

		bfSpr = new FlxSprite(
			boxOfNoodles.width - 10,
			boxOfNoodles.y
		);

		bfSpr.frames = Paths.getSparrowAtlas("loadingScreen/bf");

		bfSpr.animation.addByPrefix(
			"idle",
			"bf ate",
			24,
			false
		);

		bfSpr.animation.addByPrefix(
			"finished",
			"load complete",
			24,
			false
		);

		bfSpr.animation.play("idle", true);
		bfSpr.scrollFactor.set(0, 0);
		bfSpr.cameras = [loadingCamera];

		game.add(bfSpr);
	}

	function createDadbattleViz():Void
	{
		if (game == null)
			return;

		dadbattleViz = [];

		for (i in 1...12)
		{
			var viz:FunkinSprite = new FunkinSprite(
				0,
				0,
				Paths.animateAtlas(
					"loadingScreen/dadbattleviz"
				)
			);

			viz.hasAnimation(
				"viz" + i
			);

			viz.anim.play(
				"viz" + i,
				true
			);

			viz.scale.set(
				loadingBG.scale.x,
				loadingBG.scale.y
			);

			viz.updateHitbox();

			viz.x =
				(FlxG.width - viz.width) / 2;

			viz.y =
				(FlxG.height - viz.height) / 2;

			viz.x += 5;
			viz.y += 3;

			viz.scrollFactor.set(0, 0);
			viz.cameras = [loadingCamera];

			game.add(viz);

			if (viz.animation.curAnim != null)
			{
				viz.animation.curAnim.finish();
				viz.animation.curAnim.curFrame = 0;
			}

			dadbattleViz.push(viz);
		}

	}

	function updateDadbattleViz(elapsed:Float):Void
	{
		if (dadbattleViz == null)
			return;

		if (dadbattleViz.length < 11)
			return;

		dadbattleVizTime += elapsed;

		for (i in 0...11)
		{
			var viz:FunkinSprite = dadbattleViz[i];

			if (viz == null)
				continue;

			if (viz.animation.curAnim == null)
				continue;

			/*
			 * Simulación visual para Mobile.
			 * Cada banda se mueve con una velocidad
			 * y fase ligeramente diferentes.
			 */
			var wave:Float =
				Math.sin(
					dadbattleVizTime * (5.0 + i * 0.17) +
					i * 0.75
				);

			var wave2:Float =
				Math.sin(
					dadbattleVizTime * (8.0 + i * 0.11) +
					i * 1.35
				);

			var value:Float =
				((wave + wave2 * 0.45) + 1.45) /
				2.9;

			if (value < 0)
				value = 0;

			if (value > 1)
				value = 1;

			var frame:Int =
				Math.round(value * 13);

			viz.animation.curAnim.curFrame =
				frame;
		}
	}


	function startLoadingMusic():Void
	{
		var soundPath:String =
			"loadingThemeLol/loadingThemeLol";

		if (songId == "dadbattle-amtake")
		{
			soundPath =
				"loadingThemeLol/loadingThemeLol-dadbattle";
		}

		loadingMusic =
			FunkinSound.load(
				Paths.sound(soundPath)
			);

		if (loadingMusic != null)
		{
			loadingMusic.volume = 1;

			if (songId == "winter-horrorland-amtake")
				loadingMusic.pitch = 0.1;
			else
				loadingMusic.pitch = 1;

			loadingMusic.play(true);
		}
	}

	override function onUpdate(event)
	{
		super.onUpdate(event);

		if (!loadingActive)
			return;

		if (songId == "dadbattle-amtake")
			updateDadbattleViz(event.elapsed);

		if (fadingOut)
		{
			fadeTime += event.elapsed;

			var fadeProgress:Float =
				fadeTime / fadeDuration;

			if (fadeProgress < 0)
				fadeProgress = 0;

			if (fadeProgress > 1)
				fadeProgress = 1;

			if (blackLoading != null)
				blackLoading.alpha = fadeProgress;

			if (loadingMusic != null)
				loadingMusic.volume = 1 - fadeProgress;

			if (fadeProgress >= 1)
				finishLoading();

			return;
		}

		if (!ready)
		{
			loadTime += event.elapsed;

			var progress:Float =
				loadTime / loadDelay;

			if (progress < 0)
				progress = 0;

			if (progress > 1)
				progress = 1;

			var currentWidth:Float =
				barStartWidth +
				(barEndWidth - barStartWidth) *
				progress;

			if (longBar != null && longBar.frameWidth > 0)
			{
				longBar.scale.x =
					currentWidth /
					longBar.frameWidth;

				longBar.updateHitbox();
				longBar.x = 50;
			}

			if (bfSpr != null)
			{
				bfSpr.x = currentWidth;

				if (
					bfSpr.animation.curAnim != null &&
					bfSpr.animation.curAnim.finished
				)
				{
					bfSpr.animation.play(
						"idle",
						true
					);
				}
			}

			if (progress >= 1)
				setReady();

			return;
		}

		if (FlxG.touches.justStarted().length > 0)
			startFadeOut();
	}

	function setReady():Void
	{
		if (ready)
			return;

		ready = true;

		if (longBar != null && longBar.frameWidth > 0)
		{
			longBar.scale.x =
				barEndWidth /
				longBar.frameWidth;

			longBar.updateHitbox();
			longBar.x = 50;
		}

		if (bfSpr != null)
		{
			bfSpr.x = 135;

			if (boxOfNoodles != null)
				bfSpr.y = boxOfNoodles.y - 20;

			bfSpr.animation.play(
				"finished",
				true
			);
		}

		if (pressEnter != null)
		{
			pressEnter.visible = true;
			pressEnter.animation.play("idle", true);
		}
	}

	function startFadeOut():Void
	{
		if (!ready || fadingOut)
			return;

		fadingOut = true;
		fadeTime = 0;

		if (blackLoading != null)
			blackLoading.alpha = 0;
	}

	function stopLoadingMusic():Void
	{
		if (loadingMusic == null)
			return;

		loadingMusic.pitch = 1;
		loadingMusic.stop();
		loadingMusic.destroy();
		loadingMusic = null;
	}

	function finishLoading():Void
	{
		if (!loadingActive)
			return;

		loadingActive = false;
		loadingFinished = true;
		ready = false;
		fadingOut = false;

		stopLoadingMusic();

		if (blackLoading != null)
		{
			if (game != null)
				game.remove(blackLoading, true);

			blackLoading.destroy();
			blackLoading = null;
		}

		if (pressEnter != null)
		{
			if (game != null)
				game.remove(pressEnter, true);

			pressEnter.destroy();
			pressEnter = null;
		}

		if (bfSpr != null)
		{
			if (game != null)
				game.remove(bfSpr, true);

			bfSpr.destroy();
			bfSpr = null;
		}

		if (dadbattleViz != null)
		{
			for (viz in dadbattleViz)
			{
				if (viz == null)
					continue;

				if (game != null)
					game.remove(viz, true);

				viz.destroy();
			}

			dadbattleViz = [];
		}

		dadbattleVizTime = 0;

		if (longBar != null)
		{
			if (game != null)
				game.remove(longBar, true);

			longBar.destroy();
			longBar = null;
		}

		if (boxOfNoodles != null)
		{
			if (game != null)
				game.remove(boxOfNoodles, true);

			boxOfNoodles.destroy();
			boxOfNoodles = null;
		}

		if (loadingBG != null)
		{
			if (game != null)
				game.remove(loadingBG, true);

			loadingBG.destroy();
			loadingBG = null;
		}

		if (loadingCamera != null)
		{
			FlxG.cameras.remove(
				loadingCamera,
				true
			);

			loadingCamera = null;
		}

		if (game != null)
		{
			if (game.camGame != null)
				game.camGame.visible = true;

			if (game.camHUD != null)
				game.camHUD.visible = true;

			game.startCountdown();
		}
	}

	override function onStateChangeBegin(event)
	{
		super.onStateChangeBegin(event);

		stopLoadingMusic();

		if (loadingCamera != null)
		{
			FlxG.cameras.remove(
				loadingCamera,
				true
			);

			loadingCamera = null;
		}

		loadingBG = null;
		pressEnter = null;
		longBar = null;
		boxOfNoodles = null;
		bfSpr = null;
		dadbattleViz = [];
		dadbattleVizTime = 0;
		vizLevel = 0;
		blackLoading = null;

		game = null;

		loadingActive = false;
		loadingFinished = false;
		ready = false;
		fadingOut = false;

		loadTime = 0;
		fadeTime = 0;
	}
}
