import flixel.FlxG;
import flixel.util.FlxTimer;

import openfl.display.BlendMode;
import funkin.Paths;
import funkin.graphics.FunkinSprite;
import funkin.play.PlayState;
import funkin.play.PauseSubState;
import funkin.play.character.CharacterType;
import funkin.play.stage.ScriptedStage;

class XMasCityMallAmTakeDarkStage extends ScriptedStage
{
	public function new()
	{
		super('xMasCityMallAmTakeDark');
	}

	var railBoppers:Array<Dynamic> = [];
	var boppersIdle:Int = 2;

	var bfDarkShader:HSVBlendedShader;
	var gfDarkShader:HSVBlendedShader;
	var dadDarkShader:HSVBlendedShader;

	// SANTA
	var customSanta:FunkinSprite;
	var santaShader:HSVBlendedShader;

	// SNOW FG
	var customSnowFG:FunkinSprite;
	var snowFGShader:HSVBlendedShader;

	// SNOW FG GRAD
	var customSnowFGrad:FunkinSprite;
	var snowFGradShader:HSVBlendedShader;

	// SNOWMAN
	var customSnowman:FunkinSprite;
	var snowmanShader:HSVBlendedShader;
	
	// BANDAGE GIRL
var customBandageGirl:FunkinSprite;
var bandageGirlShader:HSVBlendedShader;

// COPS
var customCops:FunkinSprite;
var copsShader:HSVBlendedShader;

//COOLBUD
var customCoolbud:FunkinSprite;
var coolbudShader:HSVBlendedShader;

//GANG
var customGang:FunkinSprite;
var gangShader:HSVBlendedShader;

//CASSET
var customCasset:FunkinSprite;
var cassetShader:HSVBlendedShader;

//ZONET
var customZonet:FunkinSprite;
var zonetShader:HSVBlendedShader;

var customMeatBoy:FunkinSprite;
var meatBoyShader:HSVBlendedShader;

//TREE CRUSHERS
var customTreeCrushers:FunkinSprite;
var treeCrushersShader:HSVBlendedShader;

//ALIEN SHIP
var customAlienShip:FunkinSprite;
var alienShipShader:HSVBlendedShader;

//BLEND 1 Y 2
var customBlend1:FunkinSprite;
var customBlend2:FunkinSprite;

var blend1Shader:HSVBlendedShader;
var blend2Shader:HSVBlendedShader;

	override function onCreate(event)
	{
		super.onCreate(event);

		PauseSubState.musicSuffix = '-amtake5';
	}

	override function addCharacter(character, charType:CharacterType):Void
	{
		super.addCharacter(character, charType);

		if (character == null)
			return;

		if (charType == CharacterType.BF)
		{
			bfDarkShader = HSVBlendedShader.xmasInit();
			character.shader = bfDarkShader;
			return;
		}

		if (charType == CharacterType.GF)
		{
			gfDarkShader = HSVBlendedShader.xmasInit();
			character.shader = gfDarkShader;
			return;
		}

		if (charType == CharacterType.DAD)
		{
			if (character.characterId == "parents-amtake")
			{
				dadDarkShader = HSVBlendedShader.xmasInit();
				character.shader = dadDarkShader;
			}
			return;
		}
	}

	override function buildStage()
	{
		super.buildStage();

		railBoppers = [];

		addRailBopper("rail-guys-bobby");
		addRailBopper("rail-guys-left");
		addRailBopper("rail-guys-miku");
		addRailBopper("rail-guys-right");
		addRailBopper("rail-guys-far");

		createCustomSanta();
		createCustomSnowFG();
		createCustomSnowFGrad();
		createCustomSnowman();
		createCustomBandageGirl();
		createCustomCops();
		createCustomCoolbud();
		createCustomGang();
		createCustomCasset();
		createCustomZonet();
		createCustomMeatBoy();
		createCustomTreeCrushers();
		createCustomAlienShip();
		createCustomBlends();

		refresh();
	}

	// SANTA
	function createCustomSanta():Void
	{
		if (customSanta != null)
			return;

		customSanta = new FunkinSprite(-1600, -125);

		customSanta.frames = Paths.getSparrowAtlas(
			"stages/xMassCityMall/santa",
			"shared"
		);
		
		customSanta.scale.set(2.0, 2.0);
customSanta.updateHitbox();


		customSanta.scrollFactor.set(1, 1);
		customSanta.zIndex = 302;

		customSanta.animation.addByPrefix("idle", "santa", 24, false);
		customSanta.animation.play("idle", true);

		santaShader = HSVBlendedShader.xmasInit();
		customSanta.shader = santaShader;

		add(customSanta);
	}

	// SNOW FG
	function createCustomSnowFG():Void
	{
		if (customSnowFG != null)
			return;

		customSnowFG = new FunkinSprite(-2500, 100);

		customSnowFG.loadGraphic(
			Paths.image(
				"stages/xMassCityMall/fg-snow",
				"shared"
			)
		);
		
		customSnowFG.scale.set(2.0, 2.0);
customSnowFG.updateHitbox();


		customSnowFG.scrollFactor.set(1, 1);
		customSnowFG.zIndex = 150;
		customSnowFG.alpha = 1;

		snowFGShader = HSVBlendedShader.xmasInit();
		customSnowFG.shader = snowFGShader;

		add(customSnowFG);
	}

	// SNOW FG GRAD
	function createCustomSnowFGrad():Void
	{
		if (customSnowFGrad != null)
			return;

		customSnowFGrad = new FunkinSprite(-2400, -475);

		customSnowFGrad.loadGraphic(
			Paths.image(
				"stages/xMassCityMall/fg-snow-grad",
				"shared"
			)
		);
		
customSnowFGrad.scale.set(2.0, 2.0);
customSnowFGrad.updateHitbox();


		customSnowFGrad.scrollFactor.set(0.975, 0.975);
		customSnowFGrad.zIndex = 149;
		customSnowFGrad.alpha = 1;

		snowFGradShader = HSVBlendedShader.xmasInit();
		customSnowFGrad.shader = snowFGradShader;

		add(customSnowFGrad);
	}

	// SNOWMAN
	function createCustomSnowman():Void
	{
		if (customSnowman != null)
			return;

		customSnowman = new FunkinSprite(500, -50);

		customSnowman.loadGraphic(
			Paths.image(
				"stages/xMassCityMall/snowman",
				"shared"
			)
		);

		customSnowman.scrollFactor.set(1.2, 1.2);
		customSnowman.zIndex = 400;
		customSnowman.alpha = 1;

		snowmanShader = HSVBlendedShader.xmasInit();
		customSnowman.shader = snowmanShader;

		add(customSnowman);
	}
	
	// BANDAGEGIRL
	function createCustomBandageGirl():Void
{
	if (customBandageGirl != null)
		return;

	customBandageGirl = new FunkinSprite(1430, 0);

	customBandageGirl.frames = Paths.getSparrowAtlas(
		"stages/xMassCityMall/bandage_girl",
		"shared"
	);

	customBandageGirl.scrollFactor.set(1, 1);
	customBandageGirl.zIndex = 152;

	customBandageGirl.animation.addByPrefix(
		"idle",
		"bandage girl",
		24,
		false
	);

	customBandageGirl.animation.play("idle", true);

	bandageGirlShader = HSVBlendedShader.xmasInit();
	customBandageGirl.shader = bandageGirlShader;

	add(customBandageGirl);
}
    
    //COPS
    function createCustomCops():Void
{
	if (customCops != null)
		return;

	customCops = new FunkinSprite(700, -210);

	customCops.frames = Paths.getSparrowAtlas(
		"stages/xMassCityMall/cops",
		"shared"
	);

	customCops.scrollFactor.set(1, 1);
	customCops.zIndex = 151;

	customCops.animation.addByPrefix(
		"danceLeft",
		"nightmare cops idle0",
		24,
		false
	);

	customCops.animation.addByPrefix(
		"danceRight",
		"nightmare cops idle 2",
		24,
		false
	);

	customCops.animation.addByIndices(
	"laugh",
	"laught nightmarecops",
	[
		0, 1, 2, 3, 4, 5, 6,
		0, 1, 2, 3, 4, 5, 6,
		0, 1, 2, 3, 4, 5, 6, 7
	],
	"",
	24,
	false
);

	customCops.animation.addByPrefix(
		"throw",
		"nightmare cops throw",
		24,
		false
	);

	customCops.animation.play("danceLeft", true);

	copsShader = HSVBlendedShader.xmasInit();
	customCops.shader = copsShader;

	add(customCops);
}

    //COOLBUD
    function createCustomCoolbud():Void
{
	if (customCoolbud != null)
		return;

	customCoolbud = new FunkinSprite(-1150, -225);

	customCoolbud.frames = Paths.getSparrowAtlas(
		"stages/xMassCityMall/coolbud",
		"shared"
	);

	customCoolbud.scrollFactor.set(0.95, 0.95);
	customCoolbud.zIndex = 103;

	customCoolbud.animation.addByPrefix(
		"idle",
		"iforgothisname",
		24,
		false
	);

	customCoolbud.animation.play("idle", true);

	coolbudShader = HSVBlendedShader.xmasInit();
	customCoolbud.shader = coolbudShader;

	add(customCoolbud);
}

    //GANG
function createCustomGang():Void
{
	if (customGang != null)
		return;

	customGang = new FunkinSprite(-2100, -125);

	customGang.frames = Paths.getSparrowAtlas(
		"stages/xMassCityMall/dagang",
		"shared"
	);
	
	customGang.scale.set(2.0, 2.0);
customGang.updateHitbox();


	customGang.scrollFactor.set(0.925, 0.925);
	customGang.zIndex = 102;

	// Animación completa
	customGang.animation.addByPrefix(
		"idle",
		"dagang",
		24,
		false
	);

	// Loop usando exactamente los frames del JSON original
	customGang.animation.addByIndices(
		"idle-loop",
		"dagang",
		[8, 9, 10, 11, 12, 13, 14, 15],
		"",
		24,
		true
	);

	customGang.animation.play("idle", true);

	gangShader = HSVBlendedShader.xmasInit();
	customGang.shader = gangShader;

	add(customGang);
}

    //CASSET
function createCustomCasset():Void
{
	if (customCasset != null)
		return;

	customCasset = new FunkinSprite(-425, -500);

	customCasset.frames = Paths.getSparrowAtlas(
		"stages/xMassCityMall/cass",
		"shared"
	);
	
	customCasset.scale.set(2.0, 2.0);
customCasset.updateHitbox();


	customCasset.scrollFactor.set(0.975, 0.975);
	customCasset.zIndex = 101;

	// Animación completa usando los frames originales
	customCasset.animation.addByIndices(
		"idle",
		"cass",
		[
			0, 1, 2, 3, 4, 5, 6, 7,
			8, 9, 10, 11, 12, 13, 14
		],
		"",
		24,
		false
	);

	// Loop original de los frames 8 y 9
	customCasset.animation.addByIndices(
		"idle-loop",
		"cass",
		[8, 9],
		"",
		4,
		true
	);

	customCasset.animation.play("idle", true);

	cassetShader = HSVBlendedShader.xmasInit();
	customCasset.shader = cassetShader;

	add(customCasset);
}

    //ZONET
function createCustomZonet():Void
{
	if (customZonet != null)
		return;

	customZonet = new FunkinSprite(175, -450);

	customZonet.frames = Paths.getSparrowAtlas(
		"stages/xMassCityMall/zonet",
		"shared"
	);
	
	customZonet.scale.set(2.0, 2.0);
customZonet.updateHitbox();


	customZonet.scrollFactor.set(0.975, 0.975);
	customZonet.zIndex = 101;

	customZonet.animation.addByPrefix(
		"idle",
		"zonet",
		24,
		false
	);

	customZonet.animation.play("idle", true);

	zonetShader = HSVBlendedShader.xmasInit();
	customZonet.shader = zonetShader;

	add(customZonet);
}

//MEAT BOY
function createCustomMeatBoy():Void
{
	if (customMeatBoy != null)
		return;

	customMeatBoy = new FunkinSprite(1800, 50);

	customMeatBoy.frames = Paths.getSparrowAtlas(
		"stages/xMassCityMall/meatboy",
		"shared"
	);

	customMeatBoy.scrollFactor.set(0.925, 0.925);
	customMeatBoy.zIndex = 100;

	customMeatBoy.animation.addByPrefix(
		"idle",
		"meatbo",
		24,
		false
	);

	customMeatBoy.animation.play("idle", true);

	meatBoyShader = HSVBlendedShader.xmasInit();
	customMeatBoy.shader = meatBoyShader;

	add(customMeatBoy);
}

   //TREE CRUSHERS
   function createCustomTreeCrushers():Void
{
	if (customTreeCrushers != null)
		return;

	customTreeCrushers = new FunkinSprite(-360, -900);

	customTreeCrushers.frames = Paths.getSparrowAtlas(
		"stages/xMassCityMall/tree_crushers",
		"shared"
	);

	customTreeCrushers.scrollFactor.set(0.885, 0.885);
	customTreeCrushers.zIndex = 84;

	customTreeCrushers.animation.addByPrefix(
		"idle",
		"tree dumbs",
		24,
		false
	);

	customTreeCrushers.animation.play("idle", true);

	treeCrushersShader = HSVBlendedShader.xmasInit();
	customTreeCrushers.shader = treeCrushersShader;

	add(customTreeCrushers);
}

   //ALIEN SHIP
   function createCustomAlienShip():Void
{
	if (customAlienShip != null)
		return;

	customAlienShip = new FunkinSprite(-650, -1275);

	customAlienShip.loadGraphic(
		Paths.image(
			"stages/xMassCityMall/alienship",
			"shared"
		)
	);

	customAlienShip.scrollFactor.set(0.875, 0.875);
	customAlienShip.zIndex = 83;

	alienShipShader = HSVBlendedShader.xmasInit();
	customAlienShip.shader = alienShipShader;

	add(customAlienShip);
}

function createCustomBlends():Void
{
	// --------------------------------------------------------
	// BLEND 1
	// --------------------------------------------------------

	if (customBlend1 == null)
	{
		customBlend1 = new FunkinSprite(-2150, -1240);

		customBlend1.loadGraphic(
			Paths.image(
				"stages/xMassCityMall/from_the_fog",
				"shared"
			)
		);
		
		customBlend1.scale.set(2.2, 2.2);
customBlend1.updateHitbox();


		customBlend1.scrollFactor.set(0.825, 0.825);
		customBlend1.alpha = 0.87;
		customBlend1.blend = BlendMode.OVERLAY;
		customBlend1.zIndex = 80;

		blend1Shader = HSVBlendedShader.xmasInit();
		customBlend1.shader = blend1Shader;

		add(customBlend1);
	}
	
	if (customBlend2 == null)
	{
		customBlend2 = new FunkinSprite(-2150, -1240);

		customBlend2.loadGraphic(
			Paths.image(
				"stages/xMassCityMall/from_the_fog",
				"shared"
			)
		);
		
		customBlend2.scale.set(2.2, 2.2);
customBlend2.updateHitbox();

		customBlend2.scrollFactor.set(0.825, 0.825);
		customBlend2.alpha = 0.67;
		customBlend2.blend = BlendMode.OVERLAY;
		customBlend2.zIndex = 81;

		blend2Shader = HSVBlendedShader.xmasInit();
		customBlend2.shader = blend2Shader;

		add(customBlend2);
	}
}

	function addRailBopper(name:String):Void
	{
		var prop = getNamedProp(name);

		if (prop != null)
			railBoppers.push(prop);
	}

	override function stageFullConstruct():Void
	{
		super.stageFullConstruct();

		var bf = getBoyfriend();
		if (bf != null)
		{
			bfDarkShader = HSVBlendedShader.xmasInit();
			bf.shader = bfDarkShader;
		}

		var gf = getGirlfriend();
		if (gf != null)
		{
			gfDarkShader = HSVBlendedShader.xmasInit();
			gf.shader = gfDarkShader;
		}

		var dad = getDad();
		if (dad != null && dad.characterId == "parents-christmas")
		{
			dadDarkShader = HSVBlendedShader.xmasInit();
			dad.shader = dadDarkShader;
		}

		if (customSanta != null)
		{
			if (santaShader == null)
				santaShader = HSVBlendedShader.xmasInit();

			customSanta.shader = santaShader;
		}

		if (customSnowFG != null)
		{
			if (snowFGShader == null)
				snowFGShader = HSVBlendedShader.xmasInit();

			customSnowFG.shader = snowFGShader;
		}

		if (customSnowFGrad != null)
		{
			if (snowFGradShader == null)
				snowFGradShader = HSVBlendedShader.xmasInit();

			customSnowFGrad.shader = snowFGradShader;
		}

		if (customSnowman != null)
		{
			if (snowmanShader == null)
				snowmanShader = HSVBlendedShader.xmasInit();

			customSnowman.shader = snowmanShader;
		}
		
		if (customBandageGirl != null)
{
	if (bandageGirlShader == null)
		bandageGirlShader = HSVBlendedShader.xmasInit();

	customBandageGirl.shader = bandageGirlShader;
}

if (customCops != null)
{
	if (copsShader == null)
		copsShader = HSVBlendedShader.xmasInit();

	customCops.shader = copsShader;
}

if (customCoolbud != null)
{
	if (coolbudShader == null)
		coolbudShader = HSVBlendedShader.xmasInit();

	customCoolbud.shader = coolbudShader;
}

if (customGang != null)
{
	if (gangShader == null)
		gangShader = HSVBlendedShader.xmasInit();

	customGang.shader = gangShader;
}

if (customCasset != null)
{
	if (cassetShader == null)
		cassetShader = HSVBlendedShader.xmasInit();

	customCasset.shader = cassetShader;
}

if (customZonet != null)
{
	if (zonetShader == null)
		zonetShader = HSVBlendedShader.xmasInit();

	customZonet.shader = zonetShader;
}

if (customMeatBoy != null)
{
	if (meatBoyShader == null)
		meatBoyShader = HSVBlendedShader.xmasInit();

	customMeatBoy.shader = meatBoyShader;
}

if (customTreeCrushers != null)
{
	if (treeCrushersShader == null)
		treeCrushersShader = HSVBlendedShader.xmasInit();

	customTreeCrushers.shader = treeCrushersShader;
}

if (customAlienShip != null)
{
	if (alienShipShader == null)
		alienShipShader = HSVBlendedShader.xmasInit();

	customAlienShip.shader = alienShipShader;
}

// Blend 1
if (customBlend1 != null)
{
	if (blend1Shader == null)
		blend1Shader = HSVBlendedShader.xmasInit();

	customBlend1.shader = blend1Shader;
}

// Blend 2
if (customBlend2 != null)
{
	if (blend2Shader == null)
		blend2Shader = HSVBlendedShader.xmasInit();

	customBlend2.shader = blend2Shader;
}
	}

	override function onBeatHit(event)
{
	super.onBeatHit(event);

	if (event.beat % boppersIdle == 0)
		boppersBop();
		
		// Santa sigue el ritmo
if (customSanta != null)
{
	if (event.beat % 2 == 0)
		customSanta.animation.play("idle", true);
}

// Bandage Girl al ritmo
if (customBandageGirl != null)
{
	if (event.beat % 2 == 0)
		customBandageGirl.animation.play("idle", true);
}

// Coolbud al ritmo
if (customCoolbud != null)
{
	if (event.beat % 2 == 0)
		customCoolbud.animation.play("idle", true);
}

// Gang al ritmo
if (customGang != null)
{
	if (event.beat % 2 == 0)
	{
		customGang.animation.play("idle", true);

		new FlxTimer().start(8 / 24, function(_)
		{
			if (customGang != null &&
				customGang.animation.curAnim != null &&
				customGang.animation.curAnim.name == "idle")
			{
				customGang.animation.play("idle-loop", true);
			}
		});
	}
}

// Casset al ritmo
if (customCasset != null)
{
	if (event.beat % 2 == 0)
	{
		customCasset.animation.play("idle", true);

		new FlxTimer().start(8 / 24, function(_)
		{
			if (customCasset != null &&
				customCasset.animation.curAnim != null &&
				customCasset.animation.curAnim.name == "idle")
			{
				customCasset.animation.play("idle-loop", true);
			}
		});
	}
}

// Zonet al ritmo
if (customZonet != null)
{
	if (event.beat % 2 == 0)
		customZonet.animation.play("idle", true);
}

// Meat Boy al ritmo
if (customMeatBoy != null)
{
	if (event.beat % 2 == 0)
		customMeatBoy.animation.play("idle", true);
}

// Tree Crushers al ritmo
if (customTreeCrushers != null)
{
	if (event.beat % 2 == 0)
		customTreeCrushers.animation.play("idle", true);
}

	if (customCops != null)
	{
		var anim = customCops.animation.curAnim;

		// Solo bailar si no está haciendo laugh o throw.
		if (anim == null || (anim.name != "laugh" && anim.name != "throw"))
		{
		if (event.beat % 2 == 0)
{
	if (customCops.animation.curAnim == null ||
		customCops.animation.curAnim.name == "danceLeft")
	{
		customCops.animation.play("danceRight", true);
	}
	else
	{
		customCops.animation.play("danceLeft", true);
	}
}
		}
	}
}

function copsDance():Void
{
	if (customCops == null)
		return;

	if (customCops.animation.curAnim != null &&
		customCops.animation.curAnim.name == "laugh")
	{
		customCops.animation.play("danceLeft", true);
	}
}

	function boppersBop():Void
	{
		for (prop in railBoppers)
		{
			if (prop == null)
				continue;

			var baseY:Float = prop.y;

			prop.y = baseY + 10;

			new FlxTimer().start(2 / 24, function(_)
			{
				if (prop != null)
					prop.y = baseY + 7.5;
			});

			new FlxTimer().start(4 / 24, function(_)
			{
				if (prop != null)
					prop.y = baseY + 2.5;
			});

			new FlxTimer().start(6 / 24, function(_)
			{
				if (prop != null)
					prop.y = baseY;
			});
		}
	}

	override function onNoteHit(event)
	{
		super.onNoteHit(event);

		if (event.isComboBreak)
			makeCrowdLaugh();
	}

	override function onNoteGhostMiss(event)
	{
		super.onNoteGhostMiss(event);
		makeCrowdLaugh();
	}

	override function onNoteMiss(event)
	{
		if (event.eventCanceled)
			return;

		if (event.note == null)
			return;

		if (event.note.kind == "solotime")
			return;

		super.onNoteMiss(event);
		makeCrowdLaugh();
	}

	
	function makeCrowdLaugh():Void
{
	if (customCops == null)
		return;

	var anim = customCops.animation.curAnim;

	if (anim != null && anim.name == "laugh")
		return;

	customCops.animation.play("laugh", true);

	new FlxTimer().start(1.0, function(_)
	{
		if (customCops != null &&
			customCops.animation.curAnim != null &&
			customCops.animation.curAnim.name == "laugh")
		{
			copsDance();
		}
	});
}

	override function onDestroy(event)
	{
		railBoppers = [];

		if (customSanta != null)
		{
			customSanta.destroy();
			customSanta = null;
		}

		if (customSnowFG != null)
		{
			customSnowFG.destroy();
			customSnowFG = null;
		}

		if (customSnowFGrad != null)
		{
			customSnowFGrad.destroy();
			customSnowFGrad = null;
		}

		if (customSnowman != null)
		{
			customSnowman.destroy();
			customSnowman = null;
		}
		
		if (customBandageGirl != null)
{
	customBandageGirl.destroy();
	customBandageGirl = null;
}

if (customCops != null)
{
	customCops.destroy();
	customCops = null;
}

if (customCoolbud != null)
{
	customCoolbud.destroy();
	customCoolbud = null;
}

if (customGang != null)
{
	customGang.destroy();
	customGang = null;
}

if (customCasset != null)
{
	customCasset.destroy();
	customCasset = null;
}

if (customZonet != null)
{
	customZonet.destroy();
	customZonet = null;
}

if (customMeatBoy != null)
{
	customMeatBoy.destroy();
	customMeatBoy = null;
}

if (customTreeCrushers != null)
{
	customTreeCrushers.destroy();
	customTreeCrushers = null;
}

if (customAlienShip != null)
{
	customAlienShip.destroy();
	customAlienShip = null;
}

if (customBlend1 != null)
{
	customBlend1.destroy();
	customBlend1 = null;
}

if (customBlend2 != null)
{
	customBlend2.destroy();
	customBlend2 = null;
}

		bfDarkShader = null;
		gfDarkShader = null;
		dadDarkShader = null;

		santaShader = null;
		snowFGShader = null;
		snowFGradShader = null;
		snowmanShader = null;
        bandageGirlShader = null;
        copsShader = null;
        coolbudShader = null;
        gangShader = null;
        cassetShader = null;
        zonetShader = null;
        meatBoyShader = null;
        treeCrushersShader = null;
        alienShipShader = null;
        blend1Shader = null;
        blend2Shader = null;
		super.onDestroy(event);
	}
}