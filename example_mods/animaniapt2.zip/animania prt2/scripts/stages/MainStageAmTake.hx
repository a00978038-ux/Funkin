import flixel.FlxG;
import flixel.FlxSprite;
import flixel.math.FlxMath;
import flixel.tweens.FlxTween;
import flixel.tweens.FlxEase;
import flixel.util.FlxColor;

import funkin.Paths;
import funkin.Conductor;
import funkin.play.PlayState;
import funkin.play.PauseSubState;
import funkin.play.stage.ScriptedStage;
import funkin.graphics.FunkinSprite;


class MainStageAmTake extends ScriptedStage
{
	function new()
	{
		super('mainStageAmTake');
	}


	override function onCreate(e)
	{
		super.onCreate(e);

		PauseSubState.musicSuffix = '-amtake1';
	}


	var spotlighShits = [];

	var crowd1:FunkinSprite;
	var crowd2:FunkinSprite;
	var crowd3:FunkinSprite;

	var smokes = [];



function buildStage()
{
		spotlighShits = [];

		super.buildStage();




		createAllSpotlights();


		setLight(true);


		setSmokeVisible(false);


		smokes = [];

		for (prop in namedProps)
		{
			if (prop.name.indexOf("smoke-") != -1)
			{
				smokes.push(prop);
			}
		}


		getNamedProp("vin1").alpha = 1;
		getNamedProp("vin2").alpha = 0;


		if (!Preferences.lowQuality)
		{
			// CROWD 1
			crowd1 = new FunkinSprite(
				-1050,
				770,
				Paths.animateAtlas(
					"stages/mainStageAmTake/crowd",
					"shared"
				)
			);

			// En Mobile no llamamos addByFrameLabel() desde HScript.
			// hasAnimation() detecta el frame label del Animate Atlas y lo registra internamente.
			crowd1.hasAnimation("croud1");
			crowd1.anim.play("croud1", true);

			crowd1.scrollFactor.set(1.1, 1.1);
			crowd1.zIndex = 80;
			crowd1.useRenderTexture = true;
			crowd1.applyStageMatrix = true;

			add(crowd1);


			// CROWD 2
			crowd2 = new FunkinSprite(
				-1100,
				750,
				Paths.animateAtlas(
					"stages/mainStageAmTake/crowd",
					"shared"
				)
			);

			// Los nombres son frame labels reales del Animation.json.
			crowd2.hasAnimation("croud2 bop");
			crowd2.hasAnimation("croud2 dance");
			crowd2.anim.play("croud2 bop", true);

			crowd2.scrollFactor.set(1.2, 1.2);
			crowd2.zIndex = 200;
			crowd2.color = 0xFFAAA9B2;

			namedProps.set("crowdA", crowd2);

			crowd2.useRenderTexture = true;
			crowd2.applyStageMatrix = true;

			add(crowd2);


			// CROWD 3
			crowd3 = new FunkinSprite(
				-1050,
				600,
				Paths.animateAtlas(
					"stages/mainStageAmTake/crowd",
					"shared"
				)
			);

			crowd3.hasAnimation("croud3");
			crowd3.anim.play("croud3", true);

			crowd3.scrollFactor.set(1.3, 1.3);
			crowd3.zIndex = 205;
			crowd3.color = 0xFFA29EAF;

			crowd3.useRenderTexture = true;
			crowd3.applyStageMatrix = true;

			add(crowd3);
		}


		refresh();


	}








	function createAllSpotlights()
	{
		for (prop in namedProps)
		{
			if (prop.name.indexOf("stoplight") != -1)
			{
				var uhuh = new SpotlightAccesories(
					"asss",
					prop
				);

				if (uhuh != null)
				{
					spotlighShits.push(uhuh);

					// Anillo del spotlight.
					add(uhuh);

					// Rayo del spotlight.
					if (uhuh.ray != null)
					{
						add(uhuh.ray);
					}
				}
			}
		}
	}


	function onUpdate(event)
	{
		super.onUpdate(event);




		var floorLightsBlendy =
			getNamedProp("floorLightsBlendy");

		if (floorLightsBlendy != null
			&& floorLightsBlendy.alpha > 0)
		{
			floorLightsBlendy.alpha -=
				(Conductor.instance.beatLengthMs / 1000)
				* FlxG.elapsed
				* 2.2;
		}


		var floorLights =
			getNamedProp("floorLights");

		if (floorLights != null
			&& floorLights.alpha > 0)
		{
			floorLights.alpha -=
				(Conductor.instance.beatLengthMs / 1000)
				* FlxG.elapsed
				* 2.2;
		}


		// MOBILE: la luz y el reflector/rayo comparten el mismo alpha.
		if (spotlighShits.length > 0 && !itsSoloTime)
		{
			var alph:Float = 0;

			if (spotlighShits[0] != null)
				alph = spotlighShits[0].alpha;

			if (alph > 0)
			{
				alph -=
					(Conductor.instance.beatLengthMs / 1000)
					* FlxG.elapsed
					* 3.3;

				if (alph < 0) alph = 0;

				for (s in spotlighShits)
				{
					if (s != null)
					{
						s.alpha = alph;

						if (s.targetSpotlight != null)
							s.targetSpotlight.alpha = alph;

						if (s.ray != null)
							s.ray.alpha = alph;
					}
				}

			}
		}

		// Fuerza la sincronización de posición/ángulo/color cada frame.
		for (s in spotlighShits)
		{
			if (s != null)
				s.syncWithTarget();
		}


	}



	var itsSoloTime:Bool = false;

	var crowd2Bop:Bool = false;
	var crowd2Right:Bool = false;



	function onBeatHit(event:SongTimeScriptEvent)
	{
		super.onBeatHit(event);


		if (
			(event.beat > 95
			&& event.beat < 129
			&& PlayState.instance.currentSong.id == "bopeebo-amtake")
			||
			(event.beat > 145
			&& event.beat < 175
			&& PlayState.instance.currentSong.id == "fresh-amtake")
		)
		{
			crowd2Bop = true;
		}
		else
		{
			crowd2Bop = false;
		}


		if (allowedColorChange > 0
			&& event.beat % allowedColorChange == 0)
		{
			setLight();
		}




		if (!Preferences.lowQuality)
		{
			if (crowd1 != null)
			{
				FlxTween.cancelTweensOf(crowd1);

				crowd1.y = 780;

				FlxTween.tween(
					crowd1,
					{y: crowd1.y - 10},
					.5,
					{ease: FlxEase.backOut}
				);
			}


			if (crowd1 != null)
			{
				crowd1.anim.play("croud1", true);
			}


			if (crowd2 != null)
			{
				if (crowd2Bop)
					crowd2.anim.play("croud2 dance", true);
				else
					crowd2.anim.play("croud2 bop", true);
			}


			if (crowd3 != null)
			{
				crowd3.anim.play("croud3", true);
			}


			crowd2Right = !crowd2Right;
		}


		if (PlayState.instance.currentSong.id == "fresh-amtake")
		{
			if (event.beat == 48)
			{
				itsSoloTime = true;

				projectDad();

			}


			if (event.beat == 56)
			{
				itsSoloTime = true;

				setLight();

			}


			if (event.beat == 65)
			{
				itsSoloTime = true;
				projectGF();
			}


			if (event.beat == 72)
			{
				itsSoloTime = true;

				putProjectors(
					0xFF99FFFF,
					.45,
					.7
				);

			}


			if (event.beat >= 74 && event.beat <= 76)
			{
				itsSoloTime = false;

				putProjectors(
					0xFF99FFFF,
					.45,
					FlxG.random.float(.4, .8)
				);


			}


			if (event.beat == 80)
			{
				itsSoloTime = false;

				for (p in spotlighShits)
				{
					if (p != null
						&& p.targetSpotlight != null)
					{
						p.targetSpotlight.animation.play(
							"off",
							true
						);
					}
				}
			}


			if (event.beat == 110)
			{

			}


			if (event.beat == 112)
			{
				itsSoloTime = true;

				setLight(
					false,
					FlxColor.WHITE
				);

				for (smoke in smokes)
				{
					if (smoke != null)
						smoke.alpha = 1;
				}

			}


			if (event.beat == 144)
			{

				itsSoloTime = false;

				allowedColorChange = 1;

				setLight();


				for (smoke in smokes)
				{
					if (smoke != null)
					{
						FlxTween.tween(
							smoke,
							{alpha: 0},
							6,
							{
								ease:
									FlxEase.smootherStepInOut
							}
						);
					}
				}

			}


			if (event.beat == 176)
			{
				itsSoloTime = false;

				allowedColorChange = 2;

				setLight();
			}


			if (event.beat == 206)
			{
				itsSoloTime = false;

				setLight(true);
			}


			if (event.beat == 208)
			{
				itsSoloTime = true;

				allowedColorChange = 0;

				setLight(
					false,
					FlxColor.WHITE
				);


				var vin2 = getNamedProp("vin2");


				if (vin2 != null)
				{
					FlxTween.tween(
						vin2,
						{alpha: .5},
						3,
						{
							ease:
								FlxEase.cubeOut
						}
					);
				}

			}
		}
	}


	var lightColors = [
		FlxColor.WHITE,
		0xFF00F9FF,
		0xFF2BFF00,
		0xFFFF4F00,
		0xFFCC00FF,
		0xFFFF0064
	];


	var currentLightsColor = null;
	var nextLightColorIndex:Int = 1;

	var allowedColorChange:Int = 0;


	public function setLight(
		?turnOff:Bool = false,
		?forceColor:FlxColor
	)
	{
		if (turnOff)
		{
			allowedColorChange = 0;

			getNamedProp("floorLightBged")
				.animation.play("off", true);

			getNamedProp("floorLights").alpha = .00001;

			getNamedProp("floorLightsBlendy").alpha = .00001;


			for (p in spotlighShits)
			{
				if (p != null)
				{
					p.alpha = 0;

					if (p.targetSpotlight != null)
					{
						p.targetSpotlight.animation.play("off", true);
					}
				}
			}



			return;
		}


		if (forceColor == null)
		{
			currentLightsColor = lightColors[nextLightColorIndex];
			nextLightColorIndex++;

			if (nextLightColorIndex >= lightColors.length)
				nextLightColorIndex = 1;
		}
		else
		{
			currentLightsColor = forceColor;
		}


		// Aplicar el color directamente a todos los sprites de luz.
		// Esto evita depender del comportamiento de tint de la versión PC.
		var floorLights = getNamedProp("floorLights");
		if (floorLights != null)
			floorLights.color = currentLightsColor;

		var floorLightsBlendy = getNamedProp("floorLightsBlendy");
		if (floorLightsBlendy != null)
			floorLightsBlendy.color = currentLightsColor;

		var floorLightBged = getNamedProp("floorLightBged");
		if (floorLightBged != null)
			floorLightBged.color = currentLightsColor;

		for (spot in spotlighShits)
		{
			if (spot == null)
				continue;

			spot.color = currentLightsColor;

			if (spot.targetSpotlight != null)
				spot.targetSpotlight.color = currentLightsColor;
		}

		putProjectors(currentLightsColor);


		if (itsSoloTime)
			return;


		for (p in spotlighShits)
		{
			if (p != null)
			{
				p.alpha = .9;

				if (p.targetSpotlight != null)
				{
					p.targetSpotlight.animation.play("on", true);
				}
			}
		}


		getNamedProp("floorLightBged")
			.animation.play("on", true);


		getNamedProp("floorLights").alpha = .9;
		getNamedProp("floorLights").color =
			currentLightsColor;

		getNamedProp("floorLightsBlendy").alpha = .9;
		getNamedProp("floorLightsBlendy").color =
			currentLightsColor;


	}



	function putProjectors(
		currentLightsColor,
		?coolAlpha:Float = .45,
		?ass:Float = 1
	)
	{
		if (spotlighShits.length < 4)
			return;


		if (!itsSoloTime)
		{
			for (spot in spotlighShits)
			{
				if (spot == null
					|| spot.targetSpotlight == null)
					continue;


				spot.alpha = ass;
				spot.color = currentLightsColor;
				spot.targetSpotlight.color = currentLightsColor;


				spot.targetSpotlight.animation.play(
					"on",
					true
				);


				FlxTween.tween(
					spot.targetSpotlight,
					{
						angle:
							FlxG.random.float(
								-18,
								18
							)
					},
					FlxG.random.float(
						.5,
						1.5
					) * .2,
					{
						ease:
							FlxEase.circOut
					}
				);
			}


		}
		else
		{
			currentLightsColor = FlxColor.WHITE;


			for (p in spotlighShits)
			{
				if (p != null
					&& p.targetSpotlight != null)
				{
					p.targetSpotlight.animation.play(
						"on",
						true
					);
				}
			}


			if (spotlighShits[1] != null)
			{
				spotlighShits[1].alpha = 0;

				if (spotlighShits[1].targetSpotlight != null)
					spotlighShits[1].targetSpotlight.angle = 0;
			}


			if (spotlighShits[0] != null)
			{
				if (spotlighShits[0].targetSpotlight != null)
				{
					FlxTween.tween(
						spotlighShits[0].targetSpotlight,
						{angle: -35},
						FlxG.random.float(.25, .5),
						{ease: FlxEase.circOut}
					);
				}

				spotlighShits[0].alpha = coolAlpha;
				spotlighShits[0].color = 0xFF99FFFF;
			}


			if (spotlighShits[2] != null)
			{
				if (spotlighShits[2].targetSpotlight != null)
				{
					FlxTween.tween(
						spotlighShits[2].targetSpotlight,
						{angle: 15},
						FlxG.random.float(.25, .5),
						{ease: FlxEase.circOut}
					);
				}

				spotlighShits[2].alpha = coolAlpha;
				spotlighShits[2].color = 0xFF99FFFF;
			}


			if (spotlighShits[3] != null)
			{
				if (spotlighShits[3].targetSpotlight != null)
				{
					FlxTween.tween(
						spotlighShits[3].targetSpotlight,
						{angle: -20},
						FlxG.random.float(.25, .5),
						{ease: FlxEase.circOut}
					);
				}

				spotlighShits[3].alpha = coolAlpha;
				spotlighShits[3].color = 0xFF99FFFF;
			}


		}
	}


	function projectDad()
	{
		if (spotlighShits.length < 4)
			return;


		for (p in spotlighShits)
		{
			if (p != null
				&& p.targetSpotlight != null)
			{
				p.targetSpotlight.animation.play(
					"on",
					true
				);
			}
		}


		if (spotlighShits[0] != null)
		{
			spotlighShits[0].alpha = .45;
			spotlighShits[0].color = 0xFF99FFFF;

			if (spotlighShits[0].targetSpotlight != null)
			{
				FlxTween.tween(
					spotlighShits[0].targetSpotlight,
					{angle: 15},
					FlxG.random.float(.25, .5),
					{ease: FlxEase.circOut}
				);
			}
		}


		if (spotlighShits[1] != null)
		{
			spotlighShits[1].alpha = .45;
			spotlighShits[1].color = 0xFF99FFFF;

			if (spotlighShits[1].targetSpotlight != null)
			{
				FlxTween.tween(
					spotlighShits[1].targetSpotlight,
					{angle: -20},
					FlxG.random.float(.25, .5),
					{ease: FlxEase.circOut}
				);
			}
		}


		if (spotlighShits[3] != null)
		{
			spotlighShits[3].alpha = .45;
			spotlighShits[3].color = 0xFF99FFFF;

			if (spotlighShits[3].targetSpotlight != null)
			{
				FlxTween.tween(
					spotlighShits[3].targetSpotlight,
					{angle: 40},
					FlxG.random.float(.25, .5),
					{ease: FlxEase.circOut}
				);
			}
		}


		if (spotlighShits[2] != null)
		{
			if (spotlighShits[2].targetSpotlight != null)
			{
				spotlighShits[2].targetSpotlight.animation.play(
					"off",
					true
				);
			}

			spotlighShits[2].alpha = 0;
		}


	}


	function projectGF()
	{
		if (spotlighShits.length < 4)
			return;


		for (p in spotlighShits)
		{
			if (p != null
				&& p.targetSpotlight != null)
			{
				p.targetSpotlight.animation.play(
					"on",
					true
				);
			}
		}


		for (i in 0...4)
		{
			if (spotlighShits[i] != null)
			{
				spotlighShits[i].alpha = .3;
				spotlighShits[i].color = 0xFF99FFFF;
			}
		}


		if (spotlighShits[0] != null
			&& spotlighShits[0].targetSpotlight != null)
		{
			FlxTween.tween(
				spotlighShits[0].targetSpotlight,
				{angle: -25},
				FlxG.random.float(.25, .5),
				{ease: FlxEase.circOut}
			);
		}


		if (spotlighShits[1] != null
			&& spotlighShits[1].targetSpotlight != null)
		{
			FlxTween.tween(
				spotlighShits[1].targetSpotlight,
				{angle: -20},
				FlxG.random.float(.25, .5),
				{ease: FlxEase.circOut}
			);
		}


		if (spotlighShits[3] != null
			&& spotlighShits[3].targetSpotlight != null)
		{
			FlxTween.tween(
				spotlighShits[3].targetSpotlight,
				{angle: 25},
				FlxG.random.float(.25, .5),
				{ease: FlxEase.circOut}
			);
		}


		if (spotlighShits[2] != null
			&& spotlighShits[2].targetSpotlight != null)
		{
			FlxTween.tween(
				spotlighShits[2].targetSpotlight,
				{angle: 15},
				FlxG.random.float(.25, .5),
				{ease: FlxEase.circOut}
			);
		}


	}


	function setSmokeVisible(how:Bool)
	{
		for (prop in namedProps)
		{
			if (prop.name.indexOf("smoke-") != -1)
			{
				prop.alpha = how ? 1 : .00001;
			}
		}
	}


public override function destroy():Void
{

	PauseSubState.musicSuffix = "";

	super.destroy();
}


	override function onSongEvent(event)
	{
		super.onSongEvent(event);

		var eventData = event.eventData;


		switch (eventData.eventKind)
		{
			case "Blank":
				trace(eventData.value.value1);

				if (eventData.value.value1 == "true")
					trace("GAY SEX");

				trace(eventData.value.value2);
				trace(eventData.value.value3);
				trace(eventData.value.value4);
				trace(eventData.value.value5);
		}
	}
}



class SpotlightAccesories extends FunkinSprite
{
	public var targetSpotlight:FunkinSprite = null;

	// Rayo independiente.
	public var ray:FunkinSprite = null;


	public function new(ass, prop)
	{
		super(prop.x, prop.y);

		targetSpotlight = prop;


		if (prop.scrollFactor != null)
		{
			scrollFactor.set(
				prop.scrollFactor.x,
				prop.scrollFactor.y
			);
		}


		this.zIndex = prop.zIndex + 1;


		// =====================================================
		// ANILLO
		// =====================================================

		frames = Paths.getSparrowAtlas(
			"stages/mainStageAmTake/spotlight",
			"shared"
		);


		animation.addByPrefix(
			"y",
			"spotlight ring",
			1,
			true
		);


		animation.play(
			"y",
			true
		);


		updateHitbox();


		// =====================================================
		// RAYO
		// =====================================================

		ray = new FunkinSprite(
			prop.x,
			prop.y
		);


		ray.frames = Paths.getSparrowAtlas(
			"stages/mainStageAmTake/spotlight",
			"shared"
		);


		ray.animation.addByPrefix(
			"ray",
			"spotlight ray",
			1,
			true
		);


		ray.animation.play(
			"ray",
			true
		);


		ray.scrollFactor.set(
			prop.scrollFactor.x,
			prop.scrollFactor.y
		);


		ray.zIndex = prop.zIndex;


		ray.alpha = 1;


		ray.applyStageMatrix = true;


		// El rayo se coloca detrás del anillo.
		// No usamos BlendMode porporque Mobile da error.


		updateRay();
	}


	public function syncWithTarget()
	{
		if (targetSpotlight == null)
			return;

		// El prop original manda posición y ángulo.
		x = targetSpotlight.x;
		y = targetSpotlight.y;
		angle = targetSpotlight.angle;

		// MOBILE: mantener luz y reflector unidos también en alpha.
		targetSpotlight.alpha = alpha;

		// El accesorio comparte posición/ángulo/color, pero no fuerza el alpha del reflector.
		targetSpotlight.color = color;

		if (ray != null)
		{
			ray.x = targetSpotlight.x;
			ray.y = targetSpotlight.y;
			ray.angle = targetSpotlight.angle;
			ray.alpha = alpha;
			ray.color = color;
		}
	}


	function updateRay()
	{
		syncWithTarget();
	}


	override function update(elapsed)
	{
		super.update(elapsed);

		if (targetSpotlight == null)
			return;


		syncWithTarget();
	}
}