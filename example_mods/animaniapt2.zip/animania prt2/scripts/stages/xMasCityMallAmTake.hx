import flixel.FlxG;
import flixel.FlxSprite;
import flixel.util.FlxTimer;

import funkin.graphics.FunkinSprite;
import funkin.play.PlayState;
import funkin.play.PauseSubState;
import funkin.play.stage.ScriptedStage;

class XMasCityMallAmTakeStage extends ScriptedStage
{
	public function new()
	{
		super('xMasCityMallAmTake');
	}

	// ============================================================
	// Referencias de props
	// ============================================================

	var leftTV:FunkinSprite;
	var rightTV:FunkinSprite;

	var railBoppers:Array<Dynamic> = [];

	// Frecuencia de movimiento de los personajes del rail.
	var boppersIdle:Int = 2;

	// ============================================================
	// CREACIÓN DEL STAGE
	// ============================================================

	override function onCreate(event)
	{
		super.onCreate(event);

		// Mantiene el comportamiento original del AmTake.
		PauseSubState.musicSuffix = '-amtake5';
	}

	override function buildStage()
	{
		super.buildStage();

		railBoppers = [];

		// En lugar de recorrer _data.props (que puede variar entre
		// versiones del engine), buscamos directamente los props
		// definidos en el JSON.
		addRailBopper("rail-guys-bobby");
		addRailBopper("rail-guys-left");
		addRailBopper("rail-guys-miku");
		addRailBopper("rail-guys-monster");
		addRailBopper("rail-guys-right");
		addRailBopper("rail-guys-far");

		// Los televisores originales se omiten en Low Quality.
		if (!Preferences.lowQuality)
		{
			createLeftTV();
			createRightTV();
		}

		refresh();
	}

	function addRailBopper(name:String):Void
	{
		var prop = getNamedProp(name);

		if (prop != null)
			railBoppers.push(prop);
	}

	// ============================================================
	// TV IZQUIERDA
	// ============================================================

	function createLeftTV():Void
	{
		leftTV = new FunkinSprite(-1800, -690);

		leftTV.loadTextureAtlas(
			"stages/xMassCityMall/tvl",
			"shared",
			{cacheOnLoad: true}
		);

		leftTV.zIndex = 70;
		leftTV.scrollFactor.set(0.875, 0.875);
		leftTV.flipX = true;

		leftTV.anim.addByFrameLabel(
			"noise",
			"noise",
			24,
			false
		);

		leftTV.anim.addByFrameLabel("0", "f1", 24);
		leftTV.anim.addByFrameLabel("1", "f2", 24);
		leftTV.anim.addByFrameLabel("2", "f3", 24);
		leftTV.anim.addByFrameLabel("3", "f4", 24);
		leftTV.anim.addByFrameLabel("4", "f5", 24);
		leftTV.anim.addByFrameLabel("5", "f6", 24);

		leftTV.anim.addByFrameLabelIndices(
			"OOGA BOOGA",
			"OOGA BOOGA",
			[0, 0, 0, 0],
			24,
			false
		);

		leftTV.anim.onFinish.add(function(name)
		{
			if (name == "noise")
			{
				if (FlxG.random.bool(15))
					leftTV.anim.play("OOGA BOOGA", true);
				else
					leftTV.anim.play(Std.string(FlxG.random.int(0, 5)), true);
			}
			else if (name == "OOGA BOOGA")
			{
				leftTV.anim.play("noise", true);
			}
		});

		leftTV.anim.play("OOGA BOOGA", true);

		add(leftTV);
	}

	// ============================================================
	// TV DERECHA
	// ============================================================

	function createRightTV():Void
	{
		rightTV = new FunkinSprite(980, -690);

		rightTV.loadTextureAtlas(
			"stages/xMassCityMall/tvr",
			"shared",
			{cacheOnLoad: true}
		);

		rightTV.zIndex = 70;
		rightTV.scrollFactor.set(0.875, 0.875);

		rightTV.anim.addByFrameLabel(
			"noise",
			"noise",
			24,
			false
		);

		rightTV.anim.addByFrameLabel("0", "f1", 24);
		rightTV.anim.addByFrameLabel("1", "f2", 24);
		rightTV.anim.addByFrameLabel("2", "f3", 24);
		rightTV.anim.addByFrameLabel("3", "f4", 24);
		rightTV.anim.addByFrameLabel("4", "f5", 24);
		rightTV.anim.addByFrameLabel("5", "f6", 24);
		rightTV.anim.addByFrameLabel("6", "f7", 24);

		rightTV.anim.onFinish.add(function(name)
		{
			if (name == "noise")
			{
				rightTV.anim.play(
					Std.string(FlxG.random.int(0, 6)),
					true
				);
			}
		});

		rightTV.anim.play("noise", true);

		add(rightTV);
	}

	// ============================================================
	// BEATS
	// ============================================================

	override function onBeatHit(event)
	{
		super.onBeatHit(event);

		if (Preferences.lowQuality)
			return;

		if (leftTV != null && FlxG.random.bool(10))
			leftTV.anim.play("noise", true);

		if (rightTV != null && FlxG.random.bool(10))
			rightTV.anim.play("noise", true);

		if (event.beat % boppersIdle == 0)
			boppersBop();
	}

	// ============================================================
	// MOVIMIENTO DE LOS PERSONAJES DEL RAIL
	// ============================================================

	function boppersBop():Void
	{
		for (prop in railBoppers)
		{
			if (prop == null)
				continue;

			var baseY:Float = prop.y;

			prop.y = baseY + 10;

			new FlxTimer().start(
				2 / 24,
				function(_)
				{
					if (prop != null)
						prop.y = baseY + 7.5;
				}
			);

			new FlxTimer().start(
				4 / 24,
				function(_)
				{
					if (prop != null)
						prop.y = baseY + 2.5;
				}
			);

			new FlxTimer().start(
				6 / 24,
				function(_)
				{
					if (prop != null)
						prop.y = baseY;
				}
			);
		}
	}

	// ============================================================
	// RISAS AL ROMPER EL COMBO
	// ============================================================

	override function onNoteHit(event)
	{
		super.onNoteHit(event);

		if (event.isComboBreak)
			makeCrowdLaugh();
	}

	override function onNoteGhostMiss(event)
	{
		super.onNoteGhostMiss(event);

		makeCrowdLaugh();
	}

	override function onNoteMiss(event)
	{
		// Mantener la excepción original para SoloTime.
		if (event.eventCanceled)
			return;

		if (event.note == null)
			return;

		if (event.note.kind == "solotime")
			return;

		super.onNoteMiss(event);

		makeCrowdLaugh();
	}

	function makeCrowdLaugh():Void
	{
		var cops = getNamedProp("cops");

		if (cops == null)
			return;

		var currentAnim = cops.getCurrentAnimation();

		if (currentAnim == null)
		{
			cops.playAnimation("laugh", true, true);
			return;
		}

		if (currentAnim.indexOf("snowball") == -1)
			cops.playAnimation("laugh", true, true);
	}

	// ============================================================
	// LIMPIEZA
	// ============================================================

	override function onDestroy(event)
	{
		leftTV = null;
		rightTV = null;
		railBoppers = [];

		super.onDestroy(event);
	}
}
