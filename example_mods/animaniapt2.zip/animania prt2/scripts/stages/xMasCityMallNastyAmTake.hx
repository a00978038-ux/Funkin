import flixel.FlxG;
import flixel.tweens.FlxEase;
import flixel.tweens.FlxTween;
import openfl.display.BlendMode;

import funkin.Preferences;
import funkin.Conductor;
import funkin.graphics.FunkinSprite;
import funkin.graphics.adobeanimate.FlxAtlasSprite;
import funkin.graphics.shaders.AdjustColorShader;
import funkin.play.PlayState;
import funkin.play.PauseSubState;
import funkin.play.stage.ScriptedStage;
import funkin.play.character.CharacterType;

class XMasCityHallNastyAmTakeStage extends ScriptedStage
{
	function new()
	{
		super('xMasCityMallNastyAmTake');
	}

	var railBoppers = [];

	function onCountdownStep(e)
	{
		super.onCountdownStep(e);
	}

	function onCountdownStart(e)
	{
		super.onCountdownStart(e);
	}

	function onCountdownEnd(e)
	{
		super.onCountdownEnd(e);
	}

	function update(e)
	{
		super.update(e);
	}

	function onCreate(e)
	{
		super.onCreate(e);

		PauseSubState.musicSuffix = '-amtake5';

		// Estado inicial
		songPos = 0;
		hangersCanMove = false;
		stageWasStarted = false;
	}

	var leftTV;
	var rightTV;

	var colorShader:AdjustColorShader;

	function buildStage()
	{
		super.buildStage();
		
		colorShader = new AdjustColorShader();

colorShader.hue = -10;
colorShader.saturation = -20;
colorShader.contrast = 0;
colorShader.brightness = 0;

		if (!Preferences.lowQuality)
		{
			leftTV = new FunkinSprite(
				-2000,
				-915,
				Paths.animateAtlas('stages/xMassCityMallNasty/TV', 'shared')
			);

			leftTV.anim.play();
			leftTV.zIndex = 75;
			leftTV.flipX = true;
			leftTV.applyStageMatrix = true;
			leftTV.scrollFactor.set(0.8, 0.8);

			leftTV.anim.addByFrameLabel("off", "off", 24);
			leftTV.anim.addByFrameLabel("noise", "noise", 24);
			leftTV.anim.play("off", true);

			add(leftTV);


			rightTV = new FlxAtlasSprite(
				625,
				-915,
				Paths.animateAtlas('stages/xMassCityMallNasty/TV', 'shared')
			);

			rightTV.anim.play();
			rightTV.zIndex = 76;
			rightTV.applyStageMatrix = true;
			rightTV.scrollFactor.set(0.8, 0.8);

			rightTV.anim.addByFrameLabel("off", "off", 24);
			rightTV.anim.addByFrameLabel("noise", "noise", 24);
			rightTV.anim.play("off", true);

			add(rightTV);
		}


		// HANGERS
		hangers = [];

		for (prop in namedProps)
		{
			if (prop.name.indexOf("hang") != -1)
			{
				var originalY:Float = prop.y;

				hangers.push([
					prop,
					FlxG.random.float(.25, 1.5),
					originalY,
					originalY - 750
				]);

				// Posición inicial
				prop.y = originalY - 750;
			}
		}


		// SKULL
		fuckingCoolAndAwesomeSkull = new FunkinSprite(-200, -300);

		fuckingCoolAndAwesomeSkull.zIndex = 116;

		fuckingCoolAndAwesomeSkull.frames =
			Paths.getSparrowAtlas(
				'stages/xMassCityMallNasty/skull',
				'shared'
			);

		fuckingCoolAndAwesomeSkull.animation.addByPrefix(
			"y",
			"skull-troll_gif",
			24,
			false
		);

		fuckingCoolAndAwesomeSkull.scrollFactor.set(.9, .9);
		fuckingCoolAndAwesomeSkull.setGraphicSize(750, 700);
		fuckingCoolAndAwesomeSkull.flipX = true;
		fuckingCoolAndAwesomeSkull.alpha = 0;
		fuckingCoolAndAwesomeSkull.blend = BlendMode.ADD;

		fuckingCoolAndAwesomeSkull.animation.onFinish.add(
			(name:String) ->
			FlxTween.tween(
				fuckingCoolAndAwesomeSkull,
				{alpha: 0.0},
				.35,
				{
					onComplete: _ ->
					{
						fuckingCoolAndAwesomeSkull.kill();
					},
					ease: FlxEase.smootherStepInOut
				}
			)
		);

		add(fuckingCoolAndAwesomeSkull);


		// BG CREEPS
		if (!Preferences.lowQuality)
		{
			bgCreeps = new FunkinSprite(
				-1000,
				-325,
				Paths.animateAtlas(
					'stages/xMassCityMallNasty/bg creeps',
					'shared'
				)
			);

			bgCreeps.zIndex = 114;

			bgCreeps.animation.addBySymbol(
				"snow",
				bgCreeps.getDefaultSymbol(),
				24,
				true
			);

			bgCreeps.animation.play("snow", true);

			bgCreeps.scrollFactor.set(.95, .95);
			bgCreeps.applyStageMatrix = true;

			add(bgCreeps);

			// Posición inicial real
			bgCreeps.y += 500;
		}


		// TENTÁCULOS
		var tentacleLeft = getNamedProp("tentacleLeft");
		var tentacleRight = getNamedProp("tentacleRight");

		if (tentacleLeft != null)
		{
			tentacleLeft.animation.onFinish.add(
				(animName:String) ->
				tentacleLeft.alpha = 0
			);
		}

		if (tentacleRight != null)
		{
			tentacleRight.animation.onFrameChange.add(
				(animName:String, frameNumber:Int, frameIndex:Int) ->
				{
					tentacleRight.offset.x =
						(animName == "tick" ? 0 : 775);
				}
			);

			tentacleRight.animation.onFinish.add(
				(animName:String) ->
				tentacleRight.alpha = 0
			);
		}


		// Restaurar posiciones iniciales
		setInitialPositions();

		refresh();
	}


	var hangers = [];
	var fuckingCoolAndAwesomeSkull;

	var bgCreeps;

	var songPos:Float = 0;

	var hangersCanMove:Bool = false;

	// Detecta si ya comenzó el gameplay
	var stageWasStarted:Bool = false;


	/**
	 * Coloca BG CREEPS y HANGERS
	 * exactamente en sus posiciones iniciales.
	 */
	function setInitialPositions()
	{
		songPos = 0;
		hangersCanMove = false;

		// BG CREEPS
		if (bgCreeps != null)
		{
			FlxTween.cancelTweensOf(bgCreeps);

			bgCreeps.y = 175;
		}


		// HANGERS
		for (hanger in hangers)
		{
			if (hanger == null)
				continue;

			var prop = hanger[0];

			if (prop == null)
				continue;

			FlxTween.cancelTweensOf(prop);

			// hanger[3] = posición inicial antes del -750
			prop.y = hanger[3];
		}
	}


override function stageFullConstruct():Void
{
	songPos = 0;
	stageWasStarted = false;
	hangersCanMove = false;
}
	
	override function addCharacter(character:BaseCharacter, charType:CharacterType):Void
{
	super.addCharacter(character, charType);

	switch (charType)
	{
		case CharacterType.BF:
			character.shader = colorShader;

		default:
	}
}


	function onBeatHit(event)
	{
		super.onBeatHit(event);

		switch (event.beat)
		{
			case 8:

				if (!Preferences.lowQuality)
				{
					if (leftTV != null)
						leftTV.anim.play("noise", true);

					if (rightTV != null)
						rightTV.anim.play("noise", true);
				}


			case 88:

				if (!Preferences.lowQuality)
				{
					if (bgCreeps != null)
					{
						FlxTween.cancelTweensOf(bgCreeps);

						FlxTween.tween(
							bgCreeps,
							{y: -325},
							1.95,
							{
								ease: FlxEase.sineOut
							}
						);
					}


					for (hanger in hangers)
					{
						if (hanger == null)
							continue;

						var prop = hanger[0];

						if (prop == null)
							continue;

						FlxTween.cancelTweensOf(prop);

						FlxTween.tween(
							prop,
							{y: prop.y + 700},
							.85,
							{
								ease: FlxEase.cubeInOut,
								startDelay: FlxG.random.float(0, .75)
							}
						);
					}

					hangersCanMove = true;
				}


			case 148:

				if (fuckingCoolAndAwesomeSkull != null)
				{
					FlxTween.cancelTweensOf(
						fuckingCoolAndAwesomeSkull
					);

					FlxTween.tween(
						fuckingCoolAndAwesomeSkull,
						{alpha: 0.15},
						.15,
						{
							ease: FlxEase.backOut
						}
					);

					fuckingCoolAndAwesomeSkull.animation.play(
						"y",
						true
					);
				}
		}
	}


	function onUpdate(event)
	{
		super.onUpdate(event);

		if (PlayState.instance == null)
			return;


		if (PlayState.instance.isPlayerDying)
			return;


		if (Preferences.lowQuality)
			return;


		/*
			IMPORTANTE:

			Si la canción vuelve al principio,
			restauramos BG CREEPS y HANGERS.

			Esto no depende de Retry ni de un
			evento específico de reinicio.
		*/
		if (Conductor.instance.songPosition <= 0)
		{
			if (stageWasStarted)
			{
				setInitialPositions();

				stageWasStarted = false;
			}

			return;
		}


		// La canción ya comenzó
		stageWasStarted = true;


		// Movimiento de los HANGERS
		if (
			Conductor.instance.currentBeat > 92
			&& hangersCanMove
		)
		{
			songPos += event.elapsed;


			for (hanger in hangers)
			{
				if (hanger == null)
					continue;

				var prop = hanger[0];
				var speed = hanger[1];

				if (prop == null)
					continue;


				// Posición base después del movimiento del beat 88
				var baseY:Float = hanger[3] + 700;

				// Movimiento ondulante
				var wave:Float =
					Math.sin(
						songPos / 1.5 * speed
					) * 40;


				prop.y = baseY + wave;
			}
		}
	}
}