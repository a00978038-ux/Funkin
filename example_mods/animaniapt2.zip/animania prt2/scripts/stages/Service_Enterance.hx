import flixel.addons.display.FlxBackdrop;
import funkin.audio.FunkinSound;
import funkin.play.stage.ScriptedStage;
import funkin.play.PauseSubState;
import funkin.graphics.shaders.AdjustColorShader;
import funkin.play.character.CharacterType;

using StringTools;

class ServiceEnteranceTake extends ScriptedStage
{
	var rainSndAmbience:FunkinSound;
	var carSndAmbience:FunkinSound;

	var carRide1:FunkinSound;
	var carRide2:FunkinSound;

	var timer:Float = 0;

	var carLeftMoving:Bool = false;
	var carRightMoving:Bool = false;

	var carLeftTime:Float = 0;
	var carRightTime:Float = 0;

	var carLeftDuration:Float = 2;
	var carRightDuration:Float = 2;

	var colorShaderBf:AdjustColorShader;
	var colorShaderDad:AdjustColorShader;
	var colorShaderGf:AdjustColorShader;


	/*
	 * =========================================================
	 * BOTTOM OVERLAY
	 * =========================================================
	 */

	var overlayX:Float = -1150;
	var overlayY:Float = 650;

	var overlayExtraScaleX:Float = 1.35;
	var overlayExtraScaleY:Float = 1.35;

	var overlayAlpha:Float = 0.20;


	/*
	 * =========================================================
	 * NIEBLA ORIGINAL DEL STAGE
	 * =========================================================
	 */

	var mist0:FlxBackdrop;
	var mist1:FlxBackdrop;
	var mist2:FlxBackdrop;
	var mist3:FlxBackdrop;
	var mist4:FlxBackdrop;
	var mist5:FlxBackdrop;


	/*
	 * =========================================================
	 * LLUVIA
	 * =========================================================
	 */

	function randomizeRain():Void
	{
		var rain = getNamedProp('rain');

		if (rain == null)
			return;

		if (rain.timeline == null)
			return;

		if (
			rain.timeline.layers == null ||
			rain.timeline.layers.length <= 0
		)
			return;

		var layer = rain.timeline.layers[0];

		if (layer == null)
			return;

		if (
			layer.frames == null ||
			layer.frames.length <= 0
		)
			return;

		var frame = layer.frames[0];

		if (frame == null)
			return;

		if (frame.elements == null)
			return;

		for (el in frame.elements)
		{
			var element = el.toSymbolInstance();

			if (element != null)
			{
				/*
				 * El spritemap original utiliza 5 frames.
				 */
				element.firstFrame =
					FlxG.random.int(0, 4);
			}
		}
	}


	/*
	 * =========================================================
	 * CONSTRUCTOR
	 * =========================================================
	 */

	function new()
	{
		super('serviceEnterance');
	}


	/*
	 * =========================================================
	 * CREATE
	 * =========================================================
	 */

	override function onCreate(e)
	{
		super.onCreate(e);
		PauseSubState.musicSuffix = '-amtake1';

		// Audio de ambiente: se carga y queda en loop durante todo el nivel.
		rainSndAmbience = FunkinSound.load(
			Paths.sound('gameplay/stages/serviceEnterance/rainAmbience'),
			1, true, false, false
		);
		if (rainSndAmbience != null)
		{
			rainSndAmbience.volume = 0.15;
			rainSndAmbience.looped = true;
			rainSndAmbience.play();
		}

		carSndAmbience = FunkinSound.load(
			Paths.sound('gameplay/stages/serviceEnterance/carAmbience'),
			1, true, false, false
		);
		if (carSndAmbience != null)
		{
			carSndAmbience.volume = 0.12;
			carSndAmbience.looped = true;
			carSndAmbience.play();
		}
		resetCars();
	}


	/*
	 * =========================================================
	 * BUILD STAGE
	 * =========================================================
	 */

	function buildStage()
	{
		super.buildStage();

		colorShaderBf = new AdjustColorShader();
		colorShaderDad = new AdjustColorShader();

		colorShaderBf.brightness = 0;
		colorShaderBf.hue = -30;
		colorShaderBf.contrast = 7;
		colorShaderBf.saturation = 0;

		colorShaderDad.brightness = 0;
		colorShaderDad.hue = -30;
		colorShaderDad.contrast = 7;
		colorShaderDad.saturation = 0;

		/*
		 * Las seis nieblas adicionales solamente se crean
		 * cuando no estamos en Low Quality.
		 */
		if (!Preferences.lowQuality)
		{
			createOriginalMist();
		}

		refresh();

		fixBottomOverlay();
	}

	override function addCharacter(character:BaseCharacter, charType:CharacterType):Void
	{
		super.addCharacter(character, charType);

		switch (charType)
		{
			case CharacterType.BF:
				character.shader = colorShaderBf;
			case CharacterType.DAD:
				character.shader = colorShaderDad;
			case CharacterType.GF:
				character.shader = colorShaderGf;
		}
	}


	/*
	 * =========================================================
	 * NIEBLA ORIGINAL
	 * =========================================================
	 */

	function createOriginalMist():Void
	{
		/*
		 * -----------------------------------------------------
		 * MIST 0
		 * -----------------------------------------------------
		 */

		mist0 =
			new FlxBackdrop(
				Paths.image(
					'stages/serviceEnterance/mistMid'
				),
				0x01
			);

		mist0.setPosition(
			-650,
			340
		);

		mist0.scrollFactor.set(
			1.2,
			1.2
		);

		mist0.zIndex = 1000;
		mist0.blend = 0;
		mist0.color = 0xFF5c5c5c;
		mist0.alpha = 0.6;
		mist0.velocity.x = 172;

		add(mist0);


		/*
		 * -----------------------------------------------------
		 * MIST 1
		 * -----------------------------------------------------
		 */

		mist1 =
			new FlxBackdrop(
				Paths.image(
					'stages/serviceEnterance/mistMid'
				),
				0x01
			);

		mist1.setPosition(
			-650,
			305
		);

		mist1.scrollFactor.set(
			1.1,
			1.1
		);

		mist1.zIndex = 1000;
		mist1.blend = 0;
		mist1.color = 0xFF5c5c5c;
		mist1.alpha = 0.6;
		mist1.velocity.x = 150;

		add(mist1);


		/*
		 * -----------------------------------------------------
		 * MIST 2
		 * -----------------------------------------------------
		 */

		mist2 =
			new FlxBackdrop(
				Paths.image(
					'stages/serviceEnterance/mistBack'
				),
				0x01
			);

		mist2.setPosition(
			-650,
			315
		);

		mist2.scrollFactor.set(
			1.2,
			1.2
		);

		mist2.zIndex = 1001;
		mist2.blend = 0;
		mist2.color = 0xFF5c5c5c;
		mist2.alpha = 0.8;
		mist2.velocity.x = -80;

		add(mist2);


		/*
		 * -----------------------------------------------------
		 * MIST 3
		 * -----------------------------------------------------
		 */

		mist3 =
			new FlxBackdrop(
				Paths.image(
					'stages/serviceEnterance/mistMid'
				),
				0x01
			);

		mist3.setPosition(
			-650,
			320
		);

		mist3.scrollFactor.set(
			0.95,
			0.95
		);

		mist3.zIndex = 30;
		mist3.blend = 0;
		mist3.color = 0xFF5c5c5c;
		mist3.alpha = 0.5;
		mist3.velocity.x = -50;

		mist3.scale.set(
			0.8,
			0.8
		);

		add(mist3);


		/*
		 * -----------------------------------------------------
		 * MIST 4
		 * -----------------------------------------------------
		 */

		mist4 =
			new FlxBackdrop(
				Paths.image(
					'stages/serviceEnterance/mistBack'
				),
				0x01
			);

		mist4.setPosition(
			-650,
			-250
		);

		mist4.scrollFactor.set(
			0.8,
			0.8
		);

		mist4.zIndex = 5;
		mist4.blend = 0;
		mist4.color = 0xFF5c5c5c;
		mist4.alpha = 1;
		mist4.velocity.x = 40;

		mist4.scale.set(
			0.7,
			0.7
		);

		add(mist4);


		/*
		 * -----------------------------------------------------
		 * MIST 5
		 * -----------------------------------------------------
		 */

		mist5 =
			new FlxBackdrop(
				Paths.image(
					'stages/serviceEnterance/mistMid'
				),
				0x01
			);

		mist5.setPosition(
			-650,
			-400
		);

		mist5.scrollFactor.set(
			0.5,
			0.5
		);

		mist5.zIndex = 7;
		mist5.blend = 0;
		mist5.color = 0xFF5c5c5c;
		mist5.alpha = 1;
		mist5.velocity.x = 20;

		mist5.scale.set(
			1.1,
			1.1
		);

		add(mist5);
	}


	/*
	 * =========================================================
	 * OVERLAY
	 * =========================================================
	 */

	function fixBottomOverlay():Void
	{
		var overlay =
			getNamedProp('fgOverlay');

		if (overlay == null)
			return;


		var requiredWidth:Float =
			(FlxG.width / 0.46) *
			overlayExtraScaleX;

		var requiredHeight:Float =
			(FlxG.height / 0.46) *
			overlayExtraScaleY;


		if (
			overlay.width > 0 &&
			overlay.height > 0
		)
		{
			var scaleX:Float =
				requiredWidth / overlay.width;

			var scaleY:Float =
				requiredHeight / overlay.height;

			var finalScale:Float =
				Math.max(
					scaleX,
					scaleY
				);

			overlay.scale.set(
				finalScale,
				finalScale
			);
		}


		overlay.updateHitbox();

		overlay.x = overlayX;
		overlay.y = overlayY;

		overlay.alpha = overlayAlpha;
	}


	/*
	 * =========================================================
	 * STAGE FULL CONSTRUCT
	 * =========================================================
	 */

	override function stageFullConstruct():Void
	{
		/*
		 * -----------------------------------------------------
		 * LLUVIA
		 * -----------------------------------------------------
		 */

		randomizeRain();


		/*
		 * Los sonidos de ambiente se reproducen desde onCreate()
		 * para evitar depender de stageFullConstruct() en Mobile.
		 */

		/*
		 * -----------------------------------------------------
		 * SONIDOS DE LOS COCHES
		 * -----------------------------------------------------
		 */

		if (!Preferences.lowQuality)
		{
			carRide1 =
				FunkinSound.load(
					Paths.sound(
						'gameplay/stages/serviceEnterance/car'
					),
					1,
					true,
					false,
					false
				);

			carRide2 =
				FunkinSound.load(
					Paths.sound(
						'gameplay/stages/serviceEnterance/car'
					),
					1,
					true,
					false,
					false
				);


			if (carRide1 != null)
				carRide1.volume = 0;

			if (carRide2 != null)
				carRide2.volume = 0;
		}
	}


	/*
	 * =========================================================
	 * UPDATE
	 * =========================================================
	 */

	function onUpdate(event)
	{
		super.onUpdate(event);

		timer += event.elapsed;


		/*
		 * =====================================================
		 * NIEBLA
		 * =====================================================
		 */

		if (!Preferences.lowQuality)
		{
			if (mist0 != null)
			{
				mist0.y =
					480 +
					(Math.sin(
						timer * 0.35
					) * 70);
			}


			if (mist1 != null)
			{
				mist1.y =
					460 +
					(Math.sin(
						timer * 0.30
					) * 80);
			}


			if (mist2 != null)
			{
				mist2.y =
					476 +
					(Math.sin(
						timer * 0.40
					) * 60);
			}


			if (mist3 != null)
			{
				mist3.y =
					470 +
					(Math.sin(
						timer * 0.30
					) * 70);
			}


			if (mist4 != null)
			{
				mist4.y =
					-120 +
					(Math.sin(
						timer * 0.35
					) * 50);
			}


			if (mist5 != null)
			{
				mist5.y =
					-280 +
					(Math.sin(
						timer * 0.08
					) * 100);
			}
		}


		/*
		 * =====================================================
		 * FG MIST
		 * =====================================================
		 *
		 * No se modifica.
		 */


		/*
		 * =====================================================
		 * OVERLAY
		 * =====================================================
		 */

		var overlay =
			getNamedProp('fgOverlay');

		if (overlay != null)
		{
			overlay.x = overlayX;
			overlay.y = overlayY;
			overlay.alpha = overlayAlpha;
		}


		/*
		 * =====================================================
		 * VENDING LIGHT
		 * =====================================================
		 *
		 * OPTIMIZACIÓN MOBILE:
		 *
		 * Se eliminó completamente el parpadeo dinámico
		 * mediante colorTransform.
		 *
		 * La máquina mantiene la textura del JSON,
		 * pero no se modifica cada frame.
		 *
		 * Esto evita:
		 *
		 * - colorTransform constante
		 * - MathUtil.coolLerp
		 * - cálculos aleatorios
		 * - trabajo adicional de renderizado
		 *
		 * Especialmente importante porque vendingLight
		 * utiliza blend ADD en el JSON.
		 */


		/*
		 * =====================================================
		 * COCHES
		 * =====================================================
		 */

		updateCars(event.elapsed);


		/*
		 * =====================================================
		 * LLUVIA - SONIDO
		 * =====================================================
		 */

		if (rainSndAmbience != null)
		{
			var targetVolume:Float = 0.1;

			if (Preferences.lowQuality)
				targetVolume = 0.5;

			rainSndAmbience.volume =
				Math.min(
					targetVolume,
					rainSndAmbience.volume +
					event.elapsed * 0.1
				);
		}
	}


	/*
	 * =========================================================
	 * COCHES
	 * =========================================================
	 */

	function updateCars(elapsed:Float):Void
	{
		if (Preferences.lowQuality)
			return;


		var cars =
			getNamedProp('phillyCars');

		var cars2 =
			getNamedProp('phillyCars2');


		/*
		 * -----------------------------------------------------
		 * COCHE IZQUIERDO
		 * -----------------------------------------------------
		 */

		if (
			carLeftMoving &&
			cars != null
		)
		{
			carLeftTime += elapsed;

			var progress:Float =
				carLeftTime /
				carLeftDuration;


			if (progress >= 1)
			{
				progress = 1;
				carLeftMoving = false;

				if (carRide1 != null)
					carRide1.stop();
			}


			var smooth:Float =
				progress *
				progress *
				(3 - 2 * progress);


			cars.x =
				-1750 +
				2700 * smooth;

			cars.y =
				550 -
				190 * smooth;

			cars.angle =
				-20 +
				19 * smooth;


			if (carRide1 != null)
			{
				carRide1.setPosition(
					cars.x,
					cars.y
				);
			}
		}


		/*
		 * -----------------------------------------------------
		 * COCHE DERECHO
		 * -----------------------------------------------------
		 */

		if (
			carRightMoving &&
			cars2 != null
		)
		{
			carRightTime += elapsed;

			var progress2:Float =
				carRightTime /
				carRightDuration;


			if (progress2 >= 1)
			{
				progress2 = 1;
				carRightMoving = false;

				if (carRide2 != null)
					carRide2.stop();
			}


			var smooth2:Float =
				progress2 *
				progress2 *
				(3 - 2 * progress2);


			cars2.x =
				950 -
				2700 * smooth2;

			cars2.y =
				360 +
				190 * smooth2;

			cars2.angle =
				-1 -
				19 * smooth2;


			if (carRide2 != null)
			{
				carRide2.setPosition(
					cars2.x,
					cars2.y
				);
			}
		}
	}


	/*
	 * =========================================================
	 * RESET COCHES
	 * =========================================================
	 */

	function resetCars():Void
	{
		var cars =
			getNamedProp('phillyCars');

		var cars2 =
			getNamedProp('phillyCars2');


		carLeftMoving = false;
		carRightMoving = false;

		carLeftTime = 0;
		carRightTime = 0;


		if (cars != null)
		{
			cars.x = -1750;
			cars.y = 550;
			cars.angle = -20;
		}


		if (cars2 != null)
		{
			cars2.x = 950;
			cars2.y = 360;
			cars2.angle = -1;
		}
	}


	/*
	 * =========================================================
	 * COUNTDOWN
	 * =========================================================
	 */

	override function onCountdownStart(event:ScriptEvent)
	{
		super.onCountdownStart(event);

		resetCars();
	}


	/*
	 * =========================================================
	 * COCHE IZQUIERDO
	 * =========================================================
	 */

	function driveCar(sprite:Dynamic):Void
	{
		if (
			Preferences.lowQuality ||
			sprite == null
		)
			return;


		carLeftMoving = true;
		carLeftTime = 0;


		var variant:Int =
			FlxG.random.int(1, 4);


		switch (variant)
		{
			case 1:
				carLeftDuration =
					FlxG.random.float(
						1,
						1.7
					);

				sprite.offset.set(
					0,
					120
				);


			case 2:
				carLeftDuration =
					FlxG.random.float(
						1.6,
						2.4
					);

				sprite.offset.set(
					30,
					65
				);


			case 3:
				carLeftDuration =
					FlxG.random.float(
						1.8,
						2.5
					);

				sprite.offset.set(
					30,
					60
				);


			case 4:
				carLeftDuration =
					FlxG.random.float(
						0.6,
						1.9
					);

				sprite.offset.set(
					10,
					120
				);
		}


		carLeftDuration *= 1.5;


		sprite.animation.play(
			'car' + variant
		);


		sprite.x = -1750;
		sprite.y = 550;
		sprite.angle = -20;


		if (carRide1 != null)
		{
			carRide1.volume = 0.9;
			carRide1.play();
		}
	}


	/*
	 * =========================================================
	 * COCHE DERECHO
	 * =========================================================
	 */

	function driveCarBack(sprite:Dynamic):Void
	{
		if (
			Preferences.lowQuality ||
			sprite == null
		)
			return;


		carRightMoving = true;
		carRightTime = 0;


		var variant:Int =
			FlxG.random.int(1, 4);


		switch (variant)
		{
			case 1:
				carRightDuration =
					FlxG.random.float(
						1,
						1.7
					);

				sprite.offset.set(
					0,
					120
				);


			case 2:
				carRightDuration =
					FlxG.random.float(
						1.6,
						2.4
					);

				sprite.offset.set(
					30,
					65
				);


			case 3:
				carRightDuration =
					FlxG.random.float(
						1.8,
						2.5
					);

				sprite.offset.set(
					30,
					60
				);


			case 4:
				carRightDuration =
					FlxG.random.float(
						0.6,
						1.9
					);

				sprite.offset.set(
					10,
					120
				);
		}


		carRightDuration *= 1.5;


		sprite.animation.play(
			'car' + variant
		);


		sprite.x = 950;
		sprite.y = 360;
		sprite.angle = -1;


		if (carRide2 != null)
		{
			carRide2.volume = 0.9;
			carRide2.play();
		}
	}


	/*
	 * =========================================================
	 * BEAT HIT
	 * =========================================================
	 */

	override function onBeatHit(event:SongTimeScriptEvent)
	{
		super.onBeatHit(event);


		/*
		 * Desincroniza las gotas después de que el
		 * danceEvery del JSON haya actualizado la animación.
		 */

		randomizeRain();


		if (Preferences.lowQuality)
			return;


		/*
		 * -----------------------------------------------------
		 * COCHE IZQUIERDO
		 * -----------------------------------------------------
		 */

		if (
			FlxG.random.bool(15) &&
			!carLeftMoving
		)
		{
			driveCar(
				getNamedProp('phillyCars')
			);
		}


		/*
		 * -----------------------------------------------------
		 * COCHE DERECHO
		 * -----------------------------------------------------
		 */

		if (
			FlxG.random.bool(15) &&
			!carRightMoving
		)
		{
			driveCarBack(
				getNamedProp('phillyCars2')
			);
		}
	}


	/*
	 * =========================================================
	 * LIMPIEZA
	 * =========================================================
	 */

	public override function kill():Void
	{
		super.kill();

		carLeftMoving = false;
		carRightMoving = false;


		if (rainSndAmbience != null)
			rainSndAmbience.stop();

		if (carSndAmbience != null)
			carSndAmbience.stop();

		if (carRide1 != null)
			carRide1.stop();

		if (carRide2 != null)
			carRide2.stop();
	}


	public override function destroy():Void
	{
		super.destroy();

		carLeftMoving = false;
		carRightMoving = false;


		if (rainSndAmbience != null)
			rainSndAmbience.stop();

		if (carSndAmbience != null)
			carSndAmbience.stop();

		if (carRide1 != null)
			carRide1.stop();

		if (carRide2 != null)
			carRide2.stop();
	}


	/*
	 * =========================================================
	 * PAUSE
	 * =========================================================
	 */

	public override function onPause(event:PauseScriptEvent)
	{
		super.onPause(event);


		if (rainSndAmbience != null)
			rainSndAmbience.pause();

		if (carSndAmbience != null)
			carSndAmbience.pause();

		if (carRide1 != null)
			carRide1.pause();

		if (carRide2 != null)
			carRide2.pause();
	}


	/*
	 * =========================================================
	 * RESUME
	 * =========================================================
	 */

	public override function onResume(event:ScriptEvent)
	{
		super.onResume(event);


		if (rainSndAmbience != null)
			rainSndAmbience.resume();

		if (carSndAmbience != null)
			carSndAmbience.resume();

		if (carRide1 != null)
			carRide1.resume();

		if (carRide2 != null)
			carRide2.resume();
	}
}