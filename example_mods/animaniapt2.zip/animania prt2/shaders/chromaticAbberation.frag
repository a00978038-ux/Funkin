#pragma header

uniform float strength;

void main()
{
	vec2 uv = openfl_TextureCoordv;

	vec2 center = uv - 0.5;

	float dist = dot(center, center);

	float offset = strength * dist * 0.15;

	float r = texture2D(
		bitmap,
		uv + vec2(offset, 0.0)
	).r;

	float g = texture2D(
		bitmap,
		uv
	).g;

	float b = texture2D(
		bitmap,
		uv - vec2(offset, 0.0)
	).b;

	float a = texture2D(
		bitmap,
		uv
	).a;

	gl_FragColor = vec4(r, g, b, a);
}