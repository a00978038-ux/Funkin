#pragma header

uniform vec4 blendColor;
uniform int iBlendMode;
uniform float hue;
uniform float saturation;
uniform float brightness;
uniform float contrast;

const vec3 WHITE = vec3(1.0);

const vec3 grayscaleValues = vec3(
    0.3098039215686275,
    0.607843137254902,
    0.0823529411764706
);

const float e = 2.718281828459045;

const mat3 hueM1 = mat3(
    0.213, 0.213, 0.213,
    0.715, 0.715, 0.715,
    0.072, 0.072, 0.072
);

const mat3 hueM2 = mat3(
    0.787, -0.213, -0.213,
    -0.715, 0.285, -0.715,
    -0.072, -0.072, 0.928
);

const mat3 hueM3 = mat3(
    -0.213, 0.143, -0.787,
    -0.715, 0.140, 0.715,
    0.928, -0.283, 0.072
);

vec3 applyHueRotate(vec3 aColor, float aHue)
{
    float angle = radians(aHue);

    mat3 m =
        hueM1 +
        cos(angle) * hueM2 +
        sin(angle) * hueM3;

    return clamp(m * aColor, 0.0, 1.0);
}

vec3 applySaturation(vec3 aColor, float value)
{
    if (value > 0.0)
        value *= 3.0;

    value = 1.0 + (value / 100.0);

    vec3 grayscale = vec3(dot(aColor, grayscaleValues));

    return clamp(
        mix(grayscale, aColor, value),
        0.0,
        1.0
    );
}

vec3 applyContrast(vec3 aColor, float value)
{
    value = 1.0 + (value / 100.0);

    if (value > 1.0)
    {
        value =
            (
                (
                    0.00852259 *
                    pow(e, 4.76454 * (value - 1.0))
                ) *
                1.01
                -
                0.0086078159
            ) *
            10.0;

        value += 1.0;
    }

    return clamp(
        (aColor - 0.25) * value + 0.25,
        0.0,
        1.0
    );
}

vec4 applyHSBCEffect(vec4 textureColor)
{
    vec3 color;

    // Evitar problemas con alpha premultiplicado.
    if (textureColor.a > 0.0)
        color = textureColor.rgb / textureColor.a;
    else
        color = textureColor.rgb;

    // Brightness
    color += brightness / 255.0;

    // Hue
    if (hue != 0.0)
        color = applyHueRotate(color, hue);

    // Contrast
    if (contrast != 0.0)
        color = applyContrast(color, contrast);

    // Saturation
    if (saturation != 0.0)
        color = applySaturation(color, saturation);

    color = clamp(color, 0.0, 1.0);

    // Volver a premultiplicar alpha.
    return vec4(
        color * textureColor.a,
        textureColor.a
    );
}

vec4 blendMultiply(vec4 base, vec4 tint)
{
    return vec4(
        base.rgb * mix(WHITE, tint.rgb, tint.a),
        base.a
    );
}

void main()
{
    // Muestreo directo.
    // Esto evita depender de flixel_texture2D para props.
    vec4 color = texture2D(
        bitmap,
        openfl_TextureCoordv
    );

    // Aplicar HSV.
    color = applyHSBCEffect(color);

    // Aplicar el color Multiply del shader original.
    color = blendMultiply(
        color,
        blendColor
    );

    // Restaurar alpha global de OpenFL.
    color *= openfl_Alphav;

    gl_FragColor = color;
}