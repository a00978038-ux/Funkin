Español:
Que agregué en esta version?

•El nivel de Winter Horrorland obviamente
•La pantalla de inicio y las pantallas de carga de Animania
•Los controles de la Week1
•Las animaciones Angry/cansado faltantes de BF en Dadbattle
•Las animaciones/poses de Dad en Dadbattle
•Arreglo de bugs(eso espero)

-Espero les haya gustado esta version
-recuerden que talvez encuentren errores al juntarlo con otros mods,asi que kes recomiendo no juntarlo con otros mods intalados.
Att.@luis.dzul.royale





English:
What did I add in this version?

•The Winter Horrorland level, obviously
•The Animania title screen and loading screens 
•Week 1 controls
•BF's missing Angry/Tired animations for Dadbattle
•Dad's animations/poses for Dadbattle
•Bug fixes (hopefully)

-I hope you enjoyed this version
-Keep in mind that you might encounter errors when combining it with other mods, so I recommend not using it alongside other installed mods
By @luis.dzul.royale